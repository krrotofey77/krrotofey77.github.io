/*
** Watch_Face_Editor tool
** watchface js version v2.1.1
** Copyright © SashaCX75. All Rights Reserved
*/
   
try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let timeSensor;
        let timerSec;

        //dynamic modify end

        //------------- вибро ------------------
        const vibrator = hmSensor.createSensor(hmSensor.id.VIBRATE);
        let stopVibro_Timer = null;
		
		function vibro(mode = 25, stopDelay = 30) {
			vibrator.stop();
			vibrator.scene = mode;
			vibrator.start();
			stopVibro_Timer = setTimeout(() => {
				stopVibro();
			}, stopDelay);
		}		

		function stopVibro(){
			vibrator.stop();
			if (stopVibro_Timer) clearTimeout(stopVibro_Timer);
		}

		/********  класс Провайдер погоды  ********/
		/******				v1.4			*******/
		/******		2025 © leXxiR [4pda]	*******/

		class WeatherProvider {
		  constructor(props = {}) {
			this.props = {
				night_icons: [],											// индексы иконок для замены день-ночь
				index: hmFS.SysProGetInt('WeatherProviderIndex') ?? 0,		// текущий индекс провайдера (сохраняется и считывается из памяти)
				show_toast: true,											// показывать всплывающее сообщение при переключении провайдера
				temp_widget: null,											// виджет TEXT для отображения температуры
				temp_max_widget: null,										// виджет TEXT для отображения максимальной температуры
				temp_min_widget: null,										// виджет TEXT для отображения минимальной температуры
				temp_feels_widget: null,									// виджет TEXT для отображения ощущаемой температуры
				icon_widget: null,											// виджет IMG для отображения значка погоды
				time_sensor: null,											// сенсор времени, если не задан, то создается новый
				weather_sensor: null,										// сенсор погоды, если не задан, то создается новый
				file_name: 'weather.json',									// имя файла с погодными данными
				auto_update: true,											// автоматическое обновление погоды (нет необходимости добавлять weatherProvider.update() в event.MINUTEEND и WIDGET_DELEGATE)
				lang: hmSetting.getLanguage() == 4 ? 0 : 1,					// языка устройства	(Русский = 0 / Английский = 1)
				...props,
			};

			this.providers = [
							{name: ['Zepp', 'Zepp'], appId: null},							// 0
							{name: ['Погодный сервис', 'Weather service'], appId: 1065824},	// 1
							{name: ['RuWeather', 'RWeather'], appId: 1066654},				// 2
						]

			this.last = {
				weatherIcon: '25',
				temperature: '--',
				temperatureFeels: '--',
				temperatureMax: '--',
				temperatureMin: '--',
				modTime: null,
			}

			if (!this.props.time_sensor) this.props.time_sensor = hmSensor.createSensor(hmSensor.id.TIME);
			if (!this.props.weather_sensor) this.props.weather_sensor = hmSensor.createSensor(hmSensor.id.WEATHER);
			if (isFinite(props.index)) hmFS.SysProSetInt('WeatherProviderIndex', props.index);
			if (this.props.auto_update) this.createHandlers();
		  }

		// создание обработчиков автоматического обновления погоды
			createHandlers() {
				this.props.time_sensor.addEventListener(this.props.time_sensor.event.MINUTEEND, () => this.update());

				this.widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
				  resume_call: ( () => this.update() )
				})
			}
 
		// служебные функции
			arrayBufferToCyrillic(buffer) {
			  let result = '';
			  const bytes = new Uint8Array(buffer);

			  let i = 0;
			  while (i < bytes.length) {
				let byte1 = bytes[i++];
				
				if (byte1 < 0x80) {								// Обработка 1-байтовых символов (ASCII)
				  result += String.fromCharCode(byte1);
				} else if (byte1 >= 0xC0 && byte1 < 0xE0) {		// Обработка 2-байтовых символов (UTF-8 кодировка для кириллицы)
				  let byte2 = bytes[i++];
				  let charCode = ((byte1 & 0x1F) << 6) | (byte2 & 0x3F);
				  result += String.fromCharCode(charCode);
				} else if (byte1 >= 0xE0 && byte1 < 0xF0) {		// Обработка 3-байтовых символов (например, для UTF-8)
				  let byte2 = bytes[i++];
				  let byte3 = bytes[i++];
				  let charCode = ((byte1 & 0x0F) << 12) | ((byte2 & 0x3F) << 6) | (byte3 & 0x3F);
				  result += String.fromCharCode(charCode);
				}
			  }

			  return result
			}

		// чтение погодных данных из файла
			readFile(app_id) {
			  if (!app_id) return null				
			  let str_result = "";
			  try {
				const [fs_stat, err] = hmFS.stat(this.props.file_name, {
				  appid: app_id,
				});
				if (err == 0) {
				  const fh = hmFS.open(this.props.file_name, hmFS.O_RDONLY, {
					appid: app_id,
				  });

				  const len = fs_stat.size;
				  let array_buffer = new ArrayBuffer(len);
				  hmFS.read(fh, array_buffer, 0, len);
				  hmFS.close(fh);
				  str_result = this.arrayBufferToCyrillic(array_buffer);

				  return str_result;
				} else {
				  console.log("err:", err);
				}
			  } catch (error) {
				console.log("error:", error);
				console.log("FAIL: No access to hmFS.");
			  }
			  return null;
			}

		// получить время последнего изменеия файла
			getFileModTime(app_id) {
			  if (!app_id) return null
			  try {
				const [fs_stat, err] = hmFS.stat(this.props.file_name, {
				  appid: app_id,
				});
				
				if (err == 0) {
				  return fs_stat.mtime
				} else {
				  console.log("ModTime err:", err);
				}
			  } catch (error) {
				console.log("ModTime error:", error);
				console.log("FAIL: No access to hmFS.");
			  }
				return null
			}

		// проверка времени суток: возвращает true, если сейчас день
			isDayNow() {
				const sunData = this.props.weather_sensor.getForecastWeather().tideData;
				let sunriseMins = 8 * 60;			// время восхода
				let sunsetMins = 20 * 60;			// и заката по умолчанию

				if (sunData.count > 0){
					const today = sunData.data[0];
					sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
					sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
				}

				const curMins = this.props.time_sensor.hour * 60 + this.props.time_sensor.minute;
				const nowIsDay = (curMins >= sunriseMins) && (curMins < sunsetMins);

				return nowIsDay
			}


		// сопоставление индекса иконки погоды из приложений WeatherService и RuWeather с иконками погоды от Zepp 
			getZeppIconIndex(index, app_id = null) {
				
				if (!app_id)  return index;			//	если нет app_id, то не меняем индекс иконки

				let newIndex = 25;
				
				if (app_id == 1065824) {					// WeatherService
					switch(index) {
					   case 1:
							newIndex = 3;
						break;
					   case 2:
							newIndex = 0;
						break;
					   case 3:
					   case 4:
							newIndex = 4;
						break;
					   case 5:
							newIndex = 1;
						break;
					   case 6:
							newIndex = 5;
						break;
					   case 7:
							newIndex = 10;
						break;
					   case 8:
							newIndex = 15;
						break;
					   case 9:
							newIndex = 6;
						break;
					   case 10:
							newIndex = 8;
						break;
					   case 11:
							newIndex = 9;
						break;
					   case 12:
							newIndex = 12;
						break;
					   case 13:
							newIndex = 13;
						break;
					   case 14:
							newIndex = 17;
						break;
					   default:
							newIndex = 25;
						break;
					}
				} else if (app_id == 1066654) {					// RuWeather
					newIndex = index - 1;
				}

				return newIndex
			}

		// температура со знаком
			tempWithSign(val){
				val = parseFloat(val);
				if (!isFinite(val)) return '--'		// если на входе не число - возвращаем прочерки
				val = Math.round(val);
				if (val > 0) val = '+' + val;
				val += '°';
				
				return val
			}

		//получение погодных данных из Zepp
			getZeppWeatherData() {
				const iconIndex = this.props.weather_sensor.curAirIconIndex ?? 25;
				const data = {
					weatherIcon: iconIndex,
					temperature: this.props.weather_sensor.current ?? '--',
					temperatureFeels: '--',
					temperatureMax: this.props.weather_sensor.high ?? '--',
					temperatureMin: this.props.weather_sensor.low ?? '--',
				}

				return data
			}

		//получение погодных данных из файла приложения
			getAppWeatherData(app_id) {
				const data = {
					weatherIcon: 25,
					temperature: '--',
					temperatureFeels: '--',
					temperatureMax: '--',
					temperatureMin: '--',
				}

				// читаем данные из файла данных приложения
				let weather_str = this.readFile(app_id);
				let weatherJson = JSON.parse(weather_str);
		  
				if (weatherJson) {
					if (isFinite(weatherJson.weatherIcon)) {		// считываем индекс иконки погоды и сразу переводим в нумерацию Zepp
					  data.weatherIcon = this.getZeppIconIndex(parseInt(weatherJson.weatherIcon), app_id);
					}

					if (isFinite(weatherJson.temperature)) {
					  data.temperature = parseFloat(weatherJson.temperature);
					  data.temperature = Math.round(data.temperature);
					}
					
					if (isFinite(weatherJson.temperatureFeels)){
						data.temperatureFeels = parseFloat(weatherJson.temperatureFeels);
						data.temperatureFeels = Math.round(data.temperatureFeels);
					}
					  
					if (isFinite(weatherJson.temperatureMax)){
						data.temperatureMax = parseFloat(weatherJson.temperatureMax);
						data.temperatureMax = Math.round(data.temperatureMax);
					}
					  
					if (isFinite(weatherJson.temperatureMin)){
						data.temperatureMin = parseFloat(weatherJson.temperatureMin);
						data.temperatureMin = Math.round(data.temperatureMin);
					}
				}
				
				return data
			}

		//получение погодных данных из файла приложения или Zepp
			getWeatherData(app_id = null) {
				if (!app_id) return this.getZeppWeatherData()		// если нет app_id, то получаем данные от Zepp
				else return this.getAppWeatherData(app_id);			// иначе читаем данные из файла данных приложения
			}

		// обновить виджеты, используя данные текущего провайдера
			update() {
				let curIcon = parseInt(this.last.weatherIcon);				// текущий индекс значка погоды без учета времени суток (т.е. число без "n")

				const modTime = this.getFileModTime(this.providers[this.props.index].appId);		// время изменеия файла с данными
				
				if (!modTime || this.last.modTime != modTime){										// если не получено время изменеия или оно отличается от последнего времени изменеия
			
  
					const newData = this.getWeatherData(this.providers[this.props.index].appId);	// тогда читаем новые данные из файла
					this.last.modTime = modTime;

					let val = this.tempWithSign(newData.temperature);
					if (val != this.last.temperature){
						this.last.temperature = val;
						if (this.props.temp_widget) this.props.temp_widget.setProperty(hmUI.prop.TEXT, val);
					}

					val = this.tempWithSign(newData.temperatureMax);
					if (val != this.last.temperatureMax){
						this.last.temperatureMax = val;
						if (this.props.temp_max_widget) this.props.temp_max_widget.setProperty(hmUI.prop.TEXT, val);
					}

					val = this.tempWithSign(newData.temperatureMin);
					if (val != this.last.temperatureMin){
						this.last.temperatureMin = val;
						if (this.props.temp_min_widget) this.props.temp_min_widget.setProperty(hmUI.prop.TEXT, val);
					}

					val = this.tempWithSign(newData.temperatureFeels);
					if (val != this.last.temperatureFeels){
						this.last.temperatureFeels = val;
						if (this.props.temp_feels_widget) this.props.temp_feels_widget.setProperty(hmUI.prop.TEXT, val);
					}

					
					curIcon = newData.weatherIcon;						// получаем текущий индекс значка погоды
				}

				if (this.props.night_icons.includes(curIcon) && !this.isDayNow()){		// если он в списке ночных иконок и сейчас "ночь", то добавляем суффикс 'n'
					curIcon += 'n';
				}

				if (curIcon != this.last.weatherIcon){
					this.last.weatherIcon = curIcon;
					if (this.props.icon_widget) this.props.icon_widget.setProperty(hmUI.prop.SRC, `w_${curIcon}.png`);
				}
			}

		// переключить на следующего провайдера
			next(show_toast = this.props.show_toast) {
				const v = (this.props.index + 1) % this.providers.length;
				this.provider = v;
				if (show_toast) hmUI.showToast({text: this.name});
			}
			
		// установить провайдера по индексу
			set provider(v) {
				this.props.index = v;
				hmFS.SysProSetInt('WeatherProviderIndex', v);
				this.update();
			}

		// получить индекс текущего провайдера
			get index() {
				return this.props.index
			}

		// получить название текущего провайдера
			get name() {
				return this.providers[this.props.index].name[this.props.lang]
			}

		// удалить
		  delete() {
			this.providers = null;
			this.props = null;
			this.last = null;
			if (this.widgetDelegate) {
				hmUI.deleteWidget(this.widgetDelegate);
				this.widgetDelegate = null;
			}
		  }

		}

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 155,
              y: 300,
              week_en: ["week_ru_1.png","week_ru_2.png","week_ru_3.png","week_ru_4.png","week_ru_5.png","week_ru_6.png","week_ru_7.png"],
              week_tc: ["week_ru_1.png","week_ru_2.png","week_ru_3.png","week_ru_4.png","week_ru_5.png","week_ru_6.png","week_ru_7.png"],
              week_sc: ["week_ru_1.png","week_ru_2.png","week_ru_3.png","week_ru_4.png","week_ru_5.png","week_ru_6.png","week_ru_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 216,
              day_startY: 350,
              day_sc_array: ["d32_or_0.png","d32_or_1.png","d32_or_2.png","d32_or_3.png","d32_or_4.png","d32_or_5.png","d32_or_6.png","d32_or_7.png","d32_or_8.png","d32_or_9.png"],
              day_tc_array: ["d32_or_0.png","d32_or_1.png","d32_or_2.png","d32_or_3.png","d32_or_4.png","d32_or_5.png","d32_or_6.png","d32_or_7.png","d32_or_8.png","d32_or_9.png"],
              day_en_array: ["d32_or_0.png","d32_or_1.png","d32_or_2.png","d32_or_3.png","d32_or_4.png","d32_or_5.png","d32_or_6.png","d32_or_7.png","d32_or_8.png","d32_or_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            
            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

            const { width: DEVICE_WIDTH, height: DEVICE_HEIGHT} = deviceInfo;
            const radius = DEVICE_WIDTH / 2, centerX = DEVICE_WIDTH / 2, centerY = DEVICE_HEIGHT / 2

            const weather = hmSensor.createSensor(hmSensor.id.WEATHER);

            let weatherImg, tempText, tempMinText, tempMaxText, tempFeelsText

            const weatherInfo = hmUI.createWidget(hmUI.widget.GROUP, {
              x: centerX - 130,
              y: centerY - 165,
              w: 250,
              h: 120,
            });

            weatherImg = weatherInfo.createWidget(hmUI.widget.IMG, {
              x: 20,
              y: 20,
              w: 60,
              h: 60,
              src: 'w_25.png',
            });

            tempText = weatherInfo.createWidget(hmUI.widget.TEXT, {
              x: 75,
              y: 25,
              w: 110,
              h: 50,
              text_size: 42,
              font: 'fonts/aldrichrusbydaymarius_080713.ttf',
              text: '--',
              color: 0xffffff,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V
            });

            tempMinText = weatherInfo.createWidget(hmUI.widget.TEXT, {
              x: 180,
              y: 46,
              w: 70,
              h: 40,
              text_size: 24,
              font: 'fonts/aldrichrusbydaymarius_080713.ttf',
              text: '--',
              color: 0xffffff,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V
            });

            tempMaxText = weatherInfo.createWidget(hmUI.widget.TEXT, {
              x: 180,
              y: 15,
              w: 70,
              h: 40,
              text_size: 24,
              font: 'fonts/aldrichrusbydaymarius_080713.ttf',
              text: '--',
              color: 0xffffff,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V
            });

            weatherInfo.createWidget(hmUI.widget.TEXT, {
              x: 15,
              y: 85,
              w: 160,
              h: 40,
              text_size: 24,
              font: 'fonts/aldrichrusbydaymarius_080713.ttf',
              text: 'Ощущается ',
              color: 0xaaaaaa,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V
            });

            tempFeelsText = weatherInfo.createWidget(hmUI.widget.TEXT, {
              x: 180,
              y: 83,
              w: 70,
              h: 40,
              text_size: 26,
              font: 'fonts/aldrichrusbydaymarius_080713.ttf',
              text: '--',
              color: 0xcccccc,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V
            });
// Создаем небольшой текст "Обновлено"
  updateToast =  weatherInfo.createWidget(hmUI.widget.TEXT, {
      x:  45,
      y:  60,
      w: 160,
      h: 40,
      text_size: 20,
      text: "Обновлено",
      color: 0xff593a,
      align_h: hmUI.align.CENTER_H,
      align_v: hmUI.align.CENTER_V,
  });

  // Удаляем через 1 секунду
  setTimeout(() => {
      hmUI.deleteWidget(updateToast);
  }, 1000);
            // экземпляр класса
            const weatherProvider = new WeatherProvider({
                night_icons: [0, 1, 2, 3, 14],
                show_toast: false,
                temp_widget: tempText,
                temp_max_widget: tempMaxText,
                temp_min_widget: tempMinText,
                temp_feels_widget: tempFeelsText,
                icon_widget: weatherImg,
                time_sensor: timeSensor,
                weather_sensor: weather,
            });

normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'arr_hour.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 13,
              hour_posY: 180,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'arr_min.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 13,
              minute_posY: 230,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
// ==========================================================
        // 🕑 СЕКУНДНАЯ СТРЕЛКА
        // ==========================================================
        const cx = deviceInfo.width / 2;
        const cy = deviceInfo.height / 2;

        const secondHand = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: cx - 13,
          pos_y: cy - 230,
          center_x: cx,
          center_y: cy,
          src: "arr_sec.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // ==========================================================
        // ⚙️ НАСТРОЙКИ (загрузка из SysPro или дефолт)
        // ==========================================================
        let bounceSettings = {
          bounce_back_angle: -4,
          bounce_forward_angle: 6,
          dur_back: 80,
          dur_forward: 100,
          dur_return: 60,
          anim_fps: 99,
          enable_shake: true, // эффект дребезжания
          dur_shake: 60,      // длительность дребезга
          shake_angle: 3.5,   // амплитуда дребезга
        };

        try {
          const stored = hmFS.SysProGetChars("bounce_settings");
          if (stored) {
            const parsed = JSON.parse(stored);
            Object.assign(bounceSettings, parsed);
            logger.log("Custom bounce settings loaded");
          }
        } catch (err) {
          logger.log("No custom settings found or parse error");
        }

        // ==========================================================
        // ⚙️ BOUNCE + SHAKE АНИМАЦИЯ
        // ==========================================================
        function bounceSecond(second) {
          if (timeSensor.second !== second) return;

          // 🧹 [1] очистка предыдущей анимации (улучшение №1)
          try {
            secondHand.setProperty(hmUI.prop.ANIM, null);
          } catch (e) {}

          const baseAngle = second * 6;
          const {
            bounce_back_angle,
            bounce_forward_angle,
            dur_back,
            dur_forward,
            dur_return,
            anim_fps,
            enable_shake,
            dur_shake,
            shake_angle,
          } = bounceSettings;

          // базовые три фазы
          const anim_steps = [
            {
              anim_rate: "ease-out",
              anim_duration: dur_back,
              anim_from: baseAngle,
              anim_to: baseAngle + bounce_back_angle,
              anim_key: "angle",
            },
            {
              anim_rate: "ease-in",
              anim_duration: dur_forward,
              anim_from: baseAngle + bounce_back_angle,
              anim_to: baseAngle + bounce_forward_angle,
              anim_key: "angle",
            },
            {
              anim_rate: "ease-out",
              anim_duration: dur_return,
              anim_from: baseAngle + bounce_forward_angle,
              anim_to: baseAngle,
              anim_key: "angle",
            },
          ];

          // 💥 добавляем дребезжание (улучшение №8)
          if (enable_shake) {
            anim_steps.push(
              {
                anim_rate: "ease-in-out",
                anim_duration: dur_shake,
                anim_from: baseAngle,
                anim_to: baseAngle + shake_angle,
                anim_key: "angle",
              },
              {
                anim_rate: "ease-out",
                anim_duration: dur_shake,
                anim_from: baseAngle + shake_angle,
                anim_to: baseAngle,
                anim_key: "angle",
              }
            );
          }

          const anim = {
            anim_steps,
            anim_fps,
            anim_auto_start: 1,
            anim_repeat: 0,
            anim_auto_destroy: 1,
          };

          secondHand.setProperty(hmUI.prop.ANIM, anim);
        }

            // КНОПКА ПЕРЕКЛЮЧЕНИЯ ПРОВАЙДЕРА (ТЕПЕРЬ СВЕРХУ ВСЕГО)
            hmUI.createWidget(hmUI.widget.BUTTON, {
                x: centerX - 40,
                y: centerY - 235,
                w: 80,
                h: 70,
                text: '',
                text_size: 36,
                color: 0xffffff, // цвет текста (можно поменять)
                normal_src: '',  // убираем подложку
                press_src: '',   // убираем фон при нажатии
                radius: 0,       // не нужен, если нет цвета
                show_level: hmUI.show_level.ONLY_NORMAL,
                click_func: () => {
                    vibro();
                    weatherProvider.next(true);
                    console.log('Button clicked: Provider switched to', weatherProvider.name); // для дебага
                },
            });

            console.log('Watch_Face.ScreenAOD');


                //dynamic modify end
           // ==========================================================
        // ⏱️ ТАЙМЕР С СИНХРОНИЗАЦИЕЙ
        // ==========================================================
        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
            resume_call: function () {
              if (!timerSec) {
                const nowMs = timeSensor.current;
                const currentSecond = timeSensor.second;
                const msToNext = (1000 - (nowMs % 1000)) % 1000;
  
                bounceSecond(currentSecond);
  
                timerSec = timer.createTimer(msToNext, 1000, () => {
                  bounceSecond(timeSensor.second);
                });
              }
            },
            pause_call: function () {
              if (timerSec) {
                timer.stopTimer(timerSec);
                timerSec = undefined;
              }
            },
          });
        },
  
        onInit() {
          logger.log("Bounce WatchFace Pro init");
        },
  
        build() {
          this.init_view();
          logger.log("Bounce WatchFace Pro ready");
        },
  
        onDestroy() {
          // 🧹 Очистка таймера при уничтожении (улучшение №6)
          if (timerSec) {
            timer.stopTimer(timerSec);
            timerSec = undefined;
          }
          // Очистка WeatherProvider
          if (typeof weatherProvider !== 'undefined') {
            weatherProvider.delete();
          }
          logger.log("Bounce WatchFace Pro destroyed");
        },
      });
    })();
  } catch (e) {
    console.log("Mini Program Error", e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log("error stack", i));
  }