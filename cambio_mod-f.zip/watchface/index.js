try {
    (() => {
        // Инициализация приложения и модуля
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() { return __$$app$$__.app; }
        function getCurrentPage() { return __$$app$$__.current && __$$app$$__.current.module; }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');

        // Константы для повторяющихся массивов изображений цифр и иконок
        const digitFontArraySmall = ["46.png", "47.png", "48.png", "49.png", "50.png", "51.png", "52.png", "53.png", "54.png", "55.png"];
        const digitFontArrayLarge = ["64.png", "65.png", "66.png", "67.png", "68.png", "69.png", "70.png", "71.png", "72.png", "73.png"];
        const timeFontArray = ["35.png", "36.png", "37.png", "38.png", "39.png", "40.png", "41.png", "42.png", "43.png", "44.png"];
        const windDirectionArray = ["80.png", "81.png", "82.png", "83.png", "84.png", "85.png", "86.png", "87.png"];
        const weatherIconArray = ["3.png", "4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png", "15.png", "16.png", "17.png", "18.png", "19.png", "20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png", "30.png", "31.png"];
        const batteryIconArray = ["56.png", "57.png", "58.png", "59.png", "60.png", "61.png", "62.png", "63.png"];

        // Переменные для интерфейса
        let normal_background_bg = null, normal_sun_current_text_img = null, normal_altimeter_text_text_img = null,
            normal_altimeter_text_separator_img = null, normal_wind_direction_image_progress_img_level = null,
            normal_wind_text_text_img = null, normal_wind_text_separator_img = null, normal_system_disconnect_img = null,
            image_top_img = null, normal_battery_image_progress_img_level = null, normal_battery_text_text_img = null,
            normal_weather_image_progress_img_level = null, normal_temperature_high_text_img = null,
            normal_temperature_low_text_img = null, normal_temperature_current_text_img = null, normal_image_img = null,
            normal_digital_clock_img_time = null, idle_background_bg = null, idle_digital_clock_img_time = null,
            normal_altimeter_mm_img = null, weather_day = null, normal_distance_text_text_img = null,
            normal_step_current_text_img = null, normal_step_current_separator_img = null, normal_heart_rate_text_text_img = null,
            normal_heart_rate_text_separator_img = null,alarm_clock_img = null, btn_zona1 = null,Button_1 = null;

        // Датчики
        const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
        const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
        const vibrateSensor = hmSensor.createSensor(hmSensor.id.VIBRATE);
        let isDayIcons = false;
        let shotWeaterhNames = [];

        // Константы и переменные для календаря
        const customFont = 'fonts/mi-Bold_0.ttf';
        let calendarWidgets = [];
        const cellSizeWidth = 30, cellSizeHeight = 25, cellSpacing = 1;
        let currentDisplayMonth = null;
        let currentDisplayYear = null;

        // Переменные для переключения зон
        let zona1_num = 0;
        const zona1_all = 1;

        // Кэшированные списки погодных названий
        const dayWeatherNames = ["Облачно", "Местами дождь", "Местами снег", "Cолнечно", "Пасмурно", "Слабый дождь", 
            "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", 
            "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", 
            "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", 
            "Сильная песчаная буря", "Сильный дождь", "Неизвестная погода", "Облачно ночью", 
            "Дождливо ночью", "Ясно ночью"];
        const nightWeatherNames = ["Облачно ночью", "Местами дождь", "Местами снег", "Ясно ночью", "Пасмурно ночью", 
            "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", 
            "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", 
            "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", 
            "Песчаная буря", "Сильная песчаная буря", "Сильный дождь", "Неизвестная погода", 
            "Облачно ночью", "Дождливо ночью", "Ясно ночью"];

        // Функции для работы с давлением
        function read_pressure() {
            console.log("read_pressure()");
            const file_name_alt = "../../../baro_altim/pressure.dat";
            const [fs_stat, err] = hmFS.stat(file_name_alt);
            if (err == 0) {
                let file_size = fs_stat.size;
                const len = file_size / 4;
                console.log(`size_alt: ${file_size}, lenght: ${len}`);
                const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY);
                let array_buffer = new Float32Array(len);
                hmFS.read(fh, array_buffer.buffer, 0, file_size);
                hmFS.close(fh);
                console.log(`value ${array_buffer[array_buffer.length - 1]}`);
                return array_buffer;
            } else {
                console.log('err:', err);
            }
            return null;
        }

        function getPressureValue(pressure_array) {
            console.log("getPressureValue()");
            if (!pressure_array || pressure_array.length == 0) return 0;
            let start_index = pressure_array.length - 1;
            let end_index = start_index - 30 * 3;
            if (end_index < 0) end_index = 0;
            for (let index = start_index; index >= end_index; index--) {
                if (pressure_array[index] != 0) return parseInt(pressure_array[index] / 100);
            }
            return 0;
        }

        function hPa_To_mmHg(hPa_value = 0) {
            return Math.round(hPa_value * 0.750064);
        }

        function getPressureMMHG() {
            const pressure_array = read_pressure();
            return hPa_To_mmHg(getPressureValue(pressure_array));
        }

        function updatePressure() {
            const pressureValue = getPressureMMHG();
            normal_altimeter_text_text_img.setProperty(hmUI.prop.MORE, {
                x: 119, y: 372, font_array: digitFontArraySmall,
                padding: false, h_space: 0, invalid_image: '78.png', text: pressureValue, show_level: hmUI.show_level.ONLY_NORMAL
            });
            normal_altimeter_mm_img.setProperty(hmUI.prop.MORE, {
                x: 119 + 48, y: 372, show_level: hmUI.show_level.ONLY_NORMAL
            });
        }

        // Исправленная функция обновления погоды
        function updateWeather() {
            try {
                let weatherData = weatherSensor.getForecastWeather();
                let curAirIconIndex = weatherSensor.curAirIconIndex;

                // Если данных нет, ждём и показываем временный текст
                if (!weatherData || typeof curAirIconIndex !== 'number') {
                    weather_day.setProperty(hmUI.prop.TEXT, "Загрузка погоды...");
                    console.log("Weather data not ready yet");
                    return;
                }

                let sunData = weatherData.tideData || { count: 0 };
                let sunriseMins, sunsetMins;

                if (sunData.count > 0) {
                    let today = sunData.data[0];
                    sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
                    sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
                } else {
                    sunriseMins = 360; // 6:00
                    sunsetMins = 1080; // 18:00
                }

                let curMins = timeSensor.hour * 60 + timeSensor.minute;
                isDayIcons = (curMins >= sunriseMins) && (curMins < sunsetMins);
                shotWeaterhNames = isDayIcons ? dayWeatherNames : nightWeatherNames;

                // Устанавливаем текст погоды
                let weatherText = curAirIconIndex >= 0 && curAirIconIndex < shotWeaterhNames.length 
                    ? shotWeaterhNames[curAirIconIndex] 
                    : "Неизвестная погода";
                weather_day.setProperty(hmUI.prop.TEXT, weatherText);

                normal_weather_image_progress_img_level.setProperty(hmUI.prop.ANIM, {
                    anim_steps: 10,
                    anim_fps: 30,
                    anim_duration: 500
                });
            } catch (e) {
                console.log("Error in updateWeather:", e);
                weather_day.setProperty(hmUI.prop.TEXT, "Ошибка погоды");
            }
        }

        // Функция обновления календаря
        function updateCalendar(day, month, year, isInitial = false) {
            if (isInitial) {
                currentDisplayMonth = month;
                currentDisplayYear = year;
            }

            calendarWidgets.forEach(widget => hmUI.deleteWidget(widget));
            calendarWidgets = [];

            const today = new Date(year, month, day);
            const displayDate = new Date(currentDisplayYear, currentDisplayMonth, 1);
            const currentDay = today.getDate();
            const currentMonth = today.getMonth();
            const currentYear = today.getFullYear();
            const currentDayOfWeek = (today.getDay() + 6) % 7;

            const firstDay = new Date(currentDisplayYear, currentDisplayMonth, 1).getDay();
            const correctedFirstDay = (firstDay + 6) % 7;
            const daysInMonth = new Date(currentDisplayYear, currentDisplayMonth + 1, 0).getDate();

            const monthNames = ["Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
                "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"];
            const daysOfWeek = ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"];

            const startX = 210, startY = 195;
            const colorWeekday = 0xFFFFFF, colorSaturday = 0xecb2b2, colorSunday = 0xecb2b2,
                  colorToday = 0xFF5555, backgroundColor = 0x292929, backgroundRadius = 8,
                  todayBackgroundColor = 0x282828;

            calendarWidgets.push(hmUI.createWidget(hmUI.widget.TEXT, {
                x: startX + 50, y: startY, w: 200, h: 40, color: 0xFFFFFF, text_size: 20,
                align_h: hmUI.align.CENTER_H, text: `${monthNames[currentDisplayMonth]} ${currentDisplayYear}`, 
                font: customFont, show_level: hmUI.show_level.ONLY_NORMAL
            }));

            calendarWidgets.push(hmUI.createWidget(hmUI.widget.FILL_RECT, {
                x: startX - 5, y: startY + 30 - 5, w: cellSizeWidth * 7 + 10, h: 30,
                radius: backgroundRadius, color: backgroundColor, show_level: hmUI.show_level.ONLY_NORMAL
            }));

            for (let i = 0; i < 7; i++) {
                let textColor = (currentDisplayYear === currentYear && 
                                 currentDisplayMonth === currentMonth && 
                                 i === currentDayOfWeek) ? colorToday : 0xC8C8C8;
                calendarWidgets.push(hmUI.createWidget(hmUI.widget.TEXT, {
                    x: startX + i * cellSizeWidth, y: startY + 30, w: cellSizeWidth, h: 30,
                    color: textColor, text_size: 18, align_h: hmUI.align.CENTER_H, text: daysOfWeek[i],
                    font: customFont, show_level: hmUI.show_level.ONLY_NORMAL
                }));
            }

            for (let i = 1; i <= daysInMonth; i++) {
                let x = startX + ((i + correctedFirstDay - 1) % 7) * cellSizeWidth;
                let y = startY + 60 + Math.floor((i + correctedFirstDay - 1) / 7) * cellSizeHeight;

                if (currentDisplayYear === currentYear && 
                    currentDisplayMonth === currentMonth && 
                    i === currentDay) {
                    calendarWidgets.push(hmUI.createWidget(hmUI.widget.FILL_RECT, {
                        x: x - cellSpacing, y: y - cellSpacing, w: cellSizeWidth + cellSpacing * 2,
                        h: cellSizeHeight + cellSpacing * 2, radius: 6, color: todayBackgroundColor,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    }));
                }

                let textColor = ((i + correctedFirstDay - 1) % 7 === 5) ? colorSaturday :
                                ((i + correctedFirstDay - 1) % 7 === 6) ? colorSunday : colorWeekday;
                if (currentDisplayYear === currentYear && 
                    currentDisplayMonth === currentMonth && 
                    i === currentDay) textColor = colorToday;

                calendarWidgets.push(hmUI.createWidget(hmUI.widget.TEXT, {
                    x: x, y: y, w: cellSizeWidth, h: cellSizeHeight, color: textColor,
                    text_size: 18, align_h: hmUI.align.CENTER_H, text: `${i}`, font: customFont,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }));
            }

            calendarWidgets.push(hmUI.createWidget(hmUI.widget.BUTTON, {
                x: 220, y: 200, w: 80, h: 80,
                normal_src: 'prev.png', press_src: 'prev_press.png',
                click_func: () => prevMonth(),
                show_level: hmUI.show_level.ONLY_NORMAL
            }));

            calendarWidgets.push(hmUI.createWidget(hmUI.widget.BUTTON, {
                x: 330, y: 200, w: 80, h: 80,
                normal_src: 'next.png', press_src: 'next_press.png',
                click_func: () => nextMonth(),
                show_level: hmUI.show_level.ONLY_NORMAL
            }));
        }

        // Функции переключения месяцев с восстановленной вибрацией
        function prevMonth() {
            vibrateSensor.stop();
            vibrateSensor.scene = 25;
            vibrateSensor.start();
            setTimeout(() => vibrateSensor.stop(), 300);

            currentDisplayMonth--;
            if (currentDisplayMonth < 0) {
                currentDisplayMonth = 11;
                currentDisplayYear--;
            }
            updateCalendar(timeSensor.day, timeSensor.month - 1, timeSensor.year);
        }

        function nextMonth() {
            vibrateSensor.stop();
            vibrateSensor.scene = 25;
            vibrateSensor.start();
            setTimeout(() => vibrateSensor.stop(), 300);

            currentDisplayMonth++;
            if (currentDisplayMonth > 11) {
                currentDisplayMonth = 0;
                currentDisplayYear++;
            }
            updateCalendar(timeSensor.day, timeSensor.month - 1, timeSensor.year);
        }

        // Функция переключения зон
        function click_zona1() {
            zona1_num = (zona1_num + 1) % (zona1_all + 1);
            if (zona1_num === 0) {
                normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
                normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_wind_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_altimeter_mm_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                hmUI.showToast({text: "погода"});
            } else if (zona1_num === 1) {
                normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
                normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_wind_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_altimeter_mm_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
                hmUI.showToast({text: "активность"});
            }
        }

        function click_Vibrate() {
            // Функция вибрации (оставлена пустой)
        }

        // Основной модуль циферблата
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                    x: 0, y: 0, w: 466, h: 466, color: '0xFF000000', show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 124, y: 407, font_array: digitFontArraySmall,
                    padding: false, h_space: 0, dot_image: '91.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.SUN_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 119, y: 372, font_array: digitFontArraySmall,
                    padding: false, h_space: 0, invalid_image: '78.png', align_h: hmUI.align.CENTER_H, text: getPressureMMHG(),
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_altimeter_mm_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 119 + 48, y: 372, src: "90.png", show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_altimeter_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 90, y: 369, src: '89.png', show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 174, y: 333, image_array: windDirectionArray,
                    image_length: 8, type: hmUI.data_type.WIND_DIRECTION, show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_wind_direction_image_progress_img_level.setAlpha(240);
                normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 104, y: 336, font_array: digitFontArraySmall,
                    padding: false, h_space: 0, unit_sc: '79.png', unit_tc: '79.png', unit_en: '79.png', align_h: hmUI.align.CENTER_H,
                    type: hmUI.data_type.WIND, show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_wind_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 67, y: 333, src: '88.png', show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 360, y: 89, src: '33.png', type: hmUI.system_status.DISCONNECT, show_level: hmUI.show_level.ONLY_NORMAL
                });
                image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 235,
              y: 404,
              src: '97.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
                normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 220, y: 81, image_array: batteryIconArray,
                    image_length: 8, type: hmUI.data_type.BATTERY, show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 253, y: 93, font_array: digitFontArrayLarge,
                    padding: false, h_space: 0, unit_sc: '74.png', unit_tc: '74.png', unit_en: '74.png', align_h: hmUI.align.CENTER_H,
                    type: hmUI.data_type.BATTERY, show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 35, y: 102, image_array: weatherIconArray,
                    image_length: 29, type: hmUI.data_type.WEATHER_CURRENT, show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 132, y: 67, font_array: digitFontArraySmall,
                    padding: false, h_space: 0, unit_sc: '77.png', unit_tc: '77.png', unit_en: '77.png', negative_image: '78.png',
                    invalid_image: '78.png', align_h: hmUI.align.RIGHT, type: hmUI.data_type.WEATHER_HIGH, show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 132, y: 100, font_array: digitFontArraySmall,
                    padding: false, h_space: 0, unit_sc: '77.png', unit_tc: '77.png', unit_en: '77.png', negative_image: '78.png',
                    invalid_image: '78.png', align_h: hmUI.align.RIGHT, type: hmUI.data_type.WEATHER_LOW, show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 20, y: 251, font_array: digitFontArrayLarge,
                    padding: false, h_space: 0, unit_sc: '75.png', unit_tc: '75.png', unit_en: '75.png', negative_image: '76.png',
                    invalid_image: '76.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.WEATHER_CURRENT, show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0, y: 0, src: '1.png', show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_startX: 233, hour_startY: 135, hour_array: timeFontArray,
                    hour_zero: 1, hour_space: 0, hour_angle: 0, hour_unit_sc: '45.png', hour_unit_tc: '45.png', hour_unit_en: '45.png',
                    hour_align: hmUI.align.CENTER_H, minute_startX: 0, minute_startY: 0, minute_array: timeFontArray,
                    minute_zero: 1, minute_space: 0, minute_angle: 0, minute_follow: 1, minute_align: hmUI.align.CENTER_H,
                    second_startX: 400, second_startY: 165, second_array: digitFontArraySmall,
                    second_zero: 1, second_space: 0, second_angle: 0, second_follow: 0, second_align: hmUI.align.CENTER_H,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 96, y: 369, font_array: digitFontArraySmall,
                    padding: false, h_space: 0, unit_sc: '93.png', unit_tc: '93.png', unit_en: '93.png', dot_image: '94.png',
                    align_h: hmUI.align.CENTER_H, type: hmUI.data_type.DISTANCE, show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 104, y: 336, font_array: digitFontArraySmall,
                    padding: false, h_space: 0, align_h: hmUI.align.CENTER_H, type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 67, y: 333, src: '92.png', show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {  
                    x: 141, y: 406, font_array: digitFontArraySmall,
                    padding: false, h_space: 0, align_h: hmUI.align.CENTER_H, type: hmUI.data_type.HEART, 
                    show_level: hmUI.show_level.ONLY_NORMAL
                }); 
                normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 107, y: 404, src: '95.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
    alarm_clock_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 253, y: 407, font_array: digitFontArraySmall,
                    padding: true, h_space: 0, dot_image: '91.png',invalid_image: '96.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.ALARM_CLOCK,
          show_level: hmUI.show_level.ONLY_NORMAL,
            });
    
            //ALARM CLOCK 
            console.log('Watch_Face.Shortcuts');
                
                idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                    x: 0, y: 0, w: 466, h: 466, color: '0xFF000000', show_level: hmUI.show_level.ONLY_AOD
                });
                idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_startX: 233, hour_startY: 183, hour_array: timeFontArray,
                    hour_zero: 1, hour_space: 0, hour_angle: 0, hour_unit_sc: '45.png', hour_unit_tc: '45.png', hour_unit_en: '45.png',
                    hour_align: hmUI.align.CENTER_H, minute_startX: 0, minute_startY: 0, minute_array: timeFontArray,
                    minute_zero: 1, minute_space: 0, minute_angle: 0, minute_follow: 1, minute_align: hmUI.align.CENTER_H,
                    second_startX: 400, second_startY: 187, second_array: digitFontArraySmall,
                    second_zero: 1, second_space: 0, second_angle: 0, second_follow: 0, second_align: hmUI.align.CENTER_H,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                weather_day = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 9, y: 292, w: 205, h: 30, text_size: 19, char_space: 0, line_space: 0,
                    font: customFont, color: 0xFFFFFF, align_h: hmUI.align.CENTER_H, align_v: hmUI.align.TOP,
                    text_style: hmUI.text_style.ELLIPSIS, show_level: hmUI.show_level.ONLY_NORMAL
                });
Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 55,
  y: 150,
  w: 100,
  h: 100,
  text: '',
  normal_src: 'empty.png',
  press_src: 'empty.png',
  click_func: () => {
	hmApp.startApp({ appid: 1066654, 
		url: 'page/index',
		params: {
			from_wf: true,
		}
	});
  },
});
  
                btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
                    x: 100, y: 335, text: '', w: 80, h: 80,
                    normal_src: 'Empty.png', press_src: 'Empty.png',
                    click_func: () => {
                        click_zona1();
                        click_Vibrate();
                    },
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

                time_update(true);
                // Задержка перед обновлением погоды при старте
                setTimeout(() => updateWeather(), 2000); // 2 секунды задержки

                timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
                    time_update(true);
                    updateWeather();
                });
            },

            onInit() {
                logger.log('index page.js on init invoke');
            },

            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },

            onDestroy() {
                logger.log('index page.js on destroy invoke');
                timeSensor.removeEventListener(timeSensor.event.DAYCHANGE);
                calendarWidgets.forEach(widget => hmUI.deleteWidget(widget));
                calendarWidgets = [];
            }
        });

        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
            resume_call: () => {
                console.log('resume_call()');
                updatePressure();
                updateWeather();
                time_update(true);
            }
        });

        function time_update(updateDay = false) {
            if (!timeSensor) return;
            let g_day = timeSensor.day;
            let g_month = timeSensor.month - 1;
            let g_year = timeSensor.year;
            if (updateDay) updateCalendar(g_day, g_month, g_year, true);
        }
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}