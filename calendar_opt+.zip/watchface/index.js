﻿/*
** Watch_Face_Editor tool
** watchface js version v2.1.1
** Copyright © SashaCX75. All Rights Reserved
*/

try {
(() => {
    // start of ignored block
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;

    function getApp() {
        return __$$app$$__.app;
    }

    function getCurrentPage() {
        return __$$app$$__.current && __$$app$$__.current.module;
    }

    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(
        new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__)
    );
    const { px } = __$$app$$__.__globals__;
    const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75');
    // end of ignored block

    // ======================================================
    // ================= ADVANCED BAROMETER ==================
    // ======================================================

    class AdvancedBarometer {
        constructor(props = {}) {
            this.props = {
                unit_index: hmFS.SysProGetInt('BaroUnitIndex') ?? 0,
                show_toast: true,
                widget: null,
                show_trend: true,
                time_sensor: null,
                auto_update: true,
                lang: hmSetting.getLanguage() === 4 ? 0 : 1,
                ...props,
            };

            this.unitStr = [
                ['мм рт.ст.', 'mmHg'],
                ['гПа', 'hPa'],
            ];

            this.last = {
                value: '--',
                trend: '',
            };

            if (!this.props.time_sensor) {
                this.props.time_sensor = hmSensor.createSensor(hmSensor.id.TIME);
            }

            if (isFinite(props.unit_index)) {
                hmFS.SysProSetInt('BaroUnitIndex', props.unit_index);
            }

            if (this.props.auto_update) {
                this.createHandlers();
            }
        }

        createHandlers() {
            this.props.time_sensor.addEventListener(
                this.props.time_sensor.event.MINUTEEND,
                () => this.update()
            );

            this.widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                resume_call: () => this.update(),
            });
        }

        readDataFile() {
            const file_name_alt = "../../../baro_altim/pressure.dat";
            const [fs_stat, err] = hmFS.stat(file_name_alt);

            if (err !== 0) {
                console.log('Ошибка чтения файла:', err);
                return null;
            }

            const file_size = fs_stat.size;
            const len = file_size / 4;
            const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY);
            const array_buffer = new Float32Array(len);

            hmFS.read(fh, array_buffer.buffer, 0, file_size);
            hmFS.close(fh);

            return array_buffer;
        }

        getLastValue(data_array) {
            if (!data_array?.length) return null;

            const start = data_array.length - 1;
            let end = start - 30 * 3;
            if (end < 0) end = 0;

            for (let i = start; i >= end; i--) {
                if (data_array[i] !== 0) return parseInt(data_array[i] / 100);
            }

            return null;
        }

        getPressureChange(data_array) {
            if (!data_array?.length) return null;

            const start = data_array.length - 1;
            let end = start - 30 * 3;
            if (end < 0) end = 0;

            const value = data_array[start];

            for (let i = start - 1; i >= end; i--) {
                const element = data_array[i];
                if (element !== 0 && Math.abs(value - element) > 75) {
                    return value - element;
                }
            }

            return null;
        }

        getPressureAndTrend() {
            const data_array = this.readDataFile();
            const value = this.getLastValue(data_array);

            let trend = '';
            const pressureChange = this.getPressureChange(data_array);

            if (pressureChange < 0) trend = '↓';
            else if (pressureChange > 0) trend = '↑';

            return { value, trend };
        }

        setUnits(unit_index) {
            if (!isFinite(unit_index)) return;

            this.props.unit_index = unit_index === 1 ? 1 : 0;
            hmFS.SysProSetInt('BaroUnitIndex', this.props.unit_index);

            if (this.props.widget) {
                this.updateWidget();
            }
        }

        toggleUnits(show_toast = this.props.show_toast) {
            const newIndex = (this.props.unit_index + 1) % this.unitStr.length;
            this.setUnits(newIndex);

            if (show_toast) {
                hmUI.showToast({ text: this.unit });
            }
        }

        update() {
            const { value, trend } = this.getPressureAndTrend();

            if (value !== this.last.value) {
                this.last.value = value;
                this.last.trend = trend;

                if (this.props.widget) {
                    this.updateWidget();
                }
            }
        }

        updateWidget() {
            let str = this.pressure;
            if (this.props.show_trend) {
                str += ` ${this.last.trend}`;
            }
            this.props.widget.setProperty(hmUI.prop.TEXT, str);
        }

        get mmHg() {
            const v = this.last.value;
            if (!v) return '--';
            return Math.round(v * 0.750064).toString();
        }

        get hPa() {
            const v = this.last.value;
            if (!v) return '--';
            return v.toString();
        }

        get pressure() {
            return this.props.unit_index === 0 ? this.mmHg : this.hPa;
        }

        get unit() {
            return this.unitStr[this.props.unit_index][this.props.lang];
        }

        delete() {
            this.props = null;
            this.last = null;
            this.unitStr = null;

            if (this.widgetDelegate) {
                hmUI.deleteWidget(this.widgetDelegate);
                this.widgetDelegate = null;
            }
        }
    }

    // ======================================================
    // ===================== HOLIDAYS ========================
    // ======================================================

    const HOLIDAYS = {
        "01-01": "Новый год ",
        "01-02": "Новогодние каникулы ",
        "01-03": "Новогодние каникулы ",
        "01-04": "Новогодние каникулы ",
        "01-05": "Новогодние каникулы ",
        "01-06": "Новогодние каникулы ",
        "01-07": "Рождество Христово ",
        "01-08": "Новогодние каникулы ",
        "01-14": "Старый Новый год",
        "01-25": "Татьянин день, День студента 🎓",
        "01-27": "День воинской славы России🎖",
        "02-08": "День российской науки 🔬",
        "02-10": "День дипломатического работника ",
        "02-14": "День святого Валентина ",
        "02-15": "День воинов-интернационалистов",
        "02-23": "День защитника Отечества ",
        "03-08": "Международный женский день ",
        "03-10": "День работников ЖКХ ",
        "03-19": "День моряка-подводника ",
        "03-27": "День войск национальной гвардии ",
        "04-01": "День смеха ",
        "04-02": "День единения народов ",
        "04-07": "День здоровья ",
        "04-12": "День космонавтики ",
        "04-18": "День победы на Чудском озере ",
        "04-26": "День участников ликвидации радиационных аварий ",
        "04-30": "День пожарной охраны ",
        "05-01": "Праздник Весны и Труда ",
        "05-07": "День радио ",
        "05-09": "День Победы 🎖",
        "05-12": "День экологического образования ",
        "05-15": "Международный день семьи ",
        "05-18": "День Балтийского флота ",
        "05-24": "День славянской письменности и культуры ",
        "05-26": "День российского предпринимательства ",
        "05-27": "День библиотек ",
        "05-28": "День пограничника ",
        "05-31": "День адвокатуры ",
        "06-01": "Международный день защиты детей ",
        "06-06": "Пушкинский день России ",
        "06-12": "День России 🇷🇺",
        "06-22": "День памяти и скорби ",
        "06-27": "День молодежи ",
        "07-02": "День следователя ",
        "07-08": "День семьи, любви и верности ",
        "07-10": "День воинской славы России 🎖",
        "07-17": "День этнографа ",
        "07-24": "День кадастрового инженера ",
        "07-27": "День Военно-Морского Флота 🇷🇺",
        "07-28": "День Крещения Руси ✝",
        "08-01": "День Тыла Вооруженных Сил РФ 🎖",
        "08-02": "День ВДВ 🇷🇺",
        "08-06": "День Железнодорожных войск ",
        "08-09": "День воинской славы России ",
        "08-12": "День ВВС ",
        "08-15": "День археологии ",
        "08-22": "День Государственного флага РФ 🇷🇺",
        "08-27": "День российского кино ",
        "09-01": "День знаний ",
        "09-03": "День солидарности в борьбе с терроризмом ",
        "09-08": "День финансиста ",
        "09-11": "День воинской славы России 🎖",
        "09-13": "День программиста ",
        "09-19": "День оружейника ",
        "09-21": "День победы в Куликовской битве ",
        "09-27": "День воспитателя ",
        "10-01": "День пожилых людей ",
        "10-04": "День космических войск ",
        "10-05": "День учителя ",
        "10-20": "День военного связиста ",
        "10-24": "День подразделений спецназа ",
        "10-25": "День таможенника ",
        "10-29": "День вневедомственной охраны ",
        "10-30": "День инженера-механика 🔧",
        "10-31": "Хэллоуин ",
        "11-04": "День народного единства ",
        "11-07": "День воинской славы России 🎖",
        "11-10": "День сотрудника органов внутренних дел ",
        "11-19": "День ракетных войск и артиллерии ",
        "11-21": "День бухгалтера ",
        "11-27": "День морской пехоты ",
        "12-01": "Остался месяц до Н.Г",
        "12-03": "День юриста ",
        "12-09": "День Героев Отечества ",
        "12-12": "День Конституции РФ ",
        "12-17": "День РВСН ",
        "12-20": "День работника органов безопасности ",
        "12-22": "День энергетика ",
        "12-24": "День воинской славы России 🎖",
        "12-25": "Католическое Рождество ",
        "12-27": "День спасателя "
    };

    function getHolidayText() {
        const t = hmSensor.createSensor(hmSensor.id.TIME);
        const m = String(t.month).padStart(2, '0');
        const d = String(t.day).padStart(2, '0');
        return HOLIDAYS[`${m}-${d}`] || 'Обычный день';
    }

    const COLOR_HOLIDAY = 0xffff0000;
    const COLOR_NORMAL = 0xffcc0000;

    // ======================================================
// ==================== WIDGET VARS ======================
// ======================================================

let normal_background_bg_img = '';
let normal_system_disconnect_img = '';
let normal_image_img_2 = '';
let normal_battery_text_text_img = '';
let normal_battery_text_separator_img = '';
let normal_step_current_text_img = '';
let normal_step_current_separator_img = '';
let normal_heart_rate_text_text_img = '';
let normal_heart_rate_text_separator_img = '';
let normal_altimeter_text_text_img = '';
let normal_altimeter_text_separator_img = '';
let normal_image_img = '';
let normal_weather_image_progress_img_level = '';
let normal_temperature_current_text_img = '';
let normal_date_img_date_month_img = '';
let normal_date_img_date_day = '';
let normal_date_img_date_week_img = '';
let normal_calorie_current_text_img = '';
let normal_calorie_current_separator_img = '';
let normal_humidity_text_text_img = '';
let normal_humidity_text_separator_img = '';
let normal_digital_clock_img_time = '';
let idle_digital_clock_img_time = '';
let image_top_img = '';

// sleep block
let normal_sleep_icon_img = '';
let normal_sleep_score_font = '';
let normal_wakeup_count_font = '';
let normal_wakeup_time_font = '';
let normal_sleep_time_font = '';
let normal_sleep_duration_total_font = '';
let normal_sleep_end_font = '';
let normal_sleep_start_font = '';
let normal_widget_text_1 = '';
let normal_widget_text_2 = '';
let normal_widget_text_3 = '';
let normal_widget_text_4 = '';
let normal_widget_text_5 = '';
let normal_widget_text_6 = '';

// buttons
let Button_sleep = '';
let Button_1 = '';
let Button_2 = '';
let Button_3 = '';

// sensors / state
let timeSensor = '';
let sleepSensor = '';
let visible = false;
let sleepHideTimer = null;  // Таймер для автоматического скрытия блока сна

// ======================================================
// ================= HELPER FUNCTIONS ===================
// ======================================================

function setWidgetVisible(widget, state) {
    if (widget) {
        widget.setProperty(hmUI.prop.VISIBLE, state);
    }
}

function applySleepVisibility() {
    setWidgetVisible(normal_sleep_icon_img, visible);
    setWidgetVisible(normal_sleep_score_font, visible);
    setWidgetVisible(normal_wakeup_count_font, visible);
    setWidgetVisible(normal_wakeup_time_font, visible);
    setWidgetVisible(normal_sleep_time_font, visible);
    setWidgetVisible(normal_sleep_duration_total_font, visible);
    setWidgetVisible(normal_sleep_end_font, visible);
    setWidgetVisible(normal_sleep_start_font, visible);
    setWidgetVisible(normal_widget_text_1, visible);
    setWidgetVisible(normal_widget_text_2, visible);
    setWidgetVisible(normal_widget_text_3, visible);
    setWidgetVisible(normal_widget_text_4, visible);
    setWidgetVisible(normal_widget_text_5, visible);
    setWidgetVisible(normal_widget_text_6, visible);
}

function startSleepHideTimer() {
    // Сбрасываем предыдущий таймер, если он был
    if (sleepHideTimer !== null) {
        clearTimeout(sleepHideTimer);
    }
    
    // Устанавливаем новый таймер на 15 секунд
    sleepHideTimer = setTimeout(function() {
        if (visible) {
            visible = false;
            applySleepVisibility();
        }
        sleepHideTimer = null;
    }, 6000); // 6 секунд
}

function toggleSleepVisibility() {
    visible = !visible;
    applySleepVisibility();
    
    // Если блок сна стал видимым, запускаем таймер на скрытие
    if (visible) {
        startSleepHideTimer();
    } else {
        // Если блок сна скрыли вручную, отменяем таймер
        if (sleepHideTimer !== null) {
            clearTimeout(sleepHideTimer);
            sleepHideTimer = null;
        }
    }
}

    function formatMinutesToTime(totalMinutes, is24Hour) {
        let minutes = totalMinutes;
        if (minutes >= 24 * 60) minutes -= 24 * 60;

        let hour = Math.floor(minutes / 60);
        const minute = minutes % 60;

        let suffix = '';
        if (!is24Hour) {
            suffix = Math.floor(minutes / 60) > 11 ? ' pm' : ' am';
            if (hour >= 12) hour -= 12;
            if (hour === 0) hour = 12;
        }

        return `${hour}:${String(minute).padStart(2, '0')}${suffix}`;
    }

    function formatDuration(minutes) {
        const h = Math.floor(minutes / 60);
        const m = minutes % 60;
        return `${h}:${String(m).padStart(2, '0')}`;
    }

    // ======================================================
    // ===================== WATCHFACE =======================
    // ======================================================

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
        init_view() {
            // фон
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                src: 'bg.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // калории
            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                x: 61,
                y: 165,
                font_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
                padding: false,
                h_space: 0,
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.CAL,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
                x: 25,
                y: 161,
                src: 'dist.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // влажность
            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                x: 329,
                y: 165,
                font_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'icon_2.png',
                unit_tc: 'icon_2.png',
                unit_en: 'icon_2.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.HUMIDITY,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
                x: 407,
                y: 159,
                src: 'vla.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // давление
            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                x: 320,
                y: 120,
                font_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
                padding: false,
                h_space: 0,
                align_h: hmUI.align.LEFT,
                type: hmUI.data_type.ALTIMETER,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const barometer = new AdvancedBarometer({
                widget: normal_altimeter_text_text_img,
            });

            normal_altimeter_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
                x: 400,
                y: 117,
                src: 'atm.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // disconnect
            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                x: 375,
                y: 240,
                src: '0500.png',
                type: hmUI.system_status.DISCONNECT,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // alarm
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                x: 70,
                y: 246,
                font_array: ["bell_71.png","bell_72.png","bell_73.png","bell_74.png","bell_75.png","bell_76.png","bell_77.png","bell_78.png","bell_79.png","bell_80.png"],
                padding: true,
                h_space: 0,
                dot_image: 'bell_70.png',
                invalid_image: 'bell_81.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.ALARM_CLOCK,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // иконка настроек
            normal_image_img_2 = hmUI.createWidget(hmUI.widget.IMG, {
                x: 65,
                y: 350,
                src: 'set.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_image_img_2.setAlpha(200);

            // батарея
            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                x: 203,
                y: 430,
                font_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'icon_2.png',
                unit_tc: 'icon_2.png',
                unit_en: 'icon_2.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.BATTERY,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
                x: 180,
                y: 428,
                src: 'zar.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // шаги
            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                x: 50,
                y: 205,
                font_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
                padding: false,
                h_space: 0,
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.STEP,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
                x: 10,
                y: 203,
                src: 'step.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // пульс
            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                x: 72,
                y: 120,
                font_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
                padding: false,
                h_space: 0,
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.HEART,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
                x: 38,
                y: 117,
                src: 'puls.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // декор
            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 230,
                src: 'image.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // погода
            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                x: 409,
                y: 190,
                image_array: ["clima_1.png","clima_2.png","clima_3.png","clima_4.png","clima_5.png","clima_6.png","clima_7.png","clima_8.png","clima_9.png","clima_10.png","clima_11.png","clima_12.png","clima_13.png","clima_14.png","clima_15.png","clima_16.png","clima_17.png","clima_18.png","clima_19.png","clima_20.png","clima_21.png","clima_22.png","clima_23.png","clima_24.png","clima_25.png","clima_26.png","clima_27.png","clima_28.png","clima_29.png"],
                image_length: 29,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                x: 340,
                y: 205,
                font_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'icon_1.png',
                unit_tc: 'icon_1.png',
                unit_en: 'icon_1.png',
                negative_image: 'icon_3.png',
                invalid_image: 'icon_3.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // дата
            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                month_startX: 161,
                month_startY: 234,
                month_sc_array: ["77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png"],
                month_tc_array: ["77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png"],
                month_en_array: ["77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png"],
                month_is_character: true,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                day_startX: 150,
                day_startY: 127,
                day_sc_array: ["148.png","149.png","150.png","151.png","152.png","153.png","154.png","155.png","156.png","157.png"],
                day_tc_array: ["148.png","149.png","150.png","151.png","152.png","153.png","154.png","155.png","156.png","157.png"],
                day_en_array: ["148.png","149.png","150.png","151.png","152.png","153.png","154.png","155.png","156.png","157.png"],
                day_zero: 0,
                day_space: 0,
                day_align: hmUI.align.CENTER_H,
                day_is_character: false,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                x: 133,
                y: 85,
                week_en: ["89.png","90.png","91.png","92.png","93.png","94.png","95.png"],
                week_tc: ["89.png","90.png","91.png","92.png","93.png","94.png","95.png"],
                week_sc: ["89.png","90.png","91.png","92.png","93.png","94.png","95.png"],
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // цифровое время normal
            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                hour_startX: 114,
                hour_startY: 347,
                hour_array: ["6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png"],
                hour_zero: 1,
                hour_space: 0,
                hour_angle: 0,
                hour_unit_sc: '5.png',
                hour_unit_tc: '5.png',
                hour_unit_en: '5.png',
                hour_align: hmUI.align.CENTER_H,

                minute_startX: 0,
                minute_startY: 0,
                minute_array: ["6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png"],
                minute_zero: 1,
                minute_space: 0,
                minute_angle: 0,
                minute_follow: 1,
                minute_align: hmUI.align.CENTER_H,

                second_startX: 367,
                second_startY: 347,
                second_array: ["16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png"],
                second_zero: 1,
                second_space: 0,
                second_angle: 0,
                second_follow: 0,
                second_align: hmUI.align.LEFT,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_digital_clock_img_time.setAlpha(230);

            // AOD
            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                hour_startX: 39,
                hour_startY: 173,
                hour_array: ["148.png","149.png","150.png","151.png","152.png","153.png","154.png","155.png","156.png","157.png"],
                hour_zero: 1,
                hour_space: 0,
                hour_angle: 0,
                hour_unit_sc: '158.png',
                hour_unit_tc: '158.png',
                hour_unit_en: '158.png',
                hour_align: hmUI.align.CENTER_H,

                minute_startX: 249,
                minute_startY: 245,
                minute_array: ["148.png","149.png","150.png","151.png","152.png","153.png","154.png","155.png","156.png","157.png"],
                minute_zero: 1,
                minute_space: 0,
                minute_angle: 0,
                minute_follow: 1,
                minute_align: hmUI.align.CENTER_H,

                show_level: hmUI.show_level.ONLY_AOD,
            });

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 31,
                src: 'pol.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // праздник
            const holidayText = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 0,
                y: 275,
                w: 466,
                h: 40,
                color: COLOR_NORMAL,
                text_size: 24,
                font: 'fonts/akziden_bold.ttf',
                text_style: hmUI.text_style.WRAP,
                align_h: hmUI.align.CENTER_H,
                align_v: hmUI.align.CENTER_V,
                text: getHolidayText(),
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function updateHoliday() {
                const currentHoliday = getHolidayText();
                holidayText.setProperty(hmUI.prop.TEXT, currentHoliday);
                holidayText.setProperty(
                    hmUI.prop.COLOR,
                    currentHoliday === 'Обычный день' ? COLOR_NORMAL : COLOR_HOLIDAY
                );
            }

            // сенсор времени
            if (!timeSensor) {
                timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            }

            // неделя + день года
            function getWeekAndDay() {
                const y = timeSensor.year;
                const m = timeSensor.month;
                const d = timeSensor.day;

                const now = new Date(y, m - 1, d);
                const startOfYear = new Date(y, 0, 1);
                const dayOfYear = Math.round((now - startOfYear) / 86400000) + 1;

                let firstMonday = new Date(y, 0, 1);
                while (firstMonday.getDay() !== 1) {
                    firstMonday.setDate(firstMonday.getDate() + 1);
                }

                let weekNum = 0;
                if (now >= firstMonday) {
                    const diff = Math.floor((now - firstMonday) / 86400000);
                    weekNum = Math.floor(diff / 7) + 1;
                }

                return { week: weekNum, day: dayOfYear };
            }

            const normal_widget_text_week = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 20,
                y: 315,
                w: 233,
                h: 30,
                text_size: 22,
                font: 'fonts/akziden_bold.ttf',
                color: 0xFF282828,
                align_h: hmUI.align.CENTER_H,
                text: '--',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const normal_widget_text_day = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 213,
                y: 315,
                w: 233,
                h: 30,
                text_size: 22,
                font: 'fonts/akziden_bold.ttf',
                color: 0xFF282828,
                align_h: hmUI.align.CENTER_H,
                text: '--',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function updateWeekDay() {
                const data = getWeekAndDay();
                normal_widget_text_week.setProperty(hmUI.prop.TEXT, ' Неделя: ' + data.week);
                normal_widget_text_day.setProperty(hmUI.prop.TEXT, ' День: ' + data.day);
            }

            // ==================================================
            // ================== SLEEP BLOCK ===================
            // ==================================================

            normal_sleep_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                src: 'effect.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_sleep_icon_img.setAlpha(210);

            normal_sleep_score_font = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 159,
                y: 340,
                w: 150,
                h: 30,
                text_size: 20,
                char_space: 0,
                font: 'fonts/akziden_bold.ttf',
                color: 0xFFFFFFFF,
                line_space: 0,
                align_v: hmUI.align.TOP,
                text_style: hmUI.text_style.ELLIPSIS,
                align_h: hmUI.align.CENTER_H,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wakeup_count_font = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 158,
                y: 292,
                w: 150,
                h: 30,
                text_size: 20,
                char_space: 0,
                font: 'fonts/akziden_bold.ttf',
                color: 0xFFFFFFFF,
                line_space: 0,
                align_v: hmUI.align.TOP,
                text_style: hmUI.text_style.ELLIPSIS,
                align_h: hmUI.align.CENTER_H,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wakeup_time_font = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 158,
                y: 242,
                w: 150,
                h: 30,
                text_size: 20,
                char_space: 0,
                font: 'fonts/akziden_bold.ttf',
                color: 0xFFFFFFFF,
                line_space: 0,
                align_v: hmUI.align.TOP,
                text_style: hmUI.text_style.ELLIPSIS,
                align_h: hmUI.align.CENTER_H,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_time_font = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 229,
                y: 182,
                w: 150,
                h: 30,
                text_size: 20,
                char_space: 0,
                font: 'fonts/akziden_bold.ttf',
                color: 0xFFFFFFFF,
                line_space: 0,
                align_v: hmUI.align.TOP,
                text_style: hmUI.text_style.ELLIPSIS,
                align_h: hmUI.align.CENTER_H,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_duration_total_font = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 91,
                y: 182,
                w: 150,
                h: 30,
                text_size: 20,
                char_space: 0,
                font: 'fonts/akziden_bold.ttf',
                color: 0xFFFFFFFF,
                line_space: 0,
                align_v: hmUI.align.TOP,
                text_style: hmUI.text_style.ELLIPSIS,
                align_h: hmUI.align.CENTER_H,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_end_font = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 229,
                y: 123,
                w: 150,
                h: 30,
                text_size: 20,
                char_space: 0,
                font: 'fonts/akziden_bold.ttf',
                color: 0xFFFFFFFF,
                line_space: 0,
                align_v: hmUI.align.TOP,
                text_style: hmUI.text_style.ELLIPSIS,
                align_h: hmUI.align.CENTER_H,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_start_font = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 93,
                y: 123,
                w: 150,
                h: 30,
                text_size: 20,
                char_space: 0,
                font: 'fonts/akziden_bold.ttf',
                color: 0xFFFFFFFF,
                line_space: 0,
                align_v: hmUI.align.TOP,
                text_style: hmUI.text_style.ELLIPSIS,
                align_h: hmUI.align.CENTER_H,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_1 = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 99,
                y: 96,
                w: 150,
                h: 180,
                text_size: 15,
                char_space: 0,
                font: 'fonts/akziden_bold.ttf',
                color: 0xFFE6E6E6,
                line_space: 0,
                align_v: hmUI.align.TOP,
                text_style: hmUI.text_style.ELLIPSIS,
                align_h: hmUI.align.CENTER_H,
                text: 'начало сна',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_2 = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 133,
                y: 271,
                w: 210,
                h: 180,
                text_size: 15,
                char_space: 0,
                font: 'fonts/akziden_bold.ttf',
                color: 0xFFE6E6E6,
                line_space: 0,
                align_v: hmUI.align.TOP,
                text_style: hmUI.text_style.ELLIPSIS,
                align_h: hmUI.align.CENTER_H,
                text: 'число пробуждений',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_3 = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 159,
                y: 320,
                w: 150,
                h: 180,
                text_size: 15,
                char_space: 0,
                font: 'fonts/akziden_bold.ttf',
                color: 0xFFE6E6E6,
                line_space: 0,
                align_v: hmUI.align.TOP,
                text_style: hmUI.text_style.ELLIPSIS,
                align_h: hmUI.align.CENTER_H,
                text: 'баллы',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_4 = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 216,
                y: 96,
                w: 150,
                h: 180,
                text_size: 15,
                char_space: 0,
                font: 'fonts/akziden_bold.ttf',
                color: 0xFFE6E6E6,
                line_space: 0,
                align_v: hmUI.align.TOP,
                text_style: hmUI.text_style.ELLIPSIS,
                align_h: hmUI.align.CENTER_H,
                text: 'конец сна',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_5 = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 162,
                y: 155,
                w: 150,
                h: 180,
                text_size: 15,
                char_space: 0,
                font: 'fonts/akziden_bold.ttf',
                color: 0xFFE6E6E6,
                line_space: 0,
                align_v: hmUI.align.TOP,
                text_style: hmUI.text_style.ELLIPSIS,
                align_h: hmUI.align.CENTER_H,
                text: 'длительность сна',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_6 = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 110,
                y: 215,
                w: 250,
                h: 180,
                text_size: 15,
                char_space: 0,
                font: 'fonts/akziden_bold.ttf',
                color: 0xFFE6E6E6,
                line_space: 0,
                align_v: hmUI.align.TOP,
                text_style: hmUI.text_style.ELLIPSIS,
                align_h: hmUI.align.CENTER_H,
                text: 'длительность пробуждений',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!sleepSensor) {
                sleepSensor = hmSensor.createSensor(hmSensor.id.SLEEP);
            }

            function sleep_update() {
                console.log('sleep_update()');

                const sleepInfo = sleepSensor.getBasicInfo();
                const totalTime = sleepSensor.getTotalTime();
                const modelData = sleepSensor.getSleepStageModel();
                const sleepStageArray = sleepSensor.getSleepStageData();

                let wakeupTime = 0;
                let wakeupCount = 0;

                for (let i = 0; i < sleepStageArray.length; i++) {
                    const data = sleepStageArray[i];
                    if (data.model == modelData.WAKE_STAGE) {
                        wakeupTime += data.stop + 1 - data.start;
                        wakeupCount++;
                    }
                }

                const pureSleepTime = totalTime - wakeupTime;

                if (normal_sleep_score_font) {
                    normal_sleep_score_font.setProperty(hmUI.prop.TEXT, String(sleepInfo.score));
                }

                if (normal_wakeup_count_font) {
                    normal_wakeup_count_font.setProperty(hmUI.prop.TEXT, String(wakeupCount));
                }

                if (normal_wakeup_time_font) {
    normal_wakeup_time_font.setProperty(hmUI.prop.TEXT, formatDuration(wakeupTime));
}


                if (normal_sleep_time_font) {
                    normal_sleep_time_font.setProperty(hmUI.prop.TEXT, formatDuration(pureSleepTime));
                }

                if (normal_sleep_duration_total_font) {
                    normal_sleep_duration_total_font.setProperty(hmUI.prop.TEXT, formatDuration(totalTime));
                }

                if (normal_sleep_end_font) {
                    normal_sleep_end_font.setProperty(
                        hmUI.prop.TEXT,
                        formatMinutesToTime(sleepInfo.endTime, timeSensor.is24Hour)
                    );
                }

                if (normal_sleep_start_font) {
                    normal_sleep_start_font.setProperty(
                        hmUI.prop.TEXT,
                        formatMinutesToTime(sleepInfo.startTime, timeSensor.is24Hour)
                    );
                }
            }

            applySleepVisibility();

            // ==================================================
            // ================== UPDATE DATA ===================
            // ==================================================

            function updateAllData() {
                if (barometer) {
                    barometer.update();
                }
                updateHoliday();
                updateWeekDay();
                sleep_update();
            }

            // ==================================================
            // ==================== BUTTONS =====================
            // ==================================================

            console.log('Watch_Face.Buttons');

            Button_sleep = hmUI.createWidget(hmUI.widget.BUTTON, {
                x: 65,
                y: 350,
                w: 100,
                h: 100,
                text: '',
                text_size: 25,
                press_src: 'Empty.png',
                normal_src: 'Empty.png',
                click_func: () => {
                    toggleSleepVisibility();
                },
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
                x: 180,
                y: 126,
                w: 100,
                h: 100,
                text: '',
                color: 0xFFFF8C00,
                text_size: 25,
                press_src: '0_Empty.png',
                normal_src: '0_Empty.png',
                click_func: () => {
                    hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
                },
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
                x: 46,
                y: 235,
                w: 100,
                h: 40,
                text: '',
                color: 0xFFFF8C00,
                text_size: 25,
                press_src: '0_Empty.png',
                normal_src: '0_Empty.png',
                click_func: () => {
                    hmApp.startApp({ url: 'AlarmInfoScreen', native: true });
                },
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
                x: 182,
                y: 0,
                w: 100,
                h: 70,
                text: '',
                color: 0xFFFF8C00,
                text_size: 25,
                press_src: '0_Empty.png',
                normal_src: '0_Empty.png',
                click_func: () => {
                    hmApp.startApp({ url: 'Settings_homeScreen', native: true });
                },
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // первичное обновление
            updateAllData();

            hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                minute_change_call() {
                    updateAllData();
                },
                resume_call() {
                    updateAllData();
                }
            });
        },

        onInit() {
            logger.log('index page.js on init invoke');
        },

        build() {
            this.init_view();
            logger.log('index page.js on ready invoke');
        },

        onDestroy() {
            logger.log('index page.js on destroy invoke');
        }
    });
})();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}
