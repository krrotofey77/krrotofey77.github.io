﻿try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block
    
        //dynamic modify start
        
        let normal_background_bg_img = ''
        let normal_battery_font = ''
        let normal_battery_current_text_font = ''
        let normal_step_current_text_font = ''
        let normal_heart_rate_text_font = ''
        let normal_month_name_font = ''
        let normal_Month_Array = ['пульс       шаги       погода', 'пульс       шаги       погода', 'пульс       шаги        погода', 'пульс       шаги        погода', 'пульс       шаги       погода', 'пульс       шаги        погода', 'пульс       шаги        погода', 'пульс       шаги        погода', 'пульс       шаги        погода', 'пульс       шаги        погода', 'пульс       шаги        погода', 'пульс       шаги        погода', ];
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['Пoнедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота', 'Воскресенье'];
        let normal_day_month_year_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_time_hour_min_text_font = ''
        let image_top_img = ''
        let Button_1 = ''
        let tempText = null;
        let weatherSensor = null;
        let timeSensor = '';       
        let color1number_main = 1
        let totalcolor1s_main = 16
        let namecolor1_main = ''
        let colorstring = '0xFFFF8000'
        let screenType;
        
        function click_COLOR() {
            if(color1number_main>=totalcolor1s_main) {
            color1number_main=1;
                }
            else {
                color1number_main=color1number_main+1;
            }
            if (color1number_main == 1) {
                namecolor1_main = "цвет 1";
                colorstring = '0xFFFFA500';
            }
            if (color1number_main == 2) {
                namecolor1_main = "цвет 2";
                colorstring = '0xFF00FFFF';
            }
            if (color1number_main == 3) {
                namecolor1_main = "цвет 3";
                colorstring = '0xFFFFFF00';
            }
            if (color1number_main == 4) {
                namecolor1_main = "цвет 4";
                colorstring = '0xFFFF6347';
            }
            if (color1number_main == 5) {
                namecolor1_main = "цвет 5";
                colorstring = '0xFF00FFFF';
            }
            if (color1number_main == 6) {
                namecolor1_main = "цвет 6";
                colorstring = '0xFF90EE90';
            }
            if (color1number_main == 7) {
                namecolor1_main = "цвет 7";
                colorstring = '0xFFFF6347';
            }
            if (color1number_main == 8) {
                namecolor1_main = "цвет 8";
                colorstring = '0xFFFFFF00';
            }
            if (color1number_main == 9) {
                namecolor1_main = "цвет 9";
                colorstring = '0xFF9ACD32';
            }
            if (color1number_main == 10) {
                namecolor1_main = "цвет 10";
                colorstring = '0xFFD8BFD8';
            }
            if (color1number_main == 11) {
                namecolor1_main = "цвет 11";
                colorstring = '0xFF87CEEB';
            }
            if (color1number_main == 12) {
                namecolor1_main = "цвет 12";
                colorstring = '0xFFFF69B4';
            }
            if (color1number_main == 13) {
                namecolor1_main = "цвет 13";
                colorstring = '0xFFD2B48C';
            }
            if (color1number_main == 14) {
                namecolor1_main = "цвет 14";
                colorstring = '0xFFFFD700';
            }
            if (color1number_main == 15) {
                namecolor1_main = "цвет 15";
                colorstring = '0xFFD3D3D3';
            }
            if (color1number_main == 16) {
                namecolor1_main = "цвет 16";
                colorstring = '0xFFFFFFFF';
            }
    
            if (color1number_main <= 16) { 
                normal_battery_font.setProperty(hmUI.prop.MORE, {
                    x: 148,
                    y: 375,
                    w: 210,
                    h: 50,            
                    text: 'Батарея',
                    text_size: 40,
                    color: parseInt(colorstring),
                    font: 'fonts/wfs_2984_fontotf_dd9c13df_33dd_459e_98da_32422a744495.ttf',
                });
    
                normal_battery_current_text_font.setProperty(hmUI.prop.MORE, {
                    x: 167,
                    y: 430,
                    w: 150,
                    h: 30,
                    text_size: 30,
                    char_space: 0,
                    font: 'fonts/wfs_5by7_33186ca3_d6c9_4dde_a4de_baeb63209d39.ttf',
                    color: parseInt(colorstring),
                    line_space: 0,
                    align_v: hmUI.align.TOP,
                    text_style: hmUI.text_style.ELLIPSIS,
                    align_h: hmUI.align.CENTER_H,
                    unit_type: 1,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                normal_step_current_text_font.setProperty(hmUI.prop.MORE, {
                    x: 154,
                    y: 340,
                    w: 150,
                    h: 30,
                    text_size: 25,
                    char_space: 0,
                    font: 'fonts/wfs_2984_fontotf_dd9c13df_33dd_459e_98da_32422a744495.ttf',
                    color: parseInt(colorstring),
                    line_space: 0,
                    align_v: hmUI.align.TOP,
                    text_style: hmUI.text_style.ELLIPSIS,
                    align_h: hmUI.align.CENTER_H,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                normal_heart_rate_text_font.setProperty(hmUI.prop.MORE, {
                    x: 16,
                    y: 340,
                    w: 150,
                    h: 30,
                    text_size: 25,
                    char_space: 0,
                    font: 'fonts/wfs_2984_fontotf_dd9c13df_33dd_459e_98da_32422a744495.ttf',
                    color: parseInt(colorstring),
                    line_space: 0,
                    align_v: hmUI.align.TOP,
                    text_style: hmUI.text_style.ELLIPSIS,
                    align_h: hmUI.align.CENTER_H,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                
                normal_month_name_font.setProperty(hmUI.prop.MORE, {
                    x: 13,
                    y: 311,
                    w: 466,
                    h: 30,
                    text_size: 20,
                    char_space: 0,
                    font: 'fonts/wfs_2984_fontotf_dd9c13df_33dd_459e_98da_32422a744495.ttf',
                    color: parseInt(colorstring),
                    line_space: 0,
                    align_v: hmUI.align.TOP,
                    text_style: hmUI.text_style.ELLIPSIS,
                    align_h: hmUI.align.CENTER_H,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                normal_dow_text_font.setProperty(hmUI.prop.MORE, {
                    x: 80,
                    y: 63,
                    w: 310,
                    h: 50,
                    text_size: 45,
                    char_space: 0,
                    font: 'fonts/wfs_2984_fontotf_dd9c13df_33dd_459e_98da_32422a744495.ttf',
                    color: parseInt(colorstring),
                    line_space: 0,
                    align_v: hmUI.align.TOP,
                    text_style: hmUI.text_style.ELLIPSIS,
                    align_h: hmUI.align.CENTER_H,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                
                normal_day_month_year_font.setProperty(hmUI.prop.MORE, {
                    x: 131,
                    y: 116,
                    w: 210,
                    h: 50,
                    text_size: 40,
                    char_space: 0,
                    font: 'fonts/wfs_5by7_33186ca3_d6c9_4dde_a4de_baeb63209d39.ttf',
                    color: parseInt(colorstring),
                    line_space: 0,
                    align_v: hmUI.align.TOP,
                    text_style: hmUI.text_style.ELLIPSIS,
                    align_h: hmUI.align.CENTER_H,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                normal_time_hour_min_text_font.setProperty(hmUI.prop.MORE, {
                    x: 7,
                    y: 174,
                    w: 466,
                    h: 120,
                    text_size: 140,
                    char_space: 0,
                    font: 'fonts/wfs_2984_fontotf_dd9c13df_33dd_459e_98da_32422a744495.ttf',
                    color: parseInt(colorstring),
                    line_space: 0,
                    align_v: hmUI.align.TOP,
                    text_style: hmUI.text_style.ELLIPSIS,
                    align_h: hmUI.align.CENTER_H,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                tempText.setProperty(hmUI.prop.MORE, {
                    w: 150, 
                    x: 302,
                    y: 340,
                    h: 30,
                    text_size: 25,
                    font: 'fonts/wfs_2984_fontotf_dd9c13df_33dd_459e_98da_32422a744495.ttf',
                    color: parseInt(colorstring),
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.TOP,
                    text: "--°C",
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                updateTemperature();
            }
            hmUI.showToast({text: namecolor1_main });
        }	
    
        function updateTemperature() {
            if (!weatherSensor) return;
            let temp = weatherSensor.current;
            if (typeof temp !== "number") {
                tempText.setProperty(hmUI.prop.TEXT, "--°C");
                return;
            }
            let formattedTemp = (temp > 0 ? "+" + temp : temp) + "°C";
            tempText.setProperty(hmUI.prop.TEXT, formattedTemp);
        }
    
        // Исправленная структура WatchFace
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                logger.log('index page.js on ready invoke');
                
                // Инициализация сенсоров
                timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
                screenType = hmSetting.getScreenType();
                
                // Создание виджетов
                console.log('Watch_Face.ScreenNormal');
                
                // Фоновое изображение
                normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    src: 'wfs_wh_aeddce8b_4d04_4e90_a78f_4264e0242466.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                // Текст погоды
                tempText = hmUI.createWidget(hmUI.widget.TEXT, {
                    w: 150, 
                    x: 302,
                    y: 340,
                    h: 30,
                    text_size: 25,
                    font: 'fonts/wfs_2984_fontotf_dd9c13df_33dd_459e_98da_32422a744495.ttf',
                    color: 0xFFFF8C00,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.TOP,
                    text: "--°C",
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                // Батарея (текст)
                normal_battery_font = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 148,
                    y: 375,
                    w: 210,
                    h: 50,            
                    text: 'Батарея',
                    text_size: 40,
                    color: 0xFFFF8C00,
                    font: 'fonts/wfs_2984_fontotf_dd9c13df_33dd_459e_98da_32422a744495.ttf',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                // Батарея (значение)
                normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                    x: 167,
                    y: 430,
                    w: 150,
                    h: 30,
                    text_size: 30,
                    char_space: 0,
                    font: 'fonts/wfs_5by7_33186ca3_d6c9_4dde_a4de_baeb63209d39.ttf',
                    color: 0xFFFF8C00,
                    line_space: 0,
                    align_v: hmUI.align.TOP,
                    text_style: hmUI.text_style.ELLIPSIS,
                    align_h: hmUI.align.CENTER_H,
                    unit_type: 1,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                // Шаги
                normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                    x: 154,
                    y: 340,
                    w: 150,
                    h: 30,
                    text_size: 25,
                    char_space: 0,
                    font: 'fonts/wfs_2984_fontotf_dd9c13df_33dd_459e_98da_32422a744495.ttf',
                    color: 0xFFFF8C00,
                    line_space: 0,
                    align_v: hmUI.align.TOP,
                    text_style: hmUI.text_style.ELLIPSIS,
                    align_h: hmUI.align.CENTER_H,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                // Пульс
                normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                    x: 16,
                    y: 340,
                    w: 150,
                    h: 30,
                    text_size: 25,
                    char_space: 0,
                    font: 'fonts/wfs_2984_fontotf_dd9c13df_33dd_459e_98da_32422a744495.ttf',
                    color: 0xFFFF8C00,
                    line_space: 0,
                    align_v: hmUI.align.TOP,
                    text_style: hmUI.text_style.ELLIPSIS,
                    align_h: hmUI.align.CENTER_H,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                // Название месяца
                normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 13,
                    y: 311,
                    w: 466,
                    h: 30,
                    text_size: 20,
                    char_space: 0,
                    font: 'fonts/wfs_2984_fontotf_dd9c13df_33dd_459e_98da_32422a744495.ttf',
                    color: 0xFFFF8C00,
                    line_space: 0,
                    align_v: hmUI.align.TOP,
                    text_style: hmUI.text_style.ELLIPSIS,
                    align_h: hmUI.align.CENTER_H,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                // День недели
                normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 80,
                    y: 63,
                    w: 310,
                    h: 50,
                    text_size: 45,
                    char_space: 0,
                    font: 'fonts/wfs_2984_fontotf_dd9c13df_33dd_459e_98da_32422a744495.ttf',
                    color: 0xFFFF8C00,
                    line_space: 0,
                    align_v: hmUI.align.TOP,
                    text_style: hmUI.text_style.ELLIPSIS,
                    align_h: hmUI.align.CENTER_H,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                // Дата
                normal_day_month_year_font = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 131,
                    y: 116,
                    w: 210,
                    h: 50,
                    text_size: 40,
                    char_space: 0,
                    font: 'fonts/wfs_5by7_33186ca3_d6c9_4dde_a4de_baeb63209d39.ttf',
                    color: 0xFFFF8C00,
                    line_space: 0,
                    align_v: hmUI.align.TOP,
                    text_style: hmUI.text_style.ELLIPSIS,
                    align_h: hmUI.align.CENTER_H,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                // Время (часы:минуты)
                normal_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 7,
                    y: 174,
                    w: 466,
                    h: 120,
                    text_size: 140,
                    char_space: 0,
                    font: 'fonts/wfs_2984_fontotf_dd9c13df_33dd_459e_98da_32422a744495.ttf',
                    color: 0xFFFF8C00,
                    line_space: 0,
                    align_v: hmUI.align.TOP,
                    text_style: hmUI.text_style.ELLIPSIS,
                    align_h: hmUI.align.CENTER_H,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                // Верхнее изображение
                console.log('Watch_Face.ScreenAOD');
                image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    src: 'style_wfs_4c94bc31_8ae4_4a38_8db2_a9191490d18b_0.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                // Кнопка смены цвета
                console.log('Watch_Face.Buttons');
                Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
                    x: 183,
                    y: 183,
                    w: 100,
                    h: 100,
                    text: '',
                    color: 0xFFFF8C00,
                    text_size: 25,
                    press_src: 'wfs_wfs_tops3_5adb317d_83dc_4679_9338_024990d218d51754703861197_trimmed_8de380cf_3e55_4955_be9e_98a2d6003eb8.png',
                    normal_src: 'wfs_wfs_tops3_5adb317d_83dc_4679_9338_024990d218d51754703861197_trimmed_8de380cf_3e55_4955_be9e_98a2d6003eb8.png',
                    click_func: click_COLOR,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                // Событие смены дня
                timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
                    updateTemperature();
                    time_update(true, true);
                });
    
                // Виджет делегат для управления таймером
                const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function() {
                        console.log('resume_call()');
                        updateTemperature();
                        time_update(true, true);
                        
                        if (screenType == hmSetting.screen_type.WATCHFACE) {
                            if (!normal_timerTimeUpdate) {
                                normal_timerTimeUpdate = timer.createTimer(0, 1000, function() {
                                    let updateHour = timeSensor.minute == 0;
                                    let updateMinute = timeSensor.second < 2;
                                    time_update(updateHour, updateMinute);
                                });
                            }
                        }
                    },
                    pause_call: function() {
                        console.log('pause_call()');
                        if (normal_timerTimeUpdate) {
                            timer.stopTimer(normal_timerTimeUpdate);
                            normal_timerTimeUpdate = undefined;
                        }
                    }
                });
    
                // Функция обновления времени
                function time_update(updateHour = false, updateMinute = false) {
                    console.log('time_update()');
                    
                    if (updateHour) {
                        // Обновление месяца
                        let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                        normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str);
                        
                        // Обновление дня недели
                        let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                        normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str);
                        
                        // Обновление даты
                        let normal_DayStr = timeSensor.day.toString().padStart(2, '0');
                        let normal_MonthStr = timeSensor.month.toString().padStart(2, '0');
                        let normal_YearStr = (timeSensor.year % 100).toString();
                        
                        let normal_DayMonthYearStr = '--';
                        const dateFormat = hmSetting.getDateFormat();
                        if (dateFormat == 0) {
                            normal_DayMonthYearStr = normal_YearStr + '/' + normal_MonthStr + '/' + normal_DayStr;
                        } else if (dateFormat == 1) {
                            normal_DayMonthYearStr = normal_DayStr + '/' + normal_MonthStr + '/' + normal_YearStr;
                        } else if (dateFormat == 2) {
                            normal_DayMonthYearStr = normal_MonthStr + '/' + normal_DayStr + '/' + normal_YearStr;
                        }
                        normal_day_month_year_font.setProperty(hmUI.prop.TEXT, normal_DayMonthYearStr);
                    }
    
                    if (updateMinute) {
                        // Обновление времени
                        let normal_HourMinStr = timeSensor.format_hour.toString().padStart(2, '0');
                        normal_HourMinStr = normal_HourMinStr + ':' + timeSensor.minute.toString().padStart(2, '0');
                        normal_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, normal_HourMinStr);
                    }
                }
    
                // Тестовые виджеты для отображения шрифтов (можно закомментировать)
                // ... (оставьте тестовые виджеты если нужно)
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
    })();
    } catch (e) {
        console.log('Mini Program Error', e);
        e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    }