/*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
*/

try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const { px } = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');

        // Чтение данных о давлении
        function read_pressure() {
            logger.log("read_pressure()");
            const file_name_alt = "../../../baro_altim/pressure.dat";
            if (typeof hmFS === 'undefined') {
                logger.log('hmFS is not available');
                return null;
            }
            const [fs_stat, err] = hmFS.stat(file_name_alt);
            if (err !== 0) {
                logger.log('File stat error:', err);
                return null;
            }

            const file_size = fs_stat.size;
            const len = file_size / 4;
            logger.log(`size_alt: ${file_size}, length: ${len}`);

            const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY);
            if (!fh) {
                logger.log('Failed to open file');
                return null;
            }

            let array_buffer = new Float32Array(len);
            const bytesRead = hmFS.read(fh, array_buffer.buffer, 0, file_size);
            hmFS.close(fh);

            if (bytesRead !== file_size) {
                logger.log('Read error: incomplete data');
                return null;
            }

            logger.log(`value ${array_buffer[array_buffer.length - 1]}`);
            return array_buffer;
        }

        // Получение значения давления
        function getPressureValue(pressure_array) {
            logger.log("getPressureValue()");
            if (!pressure_array || pressure_array.length === 0) return 0;
            let start_index = pressure_array.length - 1;
            let end_index = Math.max(0, start_index - 30 * 3); // 3 часа
            for (let index = start_index; index >= end_index; index--) {
                if (pressure_array[index] !== 0) return parseInt(pressure_array[index] / 100);
            }
            return 0;
        }

        // Вычисление изменения давления
        function changesPressure(pressure_array) {
            logger.log("changesPressure()");
            if (!pressure_array || pressure_array.length === 0) return 0;
            let start_index = pressure_array.length - 1;
            let end_index = Math.max(0, start_index - 30 * 3); // 3 часа
            let value = pressure_array[start_index];
            for (let index = start_index; index >= end_index; index--) {
                let element = pressure_array[index];
                if (element !== 0 && Math.abs(value - element) > 10) { // разница > 0.1 гПа
                    return value - element;
                }
            }
            return 0;
        }

        // Перевод гПа в мм рт. ст.
        function hPa_To_mmHg(hPa_value = 0) {
            return Math.round(hPa_value * 0.750064);
        }

        // Объявление виджетов
        let text_pressere; // Давление
        let text_pressere_changes; // Изменение давления
        let normal_background_bg_img;
        let normal_calorie_icon_img;
        let normal_distance_icon_img;
        let normal_distance_current_text_font;
        let normal_system_disconnect_img;
        let normal_image_img;
        let normal_step_icon_img;
        let normal_step_current_text_font;
        let normal_heart_rate_icon_img;
        let normal_heart_rate_text_font;
        let normal_wind_icon_img;
        let normal_wind_direction_image_progress_img_level;
        let normal_wind_current_text_font;
        let normal_humidity_icon_img;
        let normal_humidity_current_text_font;
        let normal_month_name_font;
        let normal_day_text_font;
        let normal_group_ForecastWeather;
        let normal_forecast_date_week_font = new Array(7);
        let normal_forecast_average_text_font = new Array(7);
        let normal_forecast_image_progress_img_level = new Array(7);
        let normal_forecast_icon_img;
        let normal_dow_text_font;
        let normal_weather_image_progress_img_level;
        let normal_temperature_current_text_font;
        let normal_city_name_text;
        let normal_battery_current_text_font;
        let normal_battery_image_progress_img_level;
        let normal_battery_icon_img;
        let normal_time_hour_text_font;
        let normal_time_minute_text_font;
        let normal_time_second_text_font;
        let idle_image_img;
        let idle_time_hour_text_font;
        let idle_time_minute_text_font;
        let image_top_img;
        let btn_zona1;
        let button_1;

        const normal_Month_Array = ['Января', 'Февраля', 'Марта', 'Апреля', 'Мая', 'Июня', 'Июля', 'Августа', 'Сентября', 'Октября', 'Ноября', 'Декабря'];
        const normal_DOW_Array = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
        const normal_forecast_date_week_font_Array = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
        const normal_forecast_image_array = ['8.png', '9.png', '10.png', '11.png', '12.png', '13.png', '14.png', '15.png', '16.png', '17.png', '18.png', '19.png', '20.png', '21.png', '22.png', '23.png', '24.png', '25.png', '26.png', '27.png', '28.png', '29.png', '30.png', '31.png', '32.png', '33.png', '34.png', '35.png', '36.png'];

        let timeSensor;
        let weather_day;
        let normal_timerTimeUpdate;
        let idle_timerTimeUpdate;
        let zona1_num = 0;
        const zona1_all = 1;

        // Переключение отображаемых данных
        function click_zona1() {
            zona1_num = (zona1_num + 1) % (zona1_all + 1);
            if (zona1_num === 0) {
                if (normal_distance_icon_img) normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                if (normal_distance_current_text_font) normal_distance_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
                if (normal_step_icon_img) normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                if (normal_step_current_text_font) normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
                if (normal_heart_rate_icon_img) normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                if (normal_heart_rate_text_font) normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, true);
                if (normal_calorie_icon_img) normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                if (text_pressere) text_pressere.setProperty(hmUI.prop.VISIBLE, false);
                if (text_pressere_changes) text_pressere_changes.setProperty(hmUI.prop.VISIBLE, false);
            } else if (zona1_num === 1) {
                if (normal_distance_icon_img) normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                if (normal_distance_current_text_font) normal_distance_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
                if (normal_step_icon_img) normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                if (normal_step_current_text_font) normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
                if (normal_heart_rate_icon_img) normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                if (normal_heart_rate_text_font) normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, false);
                if (normal_calorie_icon_img) normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                if (text_pressere) text_pressere.setProperty(hmUI.prop.VISIBLE, true);
                if (text_pressere_changes) text_pressere_changes.setProperty(hmUI.prop.VISIBLE, true);
            }
        }

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                // Фон
                normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    src: '1.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                // Иконки и данные
                normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 164,
                    y: 368,
                    src: '55.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_calorie_icon_img.setAlpha(220);

                normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 162,
                    y: 365,
                    src: '54.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_distance_icon_img.setAlpha(220);

                normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                    x: 182,
                    y: 361,
                    w: 150,
                    h: 30,
                    text_size: 28,
                    font: 'fonts/alex.ttf',
                    color: 0xFFE1E1E1,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.TOP,
                    unit_type: 1,
                    text_style: hmUI.text_style.ELLIPSIS,
                    type: hmUI.data_type.DISTANCE,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 6,
                    y: 239,
                    src: '2.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_system_disconnect_img.setAlpha(220);

                normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 224,
                    y: 82,
                    src: '46.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 238,
                    y: 403,
                    src: '4.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_step_icon_img.setAlpha(220);

                normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                    x: 244,
                    y: 400,
                    w: 150,
                    h: 30,
                    text_size: 30,
                    font: 'fonts/alex.ttf',
                    color: 0xFFE1E1E1,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.TOP,
                    text_style: hmUI.text_style.ELLIPSIS,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 103,
                    y: 403,
                    src: '3.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_heart_rate_icon_img.setAlpha(220);

                normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                    x: 104,
                    y: 400,
                    w: 150,
                    h: 30,
                    text_size: 30,
                    font: 'fonts/alex.ttf',
                    color: 0xFFE1E1E1,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.TOP,
                    text_style: hmUI.text_style.ELLIPSIS,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                normal_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 162,
                    y: 184,
                    src: '5.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 220,
                    y: 189,
                    image_array: ["38.png", "39.png", "40.png", "41.png", "42.png", "43.png", "44.png", "45.png"],
                    image_length: 8,
                    type: hmUI.data_type.WIND_DIRECTION,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                normal_wind_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                    x: 131,
                    y: 187,
                    w: 150,
                    h: 30,
                    text_size: 22,
                    font: 'fonts/alex.ttf',
                    color: 0xFFFFFFFF,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.TOP,
                    text_style: hmUI.text_style.ELLIPSIS,
                    type: hmUI.data_type.WIND,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                normal_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 69,
                    y: 184,
                    src: '6.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                normal_humidity_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                    x: 45,
                    y: 187,
                    w: 150,
                    h: 30,
                    text_size: 22,
                    font: 'fonts/alex.ttf',
                    color: 0xFFFFFFFF,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.TOP,
                    unit_type: 1,
                    text_style: hmUI.text_style.ELLIPSIS,
                    type: hmUI.data_type.HUMIDITY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                // Датчик времени
                if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                timeSensor.addEventListener(timeSensor.event.DAYCHANGE, () => time_update(true));

                normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 283,
                    y: 215,
                    w: 110,
                    h: 45,
                    text_size: 28,
                    char_space: -1,
                    font: 'fonts/alex.ttf',
                    color: 0xFFFBFBFB,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.TOP,
                    text_style: hmUI.text_style.ELLIPSIS,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 265,
                    y: 180,
                    w: 150,
                    h: 30,
                    text_size: 30,
                    font: 'fonts/alex.ttf',
                    color: 0xFFFFFFFF,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.TOP,
                    text_style: hmUI.text_style.ELLIPSIS,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                text_pressere = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 175,
                    y: 366,
                    w: 150,
                    h: 30,
                    text_size: 30,
                    font: 'fonts/alex.ttf',
                    color: 0xFFE1E1E1,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.TOP,
                    text_style: hmUI.text_style.ELLIPSIS,
                    text: "--",
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                text_pressere_changes = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 108,
                    y: 405,
                    w: 250,
                    h: 30,
                    text_size: 29,
                    font: 'fonts/alex.ttf',
                    color: 0xFFE1E1E1,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    text_style: hmUI.text_style.NONE,
                    text: "--",
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                const screenType = hmSetting.getScreenType();
                normal_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
                    x: 0,
                    y: 0,
                    h: 0,
                    w: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                if (screenType === hmSetting.screen_type.WATCHFACE) {
                    for (let i = 0; i < 7; i++) {
                        normal_forecast_date_week_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                            x: 8 + i * 50,
                            y: 254,
                            w: 150,
                            h: 30,
                            text_size: 23,
                            font: 'fonts/alex.ttf',
                            color: 0xFFA0A0A0,
                            align_h: hmUI.align.CENTER_H,
                            align_v: hmUI.align.TOP,
                            text_style: hmUI.text_style.ELLIPSIS,
                            show_level: hmUI.show_level.ONLY_NORMAL
                        });

                        normal_forecast_average_text_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                            x: 5 + i * 50,
                            y: 321,
                            w: 150,
                            h: 30,
                            text_size: 23,
                            font: 'fonts/alex.ttf',
                            color: 0xFFA0A0A0,
                            align_h: hmUI.align.CENTER_H,
                            align_v: hmUI.align.TOP,
                            text_style: hmUI.text_style.ELLIPSIS,
                            show_level: hmUI.show_level.ONLY_NORMAL
                        });

                        normal_forecast_image_progress_img_level[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                            x: 63 + i * 50,
                            y: 282,
                            src: normal_forecast_image_array[25],
                            show_level: hmUI.show_level.ONLY_NORMAL
                        });
                    }

                    normal_forecast_icon_img = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                        x: 55,
                        y: 249,
                        src: '37.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                }

                normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 8,
                    y: 254,
                    w: 150,
                    h: 30,
                    text_size: 23,
                    font: 'fonts/alex.ttf',
                    color: 0xFFFFFFFF,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.TOP,
                    text_style: hmUI.text_style.ELLIPSIS,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 63,
                    y: 282,
                    image_array: normal_forecast_image_array,
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                weather_day = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 33,
                    y: 212,
                    w: 255,
                    h: 45,
                    text_size: 24,
                    char_space: -1,
                    font: 'fonts/alex.ttf',
                    color: 0xFFFBFBFB,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    text_style: hmUI.text_style.ELLIPSIS,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                    x: 5,
                    y: 321,
                    w: 150,
                    h: 30,
                    text_size: 23,
                    font: 'fonts/alex.ttf',
                    color: 0xFFFFFFFF,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.TOP,
                    text_style: hmUI.text_style.ELLIPSIS,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 83,
                    y: 156,
                    w: 300,
                    h: 30,
                    text_size: 20,
                    font: 'fonts/alex.ttf',
                    color: 0xFFFFFFFF,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.TOP,
                    text_style: hmUI.text_style.ELLIPSIS,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                    x: 179,
                    y: 36,
                    w: 150,
                    h: 30,
                    text_size: 25,
                    font: 'fonts/alex.ttf',
                    color: 0xFFE1E1E1,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.TOP,
                    unit_type: 1,
                    text_style: hmUI.text_style.ELLIPSIS,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 189,
                    y: 44,
                    image_array: ["48.png", "49.png", "50.png", "51.png", "52.png", "53.png"],
                    image_length: 6,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 184,
                    y: 35,
                    src: '7.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal_battery_icon_img.setAlpha(220);

                normal_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 77,
                    y: 50,
                    w: 150,
                    h: 100,
                    text_size: 100,
                    font: 'fonts/albertsans_bold_1d53ecea_cb51_4efe-2.ttf',
                    color: 0xFFFFFFFF,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.TOP,
                    text_style: hmUI.text_style.ELLIPSIS,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                normal_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 240,
                    y: 50,
                    w: 151,
                    h: 100,
                    text_size: 100,
                    font: 'fonts/albertsans_bold_1d53ecea_cb51_4efe-2.ttf',
                    color: 0xFFFFFFFF,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.TOP,
                    text_style: hmUI.text_style.ELLIPSIS,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 330,
                    y: 128,
                    w: 150,
                    h: 30,
                    text_size: 20,
                    font: 'fonts/albertsans_bold_1d53ecea_cb51_4efe-2.ttf',
                    color: 0xFFFFFFFF,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.TOP,
                    text_style: hmUI.text_style.ELLIPSIS,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                // AOD режим
                idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 224,
                    y: 202,
                    src: '46.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });

                idle_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 83,
                    y: 168,
                    w: 150,
                    h: 100,
                    text_size: 100,
                    font: 'fonts/albertsans_bold_1d53ecea_cb51_4efe-2.ttf',
                    color: 0xFFFFFFFF,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.TOP,
                    text_style: hmUI.text_style.ELLIPSIS,
                    show_level: hmUI.show_level.ONLY_AOD
                });

                idle_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 237,
                    y: 168,
                    w: 151,
                    h: 100,
                    text_size: 100,
                    font: 'fonts/albertsans_bold_1d53ecea_cb51_4efe-2.ttf',
                    color: 0xFFFFFFFF,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.TOP,
                    text_style: hmUI.text_style.ELLIPSIS,
                    show_level: hmUI.show_level.ONLY_AOD
                });

                image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 113,
                    y: 283,
                    src: '47.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                image_top_img.setAlpha(100);

                // Кнопки
                btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
                    x: 183,
                    y: 360,
                    w: 100,
                    h: 100,
                    normal_src: 'Empty.png',
                    press_src: 'Empty.png',
                    click_func: click_zona1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
                normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                text_pressere.setProperty(hmUI.prop.VISIBLE, false);
                text_pressere_changes.setProperty(hmUI.prop.VISIBLE, false);

                button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
                    x: 35,
                    y: 255,
                    w: 80,
                    h: 100,
                    text: '',
                    normal_src: 'empty.png',
                    press_src: 'empty.png',
                    click_func: () => {
                        hmApp.startApp({
                            appid: 1066654,
                            url: 'page/index',
                            params: { from_wf: true }
                        });
                    },
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                // Функции обновления
                function weather_few_days(weatherSensor) {
                    logger.log('weather_few_days()');
                    const weatherData = weatherSensor.getForecastWeather();
                    const forecastData = weatherData.forecastData;

                    for (let i = 0; i < 7; i++) {
                        if (screenType === hmSetting.screen_type.WATCHFACE) {
                            let dowIndex = timeSensor.week - 1 + i;
                            dowIndex = dowIndex >= 7 ? dowIndex - 7 : dowIndex;
                            normal_forecast_date_week_font[i].setProperty(hmUI.prop.TEXT, normal_forecast_date_week_font_Array[dowIndex]);

                            let averageTemperature = '-';
                            if (i < forecastData.count && forecastData.data[i]) {
                                averageTemperature = parseInt((forecastData.data[i].high + forecastData.data[i].low) / 2).toString();
                            }
                            normal_forecast_average_text_font[i].setProperty(hmUI.prop.TEXT, averageTemperature);

                            let weatherIndex = 25;
                            if (i < forecastData.count && forecastData.data[i]) {
                                weatherIndex = forecastData.data[i].index;
                            }
                            normal_forecast_image_progress_img_level[i].setProperty(hmUI.prop.SRC, normal_forecast_image_array[weatherIndex]);
                        }
                    }
                }

                function time_update(updateHour = false, updateMinute = false) {
                    logger.log('time_update()');
                    const hour = timeSensor.hour;
                    const minute = timeSensor.minute;
                    const second = timeSensor.second;
                    const format_hour = timeSensor.format_hour;

                    if (updateHour) {
                        normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Array[timeSensor.month - 1]);
                        let dayStr = timeSensor.day.toString().padStart(2, '0');
                        normal_day_text_font.setProperty(hmUI.prop.TEXT, dayStr);
                        normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Array[timeSensor.week - 1]);
                        let hourStr = format_hour.toString().padStart(2, '0');
                        normal_time_hour_text_font.setProperty(hmUI.prop.TEXT, hourStr);
                        idle_time_hour_text_font.setProperty(hmUI.prop.TEXT, hourStr);
                    }

                    if (updateMinute) {
                        let minuteStr = minute.toString().padStart(2, '0');
                        normal_time_minute_text_font.setProperty(hmUI.prop.TEXT, minuteStr);
                        idle_time_minute_text_font.setProperty(hmUI.prop.TEXT, minuteStr);
                    }

                    let secondStr = second.toString().padStart(2, '0');
                    normal_time_second_text_font.setProperty(hmUI.prop.TEXT, secondStr);
                }

                function scale_call(weatherSensor) {
                    logger.log('scale_call()');
                    const weatherData = weatherSensor.getForecastWeather();
                    normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                    const tideData = weatherData.tideData;
                    const curAirIconIndex = weatherSensor.curAirIconIndex;
                    let sunriseMins, sunsetMins;
                    if (tideData.count > 0) {
                        const today = tideData.data[0];
                        sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
                        sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
                    } else {
                        sunriseMins = 6 * 60; // 6:00 по умолчанию
                        sunsetMins = 18 * 60; // 18:00 по умолчанию
                    }

                    const curMins = timeSensor.hour * 60 + timeSensor.minute;
                    const isDayNow = curMins >= sunriseMins && curMins < sunsetMins;
                    const shotWeatherNames = isDayNow ? [
                        "Облачно", "Местами дождь", "Местами снег", "Cолнечно", "Пасмурно", "Слабый дождь",
                        "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь",
                        "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно",
                        "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь", "Песчаная буря",
                        "Сильная песчаная буря", "Сильный дождь", "Неизвестная погода", "Облачно ночью",
                        "Дождливо ночью", "Ясно ночью"
                    ] : [
                        "Облачно ночью", "Местами дождь", "Местами снег", "Ясно ночью", "Пасмурно ночью",
                        "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад",
                        "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой",
                        "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь",
                        "Песчаная буря", "Сильная песчаная буря", "Сильный дождь", "Неизвестная погода",
                        "Облачно ночью", "Дождливо ночью", "Ясно ночью"
                    ];

                    weather_day.setProperty(hmUI.prop.TEXT, shotWeatherNames[curAirIconIndex] || "Неизвестная погода");
                }

                const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
                const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: () => {
                        logger.log('resume_call()');
                        const pressure_array = read_pressure();
                        const value = hPa_To_mmHg(getPressureValue(pressure_array));
                        text_pressere.setProperty(hmUI.prop.TEXT, value === 0 ? "--" : `${value} мм.`);
                        const pressere_changes = changesPressure(pressure_array);
                        text_pressere_changes.setProperty(hmUI.prop.TEXT, pressere_changes < 0 ? "Давление падает" : pressere_changes > 0 ? "Давление растет" : "Давление не меняется");

                        scale_call(weatherSensor);
                        time_update(true, true);
                        weather_few_days(weatherSensor);

                        if (screenType === hmSetting.screen_type.WATCHFACE && !normal_timerTimeUpdate) {
                            normal_timerTimeUpdate = timer.createTimer(0, 1000, () => {
                                const updateHour = timeSensor.minute === 0 && timeSensor.second < 2;
                                const updateMinute = timeSensor.second < 2;
                                time_update(updateHour, updateMinute);
                            });
                        }

                        if (screenType === hmSetting.screen_type.AOD && !idle_timerTimeUpdate) {
                            idle_timerTimeUpdate = timer.createTimer(0, 1000, () => {
                                const updateHour = timeSensor.minute === 0 && timeSensor.second < 2;
                                const updateMinute = timeSensor.second < 2;
                                time_update(updateHour, updateMinute);
                            });
                        }
                    },
                    pause_call: () => {
                        logger.log('pause_call()');
                        if (normal_timerTimeUpdate) {
                            timer.stopTimer(normal_timerTimeUpdate);
                            normal_timerTimeUpdate = undefined;
                        }
                        if (idle_timerTimeUpdate) {
                            timer.stopTimer(idle_timerTimeUpdate);
                            idle_timerTimeUpdate = undefined;
                        }
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}