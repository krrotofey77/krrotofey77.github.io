const labels = [
  { x: 40,  y: 300, size: 25, color: 0xFFFF0000, text: 'test1' },
  { x: 140, y: 300, size: 28, color: 0xFFFFCC00, text: 'test2' },
  { x: 240, y: 300, size: 33, color: 0xFFFFFFFF, text: 'test3' },
  { x: 340, y: 300, size: 35, color: 0xFFFEE9BC, text: 'test4' },
]

labels.forEach(item => {
  hmUI.createWidget(hmUI.widget.TEXT, {
    x: item.x,
    y: item.y,
    w: 120,
    h: 30,
    text: item.text,
    text_size: item.size,
    color: item.color,
    font: 'fonts/1.ttf'
  })
})