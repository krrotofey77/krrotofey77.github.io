hmUI.createWidget(hmUI.widget.TEXT,{
  x: 40,
  y: 300,
  w: 120,
  h: 30,
  text: 'ШАГИ',
  text_size: 22,
  color: COLOR,
  font: 'fonts/another.ttf'
})
hmUI.createWidget(hmUI.widget.TEXT,{
  x: 40,
  y: 300,
  w: 120,
  h: 30,
  text: 'ШАГИ',
  text_size: 22,
  color: COLOR,
  font: 'fonts/another.ttf'
})
hmUI.createWidget(hmUI.widget.TEXT,{
  x: 40,
  y: 300,
  w: 120,
  h: 30,
  text: 'ШАГИ',
  text_size: 22,
  color: COLOR,
  font: 'fonts/another.ttf'
})
hmUI.createWidget(hmUI.widget.TEXT,{
  x: 40,
  y: 300,
  w: 120,
  h: 30,
  text: 'ШАГИ',
  text_size: 22,
  color: COLOR,
  font: 'fonts/another.ttf'
})