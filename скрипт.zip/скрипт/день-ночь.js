  let bg = ''      ////////////////////////////  самый верх let
  ////////////////////////////////////////////////////////////////
  const curTime = hmSensor.createSensor(hmSensor.id.TIME);
		const weather = hmSensor.createSensor(hmSensor.id.WEATHER);
		let weatherData = weather.getForecastWeather();
		let forecastData = weatherData.forecastData;
		let sunData = weatherData.tideData;
		let today = '';
		let sunriseMins = '';
		let sunsetMins = '';
		let sunriseMins_def = 8 * 60;			
		let sunsetMins_def = 20 * 60;

		let curMins = '';
		
		let isDayBg = true;
		
		function autoToggleBg() {

			weatherData = weather.getForecastWeather();
			sunData = weatherData.tideData;
			if (sunData.count > 0){
				today = sunData.data[0];
				sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
				sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
			} else {
				sunriseMins = sunriseMins_def;
				sunsetMins = sunsetMins_def;
			}

			curMins = curTime.hour * 60 + curTime.minute;
			let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);
			
			if(isDayNow){
				if(!isDayBg){
					bg.setProperty(hmUI.prop.SRC, "day.png");
					isDayBg = true;
				}
			} else {
				if(isDayBg){
					bg.setProperty(hmUI.prop.SRC, "night.png");
					isDayBg = false;
				}
			}
		}
/////////////////////////////////////////////////////////////////
console.log('Watch_Face.ScreenNormal');

bg = hmUI.createWidget(hmUI.widget.IMG, {
  x: 0,
  y: 0,
  w: 466,
  h: 466,
src: 'day.png',
show_level: hmUI.show_level.ONLY_NORMAL,
});

autoToggleBg();
//////////////////////////////////////////////////////////////
const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
  resume_call: (function () {
    console.log('resume_call()');
autoToggleBg();

  }),
  pause_call: (function () {
    console.log('pause_call()');

  }),
});
