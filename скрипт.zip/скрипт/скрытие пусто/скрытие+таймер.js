// ======================================================
// ============== ТАЙМЕР АВТОМАТИЧЕСКОГО СКРЫТИЯ ============
// ======================================================

// 1. ОБЪЯВЛЕНИЕ ПЕРЕМЕННЫХ (добавить в секцию с другими переменными)
let hideTimer = null;        // Таймер для автоматического скрытия
let targetWidgets = [];      // Массив виджетов для скрытия
let isVisible = false;       // Текущее состояние видимости

// 2. ФУНКЦИЯ ПРИМЕНЕНИЯ ВИДИМОСТИ
function applyVisibility() {
    for (let i = 0; i < targetWidgets.length; i++) {
        if (targetWidgets[i]) {
            targetWidgets[i].setProperty(hmUI.prop.VISIBLE, isVisible);
        }
    }
}

// 3. ФУНКЦИЯ ЗАПУСКА ТАЙМЕРА
function startHideTimer(delaySeconds = 15) {
    // Сбрасываем предыдущий таймер
    if (hideTimer !== null) {
        clearTimeout(hideTimer);
    }
    
    // Устанавливаем новый таймер
    hideTimer = setTimeout(function() {
        if (isVisible) {
            isVisible = false;
            applyVisibility();
        }
        hideTimer = null;
    }, delaySeconds * 1000);
}

// 4. ФУНКЦИЯ ПЕРЕКЛЮЧЕНИЯ ВИДИМОСТИ (основная)
function toggleVisibility(autoHideSeconds = 15) {
    isVisible = !isVisible;
    applyVisibility();
    
    if (isVisible) {
        startHideTimer(autoHideSeconds);
    } else {
        if (hideTimer !== null) {
            clearTimeout(hideTimer);
            hideTimer = null;
        }
    }
}

// 5. ФУНКЦИЯ ПОКАЗА С АВТОСКРЫТИЕМ
function showWithAutoHide(autoHideSeconds = 15) {
    if (!isVisible) {
        isVisible = true;
        applyVisibility();
        startHideTimer(autoHideSeconds);
    } else {
        // Если уже видимо, просто сбрасываем таймер
        startHideTimer(autoHideSeconds);
    }
}

// 6. ФУНКЦИЯ СКРЫТИЯ
function hide() {
    if (isVisible) {
        isVisible = false;
        applyVisibility();
        if (hideTimer !== null) {
            clearTimeout(hideTimer);
            hideTimer = null;
        }
    }
}

// 7. ФУНКЦИЯ ДЛЯ ДОБАВЛЕНИЯ ВИДЖЕТОВ В МАССИВ
function addToAutoHide(...widgets) {
    targetWidgets.push(...widgets);
}



// ======================================================
// ====================== ПРИМЕР =========================
// ======================================================

// 1. Создаем виджеты
let myImage = hmUI.createWidget(hmUI.widget.IMG, {
    x: 100,
    y: 100,
    src: 'my_image.png',
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let myText = hmUI.createWidget(hmUI.widget.TEXT, {
    x: 120,
    y: 200,
    w: 200,
    h: 50,
    text_size: 24,
    color: 0xFFFFFFFF,
    text: 'Привет!',
    align_h: hmUI.align.CENTER_H,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

// 2. Добавляем виджеты в массив для автоматического скрытия
addToAutoHide(myImage, myText);

// 3. Изначально скрываем (опционально)
isVisible = false;
applyVisibility();

// 4. Создаем кнопку для показа/скрытия
let myButton = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 180,
    y: 300,
    w: 100,
    h: 100,
    text: '',
    press_src: 'Empty.png',
    normal_src: 'Empty.png',
    click_func: () => {
        toggleVisibility(15); // Показать/скрыть с автоскрытием через 15 секунд
        // или
        // showWithAutoHide(10); // Только показать с автоскрытием через 10 секунд
        // или
        // hide(); // Только скрыть
    },
    show_level: hmUI.show_level.ONLY_NORMAL,
});






////////////////////минимальный код
// Минимальная версия таймера скрытия
let hideTimer = null;
let widgetsToHide = [];
let isHidden = true; // true - скрыто, false - видимо

function applyHideState() {
    for (let w of widgetsToHide) {
        if (w) w.setProperty(hmUI.prop.VISIBLE, !isHidden);
    }
}

function startAutoHide(seconds) {
    if (hideTimer) clearTimeout(hideTimer);
    hideTimer = setTimeout(() => {
        if (!isHidden) {
            isHidden = true;
            applyHideState();
        }
        hideTimer = null;
    }, seconds * 1000);
}

function toggleWithAutoHide(seconds = 15) {
    isHidden = !isHidden;
    applyHideState();
    if (!isHidden) startAutoHide(seconds);
}

// Использование:
// widgetsToHide.push(widget1, widget2, widget3); // добавляем виджеты
// isHidden = true; applyHideState(); // скрываем изначально
// кнопка: click_func: () => toggleWithAutoHide(15)