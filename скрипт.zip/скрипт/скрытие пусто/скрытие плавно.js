// Текущее состояние:
// true  = элементы видимы
// false = элементы скрыты
let fadeVisible = true;

// Счётчик шагов анимации
let fadeStep = 0;

// Переменная для хранения таймера
let fadeTimer = null;

function fadeToggle() {

    // Если таймер уже работает — останавливаем его
    // Это защищает от двойного нажатия
    if (fadeTimer) {
        timer.stopTimer(fadeTimer);
        fadeTimer = null;
    }

    // Обнуляем шаг анимации
    fadeStep = 0;

    // Создаём таймер
    // 0 — старт без задержки
    // 80 — скорость анимации (меньше = быстрее, больше = медленнее)
    fadeTimer = timer.createTimer(0, 80, function () {

        // Увеличиваем шаг
        fadeStep++;

        if (fadeVisible) {
            // ====== РЕЖИМ СКРЫТИЯ ======

            if (fadeStep === 1)
                normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

            if (fadeStep === 2)
                normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

            if (fadeStep === 3) {
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

                // Останавливаем таймер
                timer.stopTimer(fadeTimer);

                // Меняем состояние
                fadeVisible = false;
            }

        } else {
            // ====== РЕЖИМ ПОЯВЛЕНИЯ ======

            if (fadeStep === 1)
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);

            if (fadeStep === 2)
                normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);

            if (fadeStep === 3) {
                normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);

                timer.stopTimer(fadeTimer);
                fadeVisible = true;
            }
        }

    });
}
/////////////////


Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {  
      x: 180,  
      y: 180,  
      w: 100,  
      h: 100,  
      text: '',  
      color: 0xFFFF8C00,  
      text_size: 25,  
      press_src: 'Empty.png',    
      normal_src: 'Empty.png',  
      click_func: () => {
    fadeToggle();
}, // end func  
      show_level: hmUI.show_level.ONLY_NORMAL,  
    }); // end button