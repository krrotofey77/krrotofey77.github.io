 let visible = true;       ///////////////////////////////  +1 доп. кнопка

        function setVisible() {
            visible = !visible;
            normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, visible);
            normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, visible);
            normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, visible);
            normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, visible);
        }
      ///////////////////////////////////////////////////////выше let//////////////////////////////////////////
  
        console.log('Watch_Face.Buttons');
        Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 180,
          y: 180,
          w: 100,
          h: 100,
          text: '',
          color: 0xFFFF8C00,
          text_size: 25,
          press_src: 'Empty.png',  
          normal_src: 'Empty.png',
          click_func: (button_widget) => {
            setVisible();
          }, // end func
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button
