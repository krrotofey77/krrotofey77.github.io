﻿let normal_analog_clock_time_pointer_second = '';
let normal_temperature_current_text_font = '';
let normal_heart_rate_text_font = '';
let normal_step_current_text_font = '';

let visible = false;       ///////////////////////////////  +1 доп. кнопка

function applyVisibility() {
    normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, visible);
    normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, visible);
    normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, visible);
    normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, visible);
}

function setVisible() {
    visible = !visible;
    applyVisibility();
}
///////////////////////////////////////////////////////выше let//////////////////////////////////////////


console.log('Watch_Face.ScreenNormal');

normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.IMG, {
  x: 100,
  y: 100,
  src: 'second.png',
  show_level: hmUI.show_level.ONLY_NORMAL,
});

normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
  x: 120,
  y: 200,
  w: 100,
  h: 30,
  text_size: 20,
  color: 0xFFFFFFFF,
  text: '24°',
  align_h: hmUI.align.CENTER_H,
  show_level: hmUI.show_level.ONLY_NORMAL,
});

normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
  x: 120,
  y: 240,
  w: 100,
  h: 30,
  text_size: 20,
  color: 0xFFFFFFFF,
  text: '72',
  align_h: hmUI.align.CENTER_H,
  show_level: hmUI.show_level.ONLY_NORMAL,
});

normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
  x: 120,
  y: 280,
  w: 100,
  h: 30,
  text_size: 20,
  color: 0xFFFFFFFF,
  text: '5432',
  align_h: hmUI.align.CENTER_H,
  show_level: hmUI.show_level.ONLY_NORMAL,
});

applyVisibility();   // <- сразу скрываем после создания


console.log('Watch_Face.Buttons');
Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 180,
  y: 180,
  w: 100,
  h: 100,
  text: '',
  color: 0xFFFF8C00,
  text_size: 25,
  press_src: 'Empty.png',
  normal_src: 'Empty.png',
  click_func: (button_widget) => {
    setVisible();
  },
  show_level: hmUI.show_level.ONLY_NORMAL,
}); // end button
