﻿/*
** Watch_Face_Editor tool
** watchface js version v2.1.1
** Copyright © SashaCX75. All Rights Reserved
*/

try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const { px } = __$$app$$__.__globals__;
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')

        // --- start user_functions.js ---
        let normal_widget_text_week = ''
        let normal_widget_text_day = ''
        let normal_timerTimeUpdate = undefined;
        let timeSensor = null;

        function getWeekAndDay() {
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            
            const y = timeSensor.year;
            const m = timeSensor.month;
            const d = timeSensor.day;

            const now = new Date(y, m - 1, d);
            const startOfYear = new Date(y, 0, 1);

            // 1. Расчет дня года (1-366)
            const dayOfYear = Math.round((now.getTime() - startOfYear.getTime()) / 86400000) + 1;

            // 2. Расчет недели (ваша логика: с первого полного понедельника)
            let firstMonday = new Date(y, 0, 1);
            while (firstMonday.getDay() !== 1) {
                firstMonday.setDate(firstMonday.getDate() + 1);
            }

            let weekNum = 0;
            if (now >= firstMonday) {
                const diffInDays = Math.floor((now.getTime() - firstMonday.getTime()) / 86400000);
                weekNum = Math.floor(diffInDays / 7) + 1;
            }

            return {
                week: weekNum,
                day: dayOfYear
            };
        }

        function updateWidgets() {
            const data = getWeekAndDay();
            if (normal_widget_text_week) {
                normal_widget_text_week.setProperty(hmUI.prop.TEXT, 'Неделя: ' + data.week);
            }
            if (normal_widget_text_day) {
                normal_widget_text_day.setProperty(hmUI.prop.TEXT, 'День: ' + data.day);
            }
        }
        // --- end user_functions.js ---

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                // Черный фон
                hmUI.createWidget(hmUI.widget.FILL_RECT, {
                    x: 0, y: 0, w: 466, h: 466, color: 0x000000,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // Виджет НЕДЕЛЯ
                normal_widget_text_week = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: px(40),
                    y: px(210),
                    w: px(180),
                    h: px(40),
                    text_size: px(25), // Размер как вы просили
                    color: 0xFFFFFF,
                    align_h: hmUI.align.LEFT,
                    text: '--',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // Виджет ДЕНЬ
                normal_widget_text_day = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: px(250), // Смещаем вправо
                    y: px(210),
                    w: px(180),
                    h: px(40),
                    text_size: px(25), // Размер как вы просили
                    color: 0xFFFFFF,
                    align_h: hmUI.align.LEFT,
                    text: '--',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // Таймер и Делегат
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: () => {
                        updateWidgets();
                        if (!normal_timerTimeUpdate) {
                            normal_timerTimeUpdate = timer.createTimer(0, 60000, updateWidgets);
                        }
                    },
                    pause_call: () => {
                        if (normal_timerTimeUpdate) {
                            timer.stopTimer(normal_timerTimeUpdate);
                            normal_timerTimeUpdate = undefined;
                        }
                    },
                });
            },
            build() { this.init_view(); },
            onDestroy() { if (normal_timerTimeUpdate) timer.stopTimer(normal_timerTimeUpdate); }
        });
    })();
} catch (e) {
    console.log('Error', e);
}
