﻿/*
** Watch_Face_Editor tool
** watchface js version v2.1.1
** Copyright © SashaCX75. All Rights Reserved
*/

try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const { px } = __$$app$$__.__globals__;
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')

        // --- start user_functions.js ---
        let normal_widget_text_week_Year = ''
        let normal_timerTimeUpdate = undefined;
        let timeSensor = null;

        function getWeekNumber() {
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            
            const y = timeSensor.year;
            const m = timeSensor.month;
            const d = timeSensor.day;

            const now = new Date(y, m - 1, d);
            let firstMonday = new Date(y, 0, 1);
            
            // Ищем первый ПОЛНЫЙ понедельник года
            while (firstMonday.getDay() !== 1) {
                firstMonday.setDate(firstMonday.getDate() + 1);
            }

            // Если сейчас дни ДО первого понедельника года (огрызки недели)
            if (now < firstMonday) {
                return 0; // Или можно вернуть 52/53 прошлого года, но по вашей логике это 0
            }

            const diffInMs = now.getTime() - firstMonday.getTime();
            const diffInDays = Math.floor(diffInMs / 86400000);

            // Считаем только полные прошедшие 7-дневки + текущая
            return Math.floor(diffInDays / 7) + 1;
        }

        // ЭТОЙ ФУНКЦИИ НЕ ХВАТАЛО
        function updateWeekWidget() {
            if (normal_widget_text_week_Year) {
                const week = getWeekNumber();
                normal_widget_text_week_Year.setProperty(hmUI.prop.TEXT, String(week));
            }
        }
        // --- end user_functions.js ---

        let normal_background_bg = ''
        let normal_widget_text_1 = ''

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                // Черный фон
                normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    color: 0x000000,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // Текст "№ НЕДЕЛИ"
                normal_widget_text_1 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: px(157),
                    y: px(166),
                    w: px(180),
                    h: px(40),
                    text_size: px(31),
                    color: 0xFFFFFF00,
                    align_h: hmUI.align.LEFT,
                    text: '№ НЕДЕЛИ',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // Само число недели
                normal_widget_text_week_Year = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: px(169),
                    y: px(213),
                    w: px(180),
                    h: px(50),
                    text_size: px(40),
                    color: 0xFFFFFF00,
                    align_h: hmUI.align.LEFT,
                    text: '--',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // Делегат для обновления при активации экрана
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: () => {
                        updateWeekWidget();
                        if (!normal_timerTimeUpdate) {
                            // Обновляем раз в минуту
                            normal_timerTimeUpdate = timer.createTimer(0, 60000, updateWeekWidget);
                        }
                    },
                    pause_call: () => {
                        if (normal_timerTimeUpdate) {
                            timer.stopTimer(normal_timerTimeUpdate);
                            normal_timerTimeUpdate = undefined;
                        }
                    },
                });
            },
            onInit() {
                logger.log('onInit');
            },
            build() {
                this.init_view();
            },
            onDestroy() {
                if (normal_timerTimeUpdate) timer.stopTimer(normal_timerTimeUpdate);
            }
        });
    })();
} catch (e) {
    console.log('Error', e);
}
