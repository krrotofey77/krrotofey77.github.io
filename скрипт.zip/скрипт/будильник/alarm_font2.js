//            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
//              x: 388,
//              y: 200,
//              src: 'alarm.png',
//              type: hmUI.system_status.CLOCK,
//              show_level: hmUI.show_level.ONLY_NORMAL,
//            });


normal_alarm_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
    x: 304-3,
    y: 194,
    w: 170,
    h: 40,
    text_size: 32,
    char_space: -1,
    line_space: 0,
    padding: true,
    font: 'fonts/Bebas11.ttf',
    color: 0xFF000000,
    align_h: hmUI.align.CENTER_H,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.ELLIPSIS,
    type: hmUI.data_type.ALARM_CLOCK,
    show_level: hmUI.show_level.ONLY_NORMAL,
  });