 normal_ALARM_CLOCK_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 300,
              y: 122,
              w: 150,
              h: 50,
              text_size: 22,
              char_space: 0,
              line_space: 0,
				padding: true,
				font: 'fonts/conthrax_sb_0.ttf',
              color: 0xFFD3D3D3,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
                
            normal_ALARM_CLOCK_text_img_off = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198-88,
              y: 130,
              font_array: ["al_0.png","al_1.png","al_2.png","al_3.png","al_4.png","al_5.png","al_6.png","al_7.png","al_8.png","al_9.png"],
              padding: true,
              h_space: 0,
              dot_image: 'al_0.png',
              invalid_image: 'al_v.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
                