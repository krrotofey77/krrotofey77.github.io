  let alarm_clock_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
  x: 180,
  y: 400,
  font_array: ["alarm_1.png","alarm_2.png","alarm_3.png","alarm_4.png","alarm_5.png","alarm_6.png","alarm_7.png","alarm_8.png","alarm_9.png","alarm_10.png"],
  padding: 5,
  h_space: 2,
  dot_image: 'alarm_11.png',          //ALARM CLOCK 
  invalid_image: 'alarm_11_no.png',    //ALARM CLOCK
  align_h: hmUI.align.LEFT,
  type: hmUI.data_type.ALARM_CLOCK,
  show_level: hmUI.show_level.ONLY_NORMAL
});

//ALARM CLOCK 
console.log('Watch_Face.Shortcuts');
