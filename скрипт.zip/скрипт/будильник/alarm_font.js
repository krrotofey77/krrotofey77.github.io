let alarm_clock_img = hmUI.createWidget(hmUI.widget.TEXT_FONT,  {
              x: 180,
              y: 400,
              w: 100,
              h: 50,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              color: 0xFFffffff,
              align_h: hmUI.align.CENTR,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
    
            //ALARM CLOCK 
            console.log('Watch_Face.Shortcuts');