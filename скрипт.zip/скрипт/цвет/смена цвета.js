 let bg_color = ['0xFFF8641D', '0xFFEC100C3', '0xFFE9C001', '0xFFA1BD00', '0xFF40ABFD', '0xFF4C7EFB', '0xFF7B62B7', '0xFFFFC197', '0xFFFFBDC8', '0xFFFFDE96', '0xFFCDE191', '0xFF100CED6', '0xFF7790B5', '0xFFC2B5F5'];


    let color_num = 0
    let color_all = 13
    function click_color() {
      if (color_num >= color_all) { color_num = 0; }
      else { color_num = color_num + 1; }
      hmUI.showToast({ text: "Color " + parseInt(color_num + 1) });
      normal_background_bg.setProperty(hmUI.prop.MORE,{ 
        x: 0,
        y: 0,
        w: 466,
        h: 466,
        color: bg_color[color_num],
        show_level: hmUI.show_level.ONLY_NORMAL,
      });
    }


    let progress_num = 1

                 кнопка
                 console.log('Watch_Face.Buttons');
                 Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
                   x: 183,
                   y: 183,
                   w: 100,
                   h: 100,
                   text: "",
                   normal_src: "wfs_clear.png",
                   press_src: "wfs_clear.png",
                   click_func: (button_widget) => {
                     click_color();
                   }, // end func
                   show_level: hmUI.show_level.ONLY_NORMAL,
                 }); // end button
         