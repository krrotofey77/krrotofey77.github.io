let bg_fill = ''
let bgColor = [0x36FFF8, 0x36FFA8, 0x3679FF, 0xFC35F9, 0xFF3643, 0xFC7E35, 0xCDB35, 0xC7FC35, 0x7CFF36, 0x35FC7E]
		let colorIndex = 0 
		let degreeSum = 0
		let crownSensitivity = 70		// уровень чувствительности колесика
		let colorIndex_text

 function onDigitalCrown() {
                    hmApp.registerSpinEvent(function (key, degree) {
                            if (key === hmApp.key.HOME) {
                                degreeSum += degree;
                                if (Math.abs(degreeSum) > crownSensitivity){
                                    let step = degreeSum < 0 ? -1 : 1;
                                    colorIndex += step;
                                    colorIndex = colorIndex < 0 ? bgColor.length + colorIndex : colorIndex % bgColor.length;
                                    degreeSum = 0;
                                    
                                    bg_fill.setProperty(hmUI.prop.MORE, { 
                                        x: 0,
                                        y: 0,
                                        w: 466,
                                        h: 466,
                                        radius: 233,
                                        color: bgColor[colorIndex],
                                    });
                                    
                    
                                }
                            }
                        }
                    ) // crown
                }
                
                bg_fill = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    radius: 233,
                    color: bgColor[colorIndex],
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
    
                                     внизу

	
                  
                                     const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                                      resume_call: (function () {               
                                        setTimeout(() => {
                                          onDigitalCrown();
                                        }, 350);              
                                      }),
                                      pause_call: (function () {
                                        hmApp.unregisterSpinEvent();
                                      }),
                                    });
                                    

 //dynamic modify end