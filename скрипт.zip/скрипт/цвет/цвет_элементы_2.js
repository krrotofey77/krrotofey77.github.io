let color1number_main = 1
        let totalcolor1s_main = 16
        let namecolor1_main = ''
		let colorstring = '0xFFFF8000'
		let secstring = 's_.png'
		let hourstring = 'h_.png'
    let minutestring = 'm_.png'
    let imagestring = 'bg_.png'
		function click_COLOR() {
            if(color1number_main>=totalcolor1s_main) {
            color1number_main=1;
                }
            else {
                color1number_main=color1number_main+1;
            }
			if ( color1number_main == 1) { namecolor1_main = "color_1"
				colorstring = '0xFFFF8000'
				secstring = "s_" + parseInt(color1number_main) + ".png"
        hourstring = "h_" + parseInt(color1number_main) + ".png"
        minutestring = "m_" + parseInt(color1number_main) + ".png"
        imagestring = "bg_" + parseInt(color1number_main) + ".png"
			}
			if ( color1number_main == 2) { namecolor1_main = "color_2"
				colorstring = '0xFF008080'
			secstring = "s_" + parseInt(color1number_main) + ".png"
        hourstring = "h_" + parseInt(color1number_main) + ".png"
        minutestring = "m_" + parseInt(color1number_main) + ".png"
         imagestring = "bg_" + parseInt(color1number_main) + ".png"
			}
			if ( color1number_main == 3) { namecolor1_main = "color_3"
				colorstring = '0xFF808000'
				secstring = "s_" + parseInt(color1number_main) + ".png"
        hourstring = "h_" + parseInt(color1number_main) + ".png"
        minutestring = "m_" + parseInt(color1number_main) + ".png"
         imagestring = "bg_" + parseInt(color1number_main) + ".png"
			}
			if ( color1number_main == 4) { namecolor1_main = "color_4"
				colorstring = '0xFF800000'
				secstring = "s_" + parseInt(color1number_main) + ".png"
        hourstring = "h_" + parseInt(color1number_main) + ".png"
        minutestring = "m_" + parseInt(color1number_main) + ".png"
			}
			if ( color1number_main == 5) { namecolor1_main = "color_5"
				colorstring = '0xFF00FFFF'
				secstring = "s_" + parseInt(color1number_main) + ".png"
        hourstring = "h_" + parseInt(color1number_main) + ".png"
        minutestring = "m_" + parseInt(color1number_main) + ".png"
			}
			if ( color1number_main == 6) { namecolor1_main = "color_6"
				colorstring = '0xFF008000'
				secstring = "s_" + parseInt(color1number_main) + ".png"
        hourstring = "h_" + parseInt(color1number_main) + ".png"
        minutestring = "m_" + parseInt(color1number_main) + ".png"
			}
			if ( color1number_main == 7) { namecolor1_main = "color_7"
				colorstring = '0xFFFF0000'
				secstring = "s_" + parseInt(color1number_main) + ".png"
        hourstring = "h_" + parseInt(color1number_main) + ".png"
        minutestring = "m_" + parseInt(color1number_main) + ".png"
			}
			if ( color1number_main == 8) { namecolor1_main = "color_8"
				colorstring = '0xFFFFFF00'
				secstring = "s_" + parseInt(color1number_main) + ".png"
        hourstring = "h_" + parseInt(color1number_main) + ".png"
        minutestring = "m_" + parseInt(color1number_main) + ".png"
			}
			if ( color1number_main == 9) { namecolor1_main = "color_9"
				colorstring = '0xFFBFFF00'
				secstring = "s_" + parseInt(color1number_main) + ".png"
        hourstring = "h_" + parseInt(color1number_main) + ".png"
        minutestring = "m_" + parseInt(color1number_main) + ".png"
			}
			if ( color1number_main == 10) { namecolor1_main = "color_10"
				colorstring = '0xFFA020F0'
				secstring = "s_" + parseInt(color1number_main) + ".png"
        hourstring = "h_" + parseInt(color1number_main) + ".png"
        minutestring = "m_" + parseInt(color1number_main) + ".png"
			}
			if ( color1number_main == 11) { namecolor1_main = "color_11"
				colorstring = '0xFF0000FF'
			secstring = "s_" + parseInt(color1number_main) + ".png"
        hourstring = "h_" + parseInt(color1number_main) + ".png"
        minutestring = "m_" + parseInt(color1number_main) + ".png"
			}
			if ( color1number_main == 12) { namecolor1_main = "color_12"
				colorstring = '0xFFFF00FF'
				secstring = "s_" + parseInt(color1number_main) + ".png"
        hourstring = "h_" + parseInt(color1number_main) + ".png"
        minutestring = "m_" + parseInt(color1number_main) + ".png"
			}
			if ( color1number_main == 13) { namecolor1_main = "color_13"
				colorstring = '0xFFA5694F'
				secstring = "s_" + parseInt(color1number_main) + ".png"
        hourstring = "h_" + parseInt(color1number_main) + ".png"
        minutestring = "m_" + parseInt(color1number_main) + ".png"
			}
			if ( color1number_main == 14) { namecolor1_main = "color_14"
				colorstring = '0xFFFFBF00'
				secstring = "s_" + parseInt(color1number_main) + ".png"
        hourstring = "h_" + parseInt(color1number_main) + ".png"
        minutestring = "m_" + parseInt(color1number_main) + ".png"
			}
			if ( color1number_main == 15) { namecolor1_main = "color_15"
				colorstring = '0xFFC0C0C0'
				secstring = "s_" + parseInt(color1number_main) + ".png"
        hourstring = "h_" + parseInt(color1number_main) + ".png"
        minutestring = "m_" + parseInt(color1number_main) + ".png"
			}
			if ( color1number_main == 16) { namecolor1_main = "color_16"
				colorstring = '0xFFFFFFFF'
				secstring = "s_" + parseInt(color1number_main) + ".png"
        hourstring = "h_" + parseInt(color1number_main) + ".png"
        minutestring = "m_" + parseInt(color1number_main) + ".png"
			}

			if ( color1number_main <= 16) { 
			
			normal_background_bg.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: colorstring,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
              hour_path: hourstring,
              hour_centerX: 250,
              hour_centerY: 250,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
              minute_path: minutestring,
              minute_centerX: 260,
              minute_centerY: 260,
              minute_posX: 240,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
              second_path: secstring,
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			 normal_image_img.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              src: imagestring,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
		
	}
			hmUI.showToast({text: namecolor1_main });
			
        }		
/////////////////////////////////////////////////////////////////////////			

       Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 210,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                			click_COLOR();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
  