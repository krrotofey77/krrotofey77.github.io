        let bg_list = [
            'Image_1.png',
            'Image_2.png',
            'Image_3.png',
            'Image_4.png',
        ];
        let crownSensitivity = 70;		// уровень чувствительности колесика
        let bg_index = 0;
		let degreeSum = 0;

        function onDigitalCrown() {
            hmApp.registerSpinEvent(function (key, degree) {
                    if (key === hmApp.key.HOME) {
                        degreeSum += degree;
                        if (Math.abs(degreeSum) > crownSensitivity){
                            let step = degreeSum < 0 ? -1 : 1;
                            bg_index += step;
                            bg_index = bg_index < 0 ? bg_list.length + bg_index : bg_index % bg_list.length;
                            degreeSum = 0;
                            
                            normal_background_bg_img.setProperty(hmUI.prop.SRC, bg_list[bg_index]);
                        }
                    }
                }
            ) // crown
        }


        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
            resume_call: (function () {               
              setTimeout(() => {
                onDigitalCrown();
              }, 350);              
            }),
            pause_call: (function () {
              hmApp.unregisterSpinEvent();
            }),
          });
          
