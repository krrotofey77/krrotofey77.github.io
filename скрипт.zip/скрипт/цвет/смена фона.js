  let fon_img = ''//имя блока с картинкой стр 17
        let btn_fon = ''//имя кнопки стр 25
        let fon_num = 1// начальный номер png
        let fon_all = 5// штук картинок png
		
//проверяем сколько раз нажата кнопка
//и выводим картинку с соответствующей цифрой		
        function click_fon() {
            if(fon_num>=fon_all) {fon_num=1;}
            else { fon_num=fon_num+1;}
            hmUI.showToast({text: "fon " + parseInt(fon_num) });
                  fon_img.setProperty(hmUI.prop.SRC, "fon_" + parseInt(fon_num) + ".png");
            }
	
//сама картинка
            fon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,//x картинки
              y: 0,//y картинки
              src: 'fon_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			  
//кнопка
            btn_fon = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 183,//x кнопки
              y: 183,//y кнопки
              text: '',
              w: 100,//ширина кнопки
              h: 100,//высота кнопки
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_fon();//имя вызываемой функции
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_fon.setProperty(hmUI.prop.VISIBLE, true);