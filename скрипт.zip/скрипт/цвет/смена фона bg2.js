let bg_list = [
    'bg_1.png',
    'bg_2.png',
    'bg_3.png',
    'bg_4.png',
];
let bg_index = 0;

function bg_switching() {
    bg_index++;
    if (bg_index >= bg_list.length) bg_index = 0;
    normal_background_bg_img.setProperty(hmUI.prop.SRC, bg_list[bg_index]);
}



        кнопка

        console.log('Watch_Face.Buttons');
        Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 325,
          y: 220,
          w: 100,
          h: 40,
          text: '',
          color: 0xFFFF8C00,
          text_size: 25,
          press_src: 'bat_1.png',
          normal_src: 'bat_1.png',
          click_func: (button_widget) => {
            bg_switching();
          }, // end func
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button



        Создаем циферблат. В качестве фона устанавливаем первое изображение из желаемого набора фонов.
Копируем в папку с циферблатом файл user_functions.js из архива.
Открываем скопированный файл и меняем в нем 'bg_1.png', 'bg_2.png', 'bg_3.png' на имена файлов используемых для фона. При необходимости добавляем или уменьшаем их количество.
В редакторе создаем кнопку. Настраиваем ее вид.
Дважды щелкнув по кнопке в качестве кода для функции пишем "bg_switching();" (без кавычек).
Запаковываем циферблат и пользуемся.