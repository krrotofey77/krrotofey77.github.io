﻿// Start chang color line

         let colornumber = 1
        let totalcolors = 7
        let namecolor = ''

        function click_Color() {
            if(colornumber>=totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }

if ( colornumber == 1) { namecolor = "BLUE"}
if ( colornumber == 2) { namecolor = "GREEN"}
if ( colornumber == 3) { namecolor = "YELLOW"}
if ( colornumber == 4) { namecolor = "RED"}
if ( colornumber == 5) { namecolor = "MAGENTA"}
if ( colornumber == 6) { namecolor = "ORANGE"}
if ( colornumber == 7) { namecolor = "GRAY"}
hmUI.showToast({text: namecolor });


normal_image_img.setProperty(hmUI.prop.SRC, "Line" + parseInt(colornumber) + ".png");                                 
normal_fat_burning_icon_img.setProperty(hmUI.prop.SRC, "LCD_U_" + parseInt(colornumber) + ".png");       
normal_stress_icon_img.setProperty(hmUI.prop.SRC, "LCD_D_" + parseInt(colornumber) + ".png")
}
/////////////////////////////////////////
Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: -2,
    y: 193,
    w: 46,
    h: 103,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'empty.png',
    normal_src: 'empty.png',
    click_func: (button_widget) => {
      //color
click_Color()
    }, // end func
    show_level: hmUI.show_level.ONLY_NORMAL,
  }); // end button 