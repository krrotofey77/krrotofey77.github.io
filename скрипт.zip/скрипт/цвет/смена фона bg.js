    let colornumber_main = 1
        let totalcolors_main = 20
        let namecolor_main = ''

        function click_Color() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }

			
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg" + parseInt(colornumber_main) + ".png");																											 
         
        }
///////////////////////////////////////////////////////////////////////////////////////////////
        Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 256,
          y: 422,
          w: 143,
          h: 40,
          text: '',
          color: 0xFFFF8C00,
          text_size: 25,
          press_src: 'empty.png',
          normal_src: 'empty.png',
          click_func: (button_widget) => {
            click_Color();
    vibro(25);
          }, // end func
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button
