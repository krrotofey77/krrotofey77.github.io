
        //let bezel_img = ''
        let btn_bezel = ''
        let btn_bezel_left = ''
        let color_bg = ['0xFF5fd8f7', '0xFFf4f25f', '0xFF5fc593', '0xFF6ef6b8', '0xFF82fc8f', '0xFFcafc81', '0xFFffac5e', '0xFFf2757d', '0xFFf36db6', '0xFFfc81eb', '0xFFd082fc', '0xFF9f7db9', '0xFF84a2fc', '0xFF639975', '0xFF8ad2ac', '0xFFb2ddc2', '0xFF7ad5d0', '0xFFc59c70', '0xFF896b9d', '0xFF5f98ac', '0xFFc15f98', '0xFFf5a4ad', '0xFF948c89', '0xFFdadada', '0xFF5f5f5f', '0xFFffffff'];

        let yarlik_left_right_num = 0
    		let yarlik_left_right_all = 25

    		function up_click_right() {
    			yarlik_left_right_num = (yarlik_left_right_num + 1) % (yarlik_left_right_all + 1);
    			up_click_left_right();
    		}

    		function up_click_left() {
    			yarlik_left_right_num = yarlik_left_right_num - 1;
    			if (yarlik_left_right_num < 0) {
    				yarlik_left_right_num = yarlik_left_right_all
    			};
    			up_click_left_right();
    		}

    		function up_click_left_right() {
    			/*normal_background_bg.setProperty(hmUI.prop.MORE, {
    			    color: color_bg[yarlik_left_right_num],
    			   });*/
				   normal_background_bg.setProperty(hmUI.prop.MORE, {
    				x: 0,
    				y: 0,
    				w: 480,
    				h: 480,
    				color: color_bg[yarlik_left_right_num],
    				show_level: hmUI.show_level.ONLY_NORMAL,
    			});

    		};
/////////////////////////////////////////////////////////////////////////////////////////////////////
normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT);

up_click_left_right();

normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
x: 0,
y: 0,
src: 'Bezel_1.png',
show_level: hmUI.show_level.ONLY_NORMAL,
});
///////////////////////////////////////////////////////////////////////////////////////////////////////

			btn_bezel_left= hmUI.createWidget(hmUI.widget.BUTTON, {
				x: 184,
				y: 0,
				text: '',
				w: 97,
				h: 97,
				normal_src: '',
				press_src: '',
				click_func: () => {
				  up_click_left();
					vibro(25);
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
			  });
			  btn_bezel_left.setProperty(hmUI.prop.VISIBLE, true);
  
			  btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
				x: 184,
				y: 369,
				text: '',
				w: 97,
				h: 97,
				normal_src: '',
				press_src: '',
				click_func: () => {
				  up_click_right();
					vibro(25);
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
			  });
			  btn_bezel.setProperty(hmUI.prop.VISIBLE, true);
  