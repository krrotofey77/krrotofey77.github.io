﻿let color1number_main = 1
        let totalcolor1s_main = 16
        let namecolor1_main = ''
		let colorstring = '0xFFFF8000'
		
		function click_COLOR() {
            if(color1number_main>=totalcolor1s_main) {
            color1number_main=1;
                }
            else {
                color1number_main=color1number_main+1;
            }
			if ( color1number_main == 1) { namecolor1_main = "цвет 1"
				colorstring = '0xFFFF8000'
			}
			if ( color1number_main == 2) { namecolor1_main = "цвет 2"
				colorstring = '0xFF008080'
			}
			if ( color1number_main == 3) { namecolor1_main = "цвет 3"
				colorstring = '0xFF808000'
			}
			if ( color1number_main == 4) { namecolor1_main = "цвет 4"
				colorstring = '0xFF800000'
			}
			if ( color1number_main == 5) { namecolor1_main = "цвет 5"
				colorstring = '0xFF00FFFF'
			}
			if ( color1number_main == 6) { namecolor1_main = "цвет 6"
				colorstring = '0xFF008000'
			}
			if ( color1number_main == 7) { namecolor1_main = "цвет 7"
				colorstring = '0xFFFF0000'
			}
			if ( color1number_main == 8) { namecolor1_main = "цвет 8"
				colorstring = '0xFFFFFF00'
			}
			if ( color1number_main == 9) { namecolor1_main = "цвет 9"
				colorstring = '0xFFBFFF00'
			}
			if ( color1number_main == 10) { namecolor1_main = "цвет 10"
				colorstring = '0xFFA020F0'
			}
			if ( color1number_main == 11) { namecolor1_main = "цвет 11"
				colorstring = '0xFF0000FF'
			}
			if ( color1number_main == 12) { namecolor1_main = "цвет 12"
				colorstring = '0xFFFF00FF'
			}
			if ( color1number_main == 13) { namecolor1_main = "цвет 13"
				colorstring = '0xFFA5694F'
			}
			if ( color1number_main == 14) { namecolor1_main = "цвет 14"
				colorstring = '0xFFFFBF00'
			}
			if ( color1number_main == 15) { namecolor1_main = "цвет 15"
				colorstring = '0xFFC0C0C0'
			}
			if ( color1number_main == 16) { namecolor1_main = "цвет 16"
				colorstring = '0xFFFFFFFF'
			}

			if ( color1number_main <= 16) { 
			
			normal_background_bg.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: colorstring,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_time_hour_text_font.setProperty(hmUI.prop.MORE, {
              x: 35,
              y: 200,
              w: 200,
              h: 100,
              text_size: 100,
              char_space: -5,
              line_space: 0,
              font: 'fonts/1.ttf',
              color: colorstring,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_time_minute_text_font.setProperty(hmUI.prop.MORE, {
              x: 250,
              y: 200,
              w: 200,
              h: 100,
              text_size: 100,
              char_space: -5,
              line_space: 0,
              font: 'fonts/1.ttf',
              color: colorstring,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			}
			hmUI.showToast({text: namecolor1_main });
        }
    //////////////////////////////////////////////
    Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
        x: 183,
        y: 183,
        w: 100,
        h: 100,
        text: '',
        color: 0xFFFF8C00,
        text_size: 25,
        press_src: '0_Empty.png',
        normal_src: '0_Empty.png',
        click_func: (button_widget) => {
                          click_COLOR();
        }, // end func
        show_level: hmUI.show_level.ONLY_NORMAL,
      }); // end button
    
