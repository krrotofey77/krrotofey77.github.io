этом коротком коде прогноз погоды на 2 дня выводится в функции weather_few_days().
Сейчас он показывает:
i = 0 → сегодня
i = 1 → завтра
Чтобы сдвинуть прогноз на день вперёд (т.е. показывать завтра + послезавтра), нужно изменить индекс данных прогноза с i на i + 1.
Где и что менять
Найдите функцию weather_few_days() и измените все четыре места, где используется forecastData.data[i] → на forecastData.data[i + 1].
Вот как должна выглядеть исправленная функция целиком:
///////////////////////
function weather_few_days() {
    console.log('weather_few_days()');
    let weatherData = weatherSensor.getForecastWeather();
    let forecastData = weatherData.forecastData;

    for (let i = 0; i < 2; i++) {
        let dataIndex = i + 1;   // ← главное изменение: сдвиг на +1 день

        // День недели (тоже сдвигаем на +1)
        if (screenType == hmSetting.screen_type.WATCHFACE) {
            let dowIndex = timeSensor.week - 1;
            dowIndex += dataIndex;           // было i → стало dataIndex
            while (dowIndex >= 7) {dowIndex -= 7;}
            normal_forecast_date_week_font[i].setProperty(hmUI.prop.TEXT, normal_forecast_date_week_font_Array[dowIndex]);
        };
      
        // Средняя температура
        let averageTemperature = '-';
        if (dataIndex < forecastData.count) {
            averageTemperature = parseInt((forecastData.data[dataIndex].high + forecastData.data[dataIndex].low)/2).toString();
        }
        if (screenType == hmSetting.screen_type.WATCHFACE) {
            normal_forecast_average_text_font[i].setProperty(hmUI.prop.TEXT, averageTemperature);
        };
        
        // Макс / мин
        let normal_max_min_Temperature_font = '-';
        if (dataIndex < forecastData.count) {
            normal_max_min_Temperature_font = forecastData.data[dataIndex].high.toString();
            normal_max_min_Temperature_font += '';
            normal_max_min_Temperature_font += forecastData.data[dataIndex].low.toString();
        };
        if (screenType == hmSetting.screen_type.WATCHFACE) {
            normal_forecast_high_low_text_font[i].setProperty(hmUI.prop.TEXT, normal_max_min_Temperature_font);
        };
        
        // Иконка погоды
        if (screenType == hmSetting.screen_type.WATCHFACE) {
            let weatherIndex = 25;
            if (dataIndex < forecastData.count) {
                weatherIndex = forecastData.data[dataIndex].index;
            }
            normal_forecast_image_progress_img_level[i].setProperty(hmUI.prop.SRC, normal_forecast_image_array[weatherIndex]);
        };
    }
}
///////////////////
Самый минимальный вариант (если не хочешь вводить переменную dataIndex)

Просто замени во всех четырёх местах [i] на [i+1]:
if (i+1 < forecastData.count) averageTemperature = parseInt((forecastData.data[i+1].high + forecastData.data[i+1].low)/2).toString();

normal_max_min_Temperature_font = forecastData.data[i+1].high.toString();
normal_max_min_Temperature_font += '';
normal_max_min_Temperature_font += forecastData.data[i+1].low.toString();

weatherIndex = forecastData.data[i+1].index;
Но вариант с dataIndex понятнее и безопаснее.

Дополнительно (рекомендую)
Чтобы прогноз обновлялся при смене дня, добавь вызов функции в обработчик:
timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
    weather_few_days();
});
Удачи с циферблатом!