let normal_image_img = null;
let btn_decrease = null;
let btn_increase = null;
let opacityText = null;
let opacityTimer = null;

// 0% = полностью прозрачная
let opacityPercentage = 0;


// ===== Обновление прозрачности =====
function updateOpacity() {
  const alpha = Math.round((opacityPercentage / 100) * 255);
  normal_image_img.setProperty(hmUI.prop.ALPHA, alpha);
}


// ===== Показ процента =====
function showOpacityText() {

  if (!opacityText) {
    opacityText = hmUI.createWidget(hmUI.widget.TEXT, {
      x: 183,
      y: 50,
      w: 100,
      h: 50,
      text: "",
      color: 0xFFFFFF,
      text_size: 30,
      align_h: hmUI.align.CENTER_H,
      align_v: hmUI.align.CENTER_V,
      show_level: hmUI.show_level.ONLY_NORMAL
    });
  }

  opacityText.setProperty(hmUI.prop.TEXT, opacityPercentage + "%");
  opacityText.setProperty(hmUI.prop.VISIBLE, true);

  if (opacityTimer) {
    clearTimeout(opacityTimer);
  }

  opacityTimer = setTimeout(() => {
    opacityText.setProperty(hmUI.prop.VISIBLE, false);
    opacityTimer = null;
  }, 2000);
}


// ===== Уменьшение (делаем более прозрачной) =====
function decreaseOpacity() {
  opacityPercentage = Math.max(0, opacityPercentage - 10);
  updateOpacity();
  showOpacityText();
}


// ===== Увеличение (делаем более видимой) =====
function increaseOpacity() {
  opacityPercentage = Math.min(100, opacityPercentage + 10);
  updateOpacity();
  showOpacityText();
}


////////////////////////////////////////////////////////////

// ===== Картинка =====
normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
  x: 0,
  y: 0,
  src: "0002.png",
  show_level: hmUI.show_level.ONLY_NORMAL
});

// применяем стартовую прозрачность (0%)
updateOpacity();


// ===== Кнопка "-" =====
btn_decrease = hmUI.createWidget(hmUI.widget.TEXT, {
  x: 0,
  y: 183,
  w: 100,
  h: 100,
  text: "-",
  color: 0xFFFFFF,
  text_size: 80,
  align_h: hmUI.align.CENTER_H,
  align_v: hmUI.align.CENTER_V,
  show_level: hmUI.show_level.ONLY_NORMAL
});

btn_decrease.addEventListener(hmUI.event.CLICK_DOWN, decreaseOpacity);


// ===== Кнопка "+" =====
btn_increase = hmUI.createWidget(hmUI.widget.TEXT, {
  x: 366,
  y: 183,
  w: 100,
  h: 100,
  text: "+",
  color: 0xFFFFFF,
  text_size: 80,
  align_h: hmUI.align.CENTER_H,
  align_v: hmUI.align.CENTER_V,
  show_level: hmUI.show_level.ONLY_NORMAL
});

btn_increase.addEventListener(hmUI.event.CLICK_DOWN, increaseOpacity);

logger.log("Opacity control initialized (start transparent)");