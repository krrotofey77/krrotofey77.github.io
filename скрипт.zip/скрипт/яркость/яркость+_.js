﻿
    // Глобальные переменные для виджетов
    let normal_image_img = null;
    let btn_mask = null;     // Кнопка для уменьшения прозрачности
    let btn_mask_2 = null;   // Кнопка для увеличения прозрачности
    let imageOpacity = 255;  // Начальная прозрачность (0-255 для Zepp OS)
    const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

    // Функция уменьшения прозрачности
    function decreaseImageOpacity() {
      if (imageOpacity > 26) { // Минимум ~10% (26 из 255)
        imageOpacity -= 26;    // Шаг уменьшения (10%)
        normal_image_img.setProperty(hmUI.prop.ALPHA, imageOpacity);
        logger.log('Opacity decreased to: ' + imageOpacity);
      } else {
        imageOpacity = 0;      // Устанавливаем минимум, если меньше шага
        normal_image_img.setProperty(hmUI.prop.ALPHA, imageOpacity);
        logger.log('Opacity already at minimum (0%)');
      }
    }

    // Функция увеличения прозрачности
    function increaseImageOpacity() {
      if (imageOpacity < 229) { // Ограничение, чтобы не превысить 255 при шаге 26
        imageOpacity += 26;     // Шаг увеличения (10%)
        normal_image_img.setProperty(hmUI.prop.ALPHA, imageOpacity);
        logger.log('Opacity increased to: ' + imageOpacity);
      } else {
        imageOpacity = 255;     // Устанавливаем максимум
        normal_image_img.setProperty(hmUI.prop.ALPHA, imageOpacity);
        logger.log('Opacity already at maximum (100%)');
      }
    }

   //////////////////////////////////////////////////////////////////////////////
        // Переднее изображение с прозрачностью
        normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          src: 'bg_3.png',      // Передний план
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_image_img.setProperty(hmUI.prop.ALPHA, imageOpacity);

        // Кнопка для уменьшения прозрачности
        btn_mask = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 0,
          y: 183,
          w: 100,
          h: 100,
          normal_src: 'empty.png', // Замените на реальный файл
          press_src: 'empty.png',   // Замените на реальный файл
          click_func: decreaseImageOpacity,
          show_level: hmUI.show_level.ONLY_NORMAL
        });
        btn_mask.setProperty(hmUI.prop.VISIBLE, true);

        // Кнопка для увеличения прозрачности
        btn_mask_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 370,              // 466 - 80 = 386, чтобы уместиться на экране
          y: 183,
          w: 100,
          h: 100,
          normal_src: 'empty.png', // Замените на реальный файл
          press_src: 'empty.png',   // Замените на реальный файл
          click_func: increaseImageOpacity,
          show_level: hmUI.show_level.ONLY_NORMAL
        });
        btn_mask_2.setProperty(hmUI.prop.VISIBLE, true);

        logger.log('Watch Face Initialized with two buttons');
     