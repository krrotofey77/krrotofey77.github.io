﻿
    let normal_image_img = '';
    let btn_decrease = '';     // Кнопка для уменьшения прозрачности
    let btn_increase = '';     // Кнопка для увеличения прозрачности
    let opacityText = null;    // Текстовый виджет для отображения прозрачности
    let opacityPercentage = 0; // Начальная прозрачность в процентах (100-0)

    // Функция для обновления прозрачности изображения
    function updateOpacity() {
      const opacity = Math.round((opacityPercentage / 100) * 255); // Переводим проценты в 0-255
      normal_image_img.setProperty(hmUI.prop.ALPHA, opacity);
    }

    // Функция для отображения текста с процентом прозрачности
    function showOpacityText() {
      if (opacityText) {
        hmUI.deleteWidget(opacityText);
      }

      opacityText = hmUI.createWidget(hmUI.widget.TEXT, {
        x: 183,              // Центр экрана: (466 - 100) / 2
        y: 50,              // Чуть выше кнопок
        w: 100,
        h: 50,
        text: `${opacityPercentage}%`,
        color: 0xFFFFFF,     // Белый цвет текста
        text_size: 30,       // Размер шрифта
        align_h: hmUI.align.CENTER_H,
        align_v: hmUI.align.CENTER_V,
        show_level: hmUI.show_level.ONLY_NORMAL
      });

      setTimeout(() => {
        if (opacityText) {
          hmUI.deleteWidget(opacityText);
          opacityText = null;
        }
      }, 2000);
    }

    // Функция уменьшения прозрачности
    function decreaseOpacity() {
      if (opacityPercentage > 0) {
        opacityPercentage -= 10; // Шаг 10%
        updateOpacity();
        logger.log('Opacity decreased to: ' + opacityPercentage + '%');
        showOpacityText();
      }
    }

    // Функция увеличения прозрачности
    function increaseOpacity() {
      if (opacityPercentage < 100) {
        opacityPercentage += 10; // Шаг 10%
        updateOpacity();
        logger.log('Opacity increased to: ' + opacityPercentage + '%');
        showOpacityText();
      }
    }

    //////////////////////////////////////////////////////

        // Переднее изображение с изменяемой прозрачностью
        normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          src: '0002.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        updateOpacity(); // Устанавливаем начальную прозрачность

        // Кнопка уменьшения прозрачности
        btn_decrease = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 0,
          y: 183,
          w: 100,
          h: 100,
          normal_src: 'btn_down_normal.png',
          press_src: 'btn_down_press.png',
          click_func: decreaseOpacity,
          show_level: hmUI.show_level.ONLY_NORMAL
        });
        btn_decrease.setProperty(hmUI.prop.VISIBLE, true);

        // Кнопка увеличения прозрачности
        btn_increase = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 366, // 466 - 80
          y: 183,
          w: 100,
          h: 100,
          normal_src: 'btn_up_normal.png',
          press_src: 'btn_up_press.png',
          click_func: increaseOpacity,
          show_level: hmUI.show_level.ONLY_NORMAL
        });
        btn_increase.setProperty(hmUI.prop.VISIBLE, true);

        logger.log('Watch Face Initialized with opacity control');
     