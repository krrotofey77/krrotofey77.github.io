// ======================================================
// === ИНИЦИАЛИЗАЦИЯ ===================================
// ======================================================

const { width: DEVICE_WIDTH, height: DEVICE_HEIGHT } = hmSetting.getDeviceInfo();

let group1 = null;
let group2 = null;
let switchButton = null;

let activeGroup = 1; // 1 или 2 — какая группа сейчас активна

// ======================================================
// === СОЗДАНИЕ ГРУПП ==================================
// ======================================================

function createGroups() {

    // ---------- ГРУППА 1 ----------
    group1 = hmUI.createWidget(hmUI.widget.GROUP, {
        x: 0,
        y: 0,
        w: DEVICE_WIDTH,
        h: DEVICE_HEIGHT,
    });

    // Пример элементов внутри group1
    group1.createWidget(hmUI.widget.TEXT, {
        x: 150,
        y: 150,
        w: 200,
        h: 40,
        text: "GROUP 1",
        text_size: 30,
        color: 0xffffff,
    });

    group1.createWidget(hmUI.widget.IMG, {
        x: 200,
        y: 220,
        src: "step.png",
    });


    // ---------- ГРУППА 2 ----------
    group2 = hmUI.createWidget(hmUI.widget.GROUP, {
        x: 0,
        y: 0,
        w: DEVICE_WIDTH,
        h: DEVICE_HEIGHT,
    });

    group2.createWidget(hmUI.widget.TEXT, {
        x: 150,
        y: 150,
        w: 200,
        h: 40,
        text: "GROUP 2",
        text_size: 30,
        color: 0xff0000,
    });

    group2.createWidget(hmUI.widget.IMG, {
        x: 200,
        y: 220,
        src: "heart.png",
    });

    // По умолчанию вторая группа скрыта
    group2.setProperty(hmUI.prop.VISIBLE, false);
}

// ======================================================
// === КНОПКА ПЕРЕКЛЮЧЕНИЯ =============================
// ======================================================

function createSwitchButton() {

    switchButton = hmUI.createWidget(hmUI.widget.IMG, {
        x: DEVICE_WIDTH - 80,
        y: DEVICE_HEIGHT - 80,
        w: 60,
        h: 60,
        src: "switch.png",
    });

    // Обработчик нажатия
    switchButton.addEventListener(hmUI.event.CLICK_UP, function () {
        toggleGroups();
    });
}

// ======================================================
// === ЛОГИКА ПЕРЕКЛЮЧЕНИЯ ==============================
// ======================================================

function toggleGroups() {

    if (activeGroup === 1) {

        group1.setProperty(hmUI.prop.VISIBLE, false);
        group2.setProperty(hmUI.prop.VISIBLE, true);
        activeGroup = 2;

    } else {

        group1.setProperty(hmUI.prop.VISIBLE, true);
        group2.setProperty(hmUI.prop.VISIBLE, false);
        activeGroup = 1;
    }
}

// ======================================================
// === ЗАПУСК ==========================================
// ======================================================

createGroups();
createSwitchButton();