	const { width: DEVICE_WIDTH, height: DEVICE_HEIGHT } = hmSetting.getDeviceInfo();
		
		let group1 = ''
		let group2 = ''
		let group3 = ''
		let group4 = ''


		group1 = hmUI.createWidget(hmUI.widget.GROUP, {
			x: 0,
			y: 0,
			w: DEVICE_WIDTH,
			h: DEVICE_HEIGHT,
  });

  normal_step_icon_img = group1.createWidget(hmUI.widget.IMG, {
	x: 172,
	y: 270,
	src: 'step.png',
	show_level: hmUI.show_level.ONLY_NORMAL,
  });		