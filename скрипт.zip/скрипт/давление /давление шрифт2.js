﻿/*
 * Минимальный Шаблон Циферблата для Отображения Давления
 * Этот шаблон сохраняет только логику для чтения и отображения барометрического давления.
 */

try {
  (() => {
    // #region Функции для работы с барометрическим давлением

    /**
     * Читает данные о давлении из определенного пути к файлу в файловой системе устройства.
     * Ожидается, что данные о давлении хранятся в виде значений Float32.
     * @returns {Float32Array|null} Массив значений давления или null, если чтение файла не удалось.
     */
    function read_pressure() {
        console.log("read_pressure()");
        // Путь к файлу данных о давлении (может потребоваться корректировка для вашей среды)
        const file_name_alt = "../../../baro_altim/pressure.dat";
        const [fs_stat, err] = hmFS.stat(file_name_alt);
        
        if (err == 0) {
            let file_size = fs_stat.size;
            const len = file_size / 4; // Каждый Float32 занимает 4 байта
            console.log(`size_alt: ${file_size}, lenght: ${len}`);
            const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY);
        
            let array_buffer = new Float32Array(len);
            // Читаем данные в базовый буфер Float32Array
            hmFS.read(fh, array_buffer.buffer, 0, file_size);
            hmFS.close(fh);
            console.log(`value ${array_buffer[array_buffer.length - 1]}`);
            return array_buffer;
        } else {
            console.log('err:', err);
        }
        return null;
    }
  
    /**
     * Находит самое последнее ненулевое значение давления, просматривая массив с конца.
     * Просматривается до 3 часов данных (30 записей/час * 3 часа = 90 записей).
     * Исходное значение конвертируется из Паскалей в Гектопаскали (гПа) делением на 100.
     * @param {Float32Array|null} pressure_array Массив значений давления (в Паскалях).
     * @returns {number} Самое последнее ненулевое значение давления в гПа или 0.
     */
    function getPressureValue(pressure_array) {
        console.log("getPressureValue()");
        if (pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
        
        let start_index = pressure_array.length - 1;
        // Просмотреть 90 записей (3 часа * 30 записей/час)
        let end_index = start_index - 30 * 3; 
        if (end_index < 0) end_index = 0;
        
        for (let index = start_index; index >= end_index; index--) {
            if (pressure_array[index] != 0) {
                // Возвращаем значение, преобразованное в гПа (исходное значение в Па)
                return parseInt(pressure_array[index] / 100); 
            }
        }
        return 0;
    }
  
    /**
     * Конвертирует значение давления из Гектопаскалей (гПа) в миллиметры ртутного столба (мм.рт.ст.).
     * Коэффициент конвертации: 1 гПа ≈ 0.750064 мм.рт.ст.
     * @param {number} hPa_value Значение давления в гПа.
     * @returns {number} Значение давления в мм.рт.ст., округленное до ближайшего целого числа.
     */
    function hPa_To_mmHg(hPa_value = 0) {
        let mmHg = Math.round(hPa_value * 0.750064);
        return mmHg;
    }
    // #endregion
  
    let text_pressere; // Объект виджета для отображения давления

    const e = __$$hmAppManager$$__.currentApp;
    const o = e.current;

    o.module = DeviceRuntimeCore.WatchFace({
        init_view() {
            // Создаем виджет TEXT для отображения значения давления
            text_pressere = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 100, // Координата X
                y: 100, // Координата Y
                w: 200, // Ширина
                h: 50,  // Высота
                text_size: 30, // Размер шрифта
                text: "--",    // Текст по умолчанию
                color: 0xffffff, // Белый цвет
                align_h: hmUI.align.LEFT,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // Делегат для обработки событий, когда циферблат возобновляет работу (экран включается)
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                resume_call: (function () {
                    // 1. Читаем массив данных о давлении
                    let pressure_array = read_pressure();

                    // 2. Получаем самое последнее действительное значение давления в гПа
                    let value_hPa = getPressureValue(pressure_array);

                    // 3. Конвертируем гПа в мм.рт.ст.
                    let value_mmHg = hPa_To_mmHg(value_hPa); 
                    
                    // Выберите, какой модуль отобразить: value_hPa или value_mmHg

                    // 4. Форматируем и отображаем выбранное значение (здесь используется мм.рт.ст.)
                    let value_str = value_mmHg == 0 ? "--" : value_mmHg + " мм.";
                    // Для отображения в гПа используйте:
                    // let value_str = value_hPa == 0 ? "--" : value_hPa + " гПа"; 

                    text_pressere.setProperty(hmUI.prop.TEXT, value_str);
                }),
            });
        },
        
        onInit() {
            // Вызывается при инициализации циферблата
        },
        
        build() {
            this.init_view();
        },
        
        onDestroy() {
            // Вызывается при уничтожении циферблата
        }
    });
  })()
} catch (e) {
  console.log("Mini Program Error", e);
  e && e.stack && e.stack.split(/\n/).forEach((e => console.log("error stack", e)));
}
