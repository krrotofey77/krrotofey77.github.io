﻿try {
(() => {

    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    const __$$module$$__ = __$$app$$__.current;

    const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_pressure');

    let pressureNumberWidget = null;
    let mmImageWidget = null;
    let baroSensor = null;

    const MMHG_COEF = 0.75006375541921;

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({

        init_view() {

            console.log('WatchFace init');

            // цифры давления (картинками)
            pressureNumberWidget = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                x: 140,
                y: 180,
                font_array: [
                    "font_0.png","font_1.png","font_2.png","font_3.png","font_4.png",
                    "font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"
                ],
                h_space: 0,
                align_h: hmUI.align.CENTER_H
            });

            // "mm" как картинка
            mmImageWidget = hmUI.createWidget(hmUI.widget.IMG, {
                x: 260,   // подстрой под свой дизайн
                y: 185,
                src: "mm.png" // <-- файл с текстом "mm"
            });

            // сенсор давления
            baroSensor = hmSensor.createSensor(hmSensor.id.BARO);

            function updatePressure() {

                if (!baroSensor) return;

                let pressureValue = baroSensor.pressure;

                if (!pressureValue) {
                    console.log('No pressure data');
                    return;
                }

                let pressure = Math.round(pressureValue * MMHG_COEF).toString();

                pressureNumberWidget.setProperty(
                    hmUI.prop.TEXT,
                    pressure
                );
            }

            // первый запуск
            updatePressure();

            // обновление каждые 5 сек
            setInterval(updatePressure, 5000);
        },

        onInit() {
            logger.log('init');
        },

        build() {
            this.init_view();
            logger.log('build');
        },

        onDestroy() {
            logger.log('destroy');
        }

    });

})();
} catch (e) {
    console.log('Error', e);
}