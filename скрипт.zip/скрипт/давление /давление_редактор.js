﻿    
        class AdvancedBarometer {
            constructor(props = {}) {
              this.props = {
                  unit_index: hmFS.SysProGetInt('BaroUnitIndex') ?? 0,		// текущий индекс единицы измерения (сохраняется и считывается из памяти): 0 - мм рт.ст., 1 - гПа
                  show_toast: true,											// показывать всплывающее сообщение при переключении единицы измерения
                  widget: null,												// виджет TEXT для отображения давления
                  show_trend: true,											// показывать тренд (растет, падает) после значения давления при обновлении виджета
                  time_sensor: null,											// сенсор времени (для обновления давления), если не задан, то создается новый
                  auto_update: true,											// автоматическое обновление погоды (нет необходимости добавлять метод .update() в event.MINUTEEND и WIDGET_DELEGATE)
                  lang: hmSetting.getLanguage() == 4 ? 0 : 1,					// языка устройства	(Русский = 0 / Английский = 1)
                  ...props,
              };
      
              this.unitStr = [	['мм рт.ст.',  'mmHg'],		// 0
                                  ['гПа',  'hPa'],			// 1	
                              ]
      
              this.last = {
                  value: '--',
                  trend: '',
              }
      
              if (!this.props.time_sensor) this.props.time_sensor = hmSensor.createSensor(hmSensor.id.TIME);
              if (isFinite(props.unit_index)) hmFS.SysProSetInt('BaroUnitIndex', props.unit_index);
              if (this.props.auto_update) this.createHandlers();
            }
      
          // создание обработчиков автоматического обновления давления
              createHandlers() {
                  this.props.time_sensor.addEventListener(this.props.time_sensor.event.MINUTEEND, () => this.update());
      
                  this.widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: ( () => this.update() )
                  })
              }
      
          // чтение файла с данными атмосферного давления
              readDataFile() {		
                  const file_name_alt = "../../../baro_altim/pressure.dat";
                  const [fs_stat, err] = hmFS.stat(file_name_alt);
                  if (err == 0) {
                    let file_size = fs_stat.size;
                    const len = file_size / 4;
                    const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY)
                    let array_buffer = new Float32Array(len);
                    hmFS.read(fh, array_buffer.buffer, 0, file_size);
                    hmFS.close(fh);
                    return array_buffer;
                  } else {
                    console.log('err:', err)
                  }
                  return null
              }
                  
          // получение последнего значения в массиве данных из файла
              getLastValue(data_array) {
                  if(!data_array?.length) return null;
                  
                  const start = data_array.length - 1;
                  let end = start - 30 * 3; // 3 часа
                  if(end < 0) end = 0;
                  
                  for (let i = start; i >= end; i--) {
                    if(data_array[i] != 0) return parseInt(data_array[i] / 100);
                  }
                  
                  return null
              }
          
          // получение изменения давления
              getPressureChange(data_array) {
                  if(!data_array?.length) return null;
                  const start = data_array.length - 1;
                  let end = start - 30 * 3; // 3 часа
                  if(end < 0) end = 0;
      
                  let value = data_array[start];
      
                  for (let i = start - 1; i >= end; i--) {
                    let element = data_array[i];
                    if(element != 0) {
                      if(Math.abs(value - element) > 75) { // учитываем только если разница больше 0,75 hPa ~ 1 мм рт.ст.
                        value = value - element;
                        return value;
                      }
                    }
                  }
                  return null
              }
      
          // получить текущее значения  давления и тренда
              getPressureAndTrend(){
                  const data_array = this.readDataFile();
                  const value = this.getLastValue(data_array);
      
                  let trend = ''; //	"•"
                  const pressureChange = this.getPressureChange(data_array);
                  if (pressureChange < 0) trend = "↓";
                  else if (pressureChange > 0) trend = "↑";
      
                  return {value, trend}
              }
      
          // установить единицы измерения по индексу: 0 - мм рт.ст., 1 - гПа
              setUnits(unit_index) {
                  if(!isFinite(unit_index)) return
                  this.props.unit_index = unit_index == 1 ? 1 : 0;
                  hmFS.SysProSetInt('BaroUnitIndex', this.props.unit_index);
                  if (this.props.widget) this.updateWidget();
              }
      
          // переключить единицы измерения на следующие по кругу
              toggleUnits(show_toast = this.props.show_toast) {
                  const newIndex = (this.props.unit_index + 1) % this.unitStr.length;
                  this.setUnits(newIndex);
                  if (show_toast) hmUI.showToast({text: this.unit});
              }
      
          // обновить показания давления и виджет
              update() {
                  const {value, trend}  = this.getPressureAndTrend();
                  if (value != this.last.value){
                      this.last.value = value;
                      this.last.trend = trend;
                      if (this.props.widget) this.updateWidget();
                  }
              }
      
          // обновить виджет
              updateWidget() {
                  let str = this.pressure;
                  if (this.props.show_trend) str += ` ${this.last.trend}`;
                  this.props.widget.setProperty(hmUI.prop.TEXT, str);
              }
      
          // получить текущее значение давление в мм рт. ст.
              get mmHg() {
                  let v = this.last.value;
                  if (!(v)) return '--'
                  else v *= 0.750064;
                  return Math.round(v).toString();
              }
      
          // получить текущее значение давление в гПа
              get hPa() {
                  let v = this.last.value;
                  if (!(v)) return '--'
                  return this.last.value
              }
      
          // получить давление в текущих единицах измерения
              get pressure() {
                  if (this.props.unit_index == 0) return this.mmHg
                  else return this.hPa
              }
      
          // получить название текущей единицы измерения
              get unit() {
                  return this.unitStr[this.props.unit_index][this.props.lang]
              }
      
          // получить индекс текущей единицы измерения
              get unit_index() {
                  return this.props.unit_index
              }
      
          // получить тренд
              get trend() {
                  return this.last.trend
              }
      
          // удалить
            delete() {
              this.props = null;
              this.last = null;
              this.unitStr = null;
              if (this.widgetDelegate) {
                  hmUI.deleteWidget(this.widgetDelegate);
                  this.widgetDelegate = null;
              }
            }
      
          }
        
       
        let normal_altimeter_current_text_font = ''


        ////////////////////////////////////////////////////////////////////////////////////////////////////
                
           

            normal_altimeter_current_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 205,
              y: 213,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

// экземпляр класса
const barometer = new AdvancedBarometer({
	widget: normal_altimeter_current_text_font,
});
            


    