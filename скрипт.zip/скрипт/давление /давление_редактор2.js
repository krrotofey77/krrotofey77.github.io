﻿    

        //dynamic modify start
        class AdvancedBarometer {
            constructor(props = {}) {
              this.props = {
                unit_index: hmFS.SysProGetInt('BaroUnitIndex') ?? 0, // текущий индекс единицы измерения
                show_toast: true, // показывать всплывающее сообщение при переключении единицы измерения
                widget: null, // виджет TEXT для отображения давления
                show_trend: true, // показывать тренд (растет, падает)
                time_sensor: null, // сенсор времени (для обновления давления)
                auto_update: true, // автоматическое обновление погоды
                lang: hmSetting.getLanguage() === 4 ? 0 : 1, // язык устройства (0 - русский, 1 - английский)
                ...props,
              };
          
              this.unitStr = [
                ['мм рт.ст.', 'mmHg'], // 0
                ['гПа', 'hPa'], // 1
              ];
          
              this.last = {
                value: '--',
                trend: '',
              };
          
              // Инициализация сенсора времени, если не передан
              if (!this.props.time_sensor) {
                this.props.time_sensor = hmSensor.createSensor(hmSensor.id.TIME);
              }
          
              // Сохранение индекса единицы измерения, если он передан
              if (isFinite(props.unit_index)) {
                hmFS.SysProSetInt('BaroUnitIndex', props.unit_index);
              }
          
              // Создание обработчиков для автоматического обновления
              if (this.props.auto_update) {
                this.createHandlers();
              }
            }
          
            // Создание обработчиков для автоматического обновления
            createHandlers() {
              this.props.time_sensor.addEventListener(
                this.props.time_sensor.event.MINUTEEND,
                () => this.update()
              );
          
              this.widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                resume_call: () => this.update(),
              });
            }
          
            // Чтение данных из файла
            readDataFile() {
              const file_name_alt = "../../../baro_altim/pressure.dat";
              const [fs_stat, err] = hmFS.stat(file_name_alt);
          
              if (err === 0) {
                const file_size = fs_stat.size;
                const len = file_size / 4;
                const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY);
                const array_buffer = new Float32Array(len);
                hmFS.read(fh, array_buffer.buffer, 0, file_size);
                hmFS.close(fh);
                return array_buffer;
              } else {
                console.log('Ошибка чтения файла:', err);
                return null;
              }
            }
          
            // Получение последнего значения из массива данных
            getLastValue(data_array) {
              if (!data_array?.length) return null;
          
              const start = data_array.length - 1;
              let end = start - 30 * 3; // 3 часа
              if (end < 0) end = 0;
          
              for (let i = start; i >= end; i--) {
                if (data_array[i] !== 0) return parseInt(data_array[i] / 100);
              }
          
              return null;
            }
          
            // Получение изменения давления
            getPressureChange(data_array) {
              if (!data_array?.length) return null;
          
              const start = data_array.length - 1;
              let end = start - 30 * 3; // 3 часа
              if (end < 0) end = 0;
          
              const value = data_array[start];
          
              for (let i = start - 1; i >= end; i--) {
                const element = data_array[i];
                if (element !== 0 && Math.abs(value - element) > 75) {
                  return value - element;
                }
              }
          
              return null;
            }
          
            // Получение текущего значения давления и тренда
            getPressureAndTrend() {
              const data_array = this.readDataFile();
              const value = this.getLastValue(data_array);
          
              let trend = '';
              const pressureChange = this.getPressureChange(data_array);
              if (pressureChange < 0) trend = "↓";
              else if (pressureChange > 0) trend = "↑";
          
              return { value, trend };
            }
          
            // Установка единиц измерения
            setUnits(unit_index) {
              if (!isFinite(unit_index)) return;
          
              this.props.unit_index = unit_index === 1 ? 1 : 0;
              hmFS.SysProSetInt('BaroUnitIndex', this.props.unit_index);
          
              if (this.props.widget) {
                this.updateWidget();
              }
            }
          
            // Переключение единиц измерения
            toggleUnits(show_toast = this.props.show_toast) {
              const newIndex = (this.props.unit_index + 1) % this.unitStr.length;
              this.setUnits(newIndex);
          
              if (show_toast) {
                hmUI.showToast({ text: this.unit });
              }
            }
          
            // Обновление данных и виджета
            update() {
              const { value, trend } = this.getPressureAndTrend();
          
              if (value !== this.last.value) {
                this.last.value = value;
                this.last.trend = trend;
          
                if (this.props.widget) {
                  this.updateWidget();
                }
              }
            }
          
            // Обновление виджета
            updateWidget() {
              let str = this.pressure;
              if (this.props.show_trend) {
                str += ` ${this.last.trend}`;
              }
              this.props.widget.setProperty(hmUI.prop.TEXT, str);
            }
          
            // Получение давления в мм рт. ст.
            get mmHg() {
              const v = this.last.value;
              if (!v) return '--';
              return Math.round(v * 0.750064).toString();
            }
          
            // Получение давления в гПа
            get hPa() {
              const v = this.last.value;
              if (!v) return '--';
              return v.toString();
            }
          
            // Получение давления в текущих единицах измерения
            get pressure() {
              return this.props.unit_index === 0 ? this.mmHg : this.hPa;
            }
          
            // Получение названия текущей единицы измерения
            get unit() {
              return this.unitStr[this.props.unit_index][this.props.lang];
            }
          
            // Удаление ресурсов
            delete() {
              this.props = null;
              this.last = null;
              this.unitStr = null;
          
              if (this.widgetDelegate) {
                hmUI.deleteWidget(this.widgetDelegate);
                this.widgetDelegate = null;
              }
            }
          }
          
        
      ////////////////////////////////////////////////////////////////////////////////////
                    
                
            // FontName: Montserrat_Medium.ttf; FontSize: 36
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 506,
              h: 60,
              text_size: 36,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Montserrat_Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        

           // Создание виджета
const normal_altimeter_current_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 151,
              y: 213,
              w: 150,
              h: 50,
              text_size: 36,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Montserrat_Medium.ttf',
              alpha: 250,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

// Создание экземпляра класса
const barometer = new AdvancedBarometer({
    widget: normal_altimeter_current_text_font,
  });
       