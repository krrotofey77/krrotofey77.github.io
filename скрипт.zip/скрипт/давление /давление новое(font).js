﻿try {
(() => {

    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    const __$$module$$__ = __$$app$$__.current;

    const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_pressure');

    let pressureTextWidget = null;
    let baroSensor = null;

    const MMHG_COEF = 0.75006375541921;

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({

        init_view() {

            console.log('WatchFace init');

            // создаём текстовый виджет
            pressureTextWidget = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 150,
                y: 180,
                w: 200,
                h: 50,
                text: '-- mm',
                text_size: 32,
                font: 'fonts/akziden_bold.ttf',
                align_h: hmUI.align.CENTER_H,
                color: 0xFFFFFF
            });

            // создаём сенсор
            baroSensor = hmSensor.createSensor(hmSensor.id.BARO);

            // функция обновления
            function updatePressure() {

                if (!baroSensor) return;

                let pressureValue = baroSensor.pressure;

                if (!pressureValue) {
                    console.log('No pressure data');
                    return;
                }

                let pressure = Math.round(pressureValue * MMHG_COEF);

                pressureTextWidget.setProperty(
                    hmUI.prop.TEXT,
                    pressure + ' mm'
                );
            }

            // первое обновление
            updatePressure();

            // обновление каждые 5 сек
            setInterval(updatePressure, 5000);
        },

        onInit() {
            logger.log('init');
        },

        build() {
            this.init_view();
            logger.log('build');
        },

        onDestroy() {
            logger.log('destroy');
        }

    });

})();
} catch (e) {
    console.log('Error', e);
}