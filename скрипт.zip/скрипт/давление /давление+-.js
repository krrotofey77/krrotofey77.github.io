﻿/*
    ** GTR 4 API 3.5 - AdvancedBarometer v1.6
    ** Стрелки с первой минуты!
*/
try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        const __$$module$$__ = __$$app$$__.current;
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_BaroGTR4');

        let Button_Baro = '';
        let barometer = null;

        class AdvancedBarometer {
            constructor(props = {}) {
                this.props = {
                    unit_index: hmFS.SysProGetInt('BaroUnitIndex') ?? 0,
                    widget: null,
                    show_trend: true,
                    history: [],
                    prev_value: 1013,  // Стартовая референсная точка (нормальное давление)
                    current_value: 0,
                    lang: hmSetting.getLanguage() == 4 ? 0 : 1,
                    ...props,
                };

                this.unitStr = [
                    ['мм рт.ст.', 'mmHg'],
                    ['гПа', 'hPa'],
                ];

                this.initSensors();
            }

            initSensors() {
                try {
                    this.time_sensor = hmSensor.createSensor(hmSensor.id.TIME);
                    this.baro_sensor = hmSensor.createSensor(hmSensor.id.BARO);
                    
                    // Быстрая инициализация + 3 попытки
                    let attempts = 0;
                    const initLoop = () => {
                        attempts++;
                        const value = this.baro_sensor.pressure;
                        logger.log(`Baro init attempt ${attempts}: ${value}`);
                        
                        if (value && value > 500 && value < 1100) {
                            this.updateDisplay(value);
                            this.startPeriodicUpdate();
                        } else if (attempts < 5) {
                            setTimeout(initLoop, 1000);
                        } else {
                            // Fallback - показываем референсное значение
                            this.updateDisplay(this.prev_value);
                        }
                    };
                    
                    setTimeout(initLoop, 500);
                    
                } catch (e) {
                    logger.log('Sensor error: ' + e);
                }
            }

            startPeriodicUpdate() {
                // Обновление каждые 20 сек
                this.updateInterval = setInterval(() => {
                    this.update();
                }, 20000);
            }

            getPressureAndTrend(currentValue) {
                if (!currentValue || currentValue === 0) return {value: null, trend: ''};

                // Сразу сохраняем для следующего сравнения
                const trend = this.calculateTrend(currentValue);
                this.props.prev_value = this.props.current_value;
                this.props.current_value = currentValue;

                // Добавляем в историю
                this.props.history.push({value: currentValue, time: Date.now()});
                if (this.props.history.length > 5) this.props.history.shift();

                return {value: currentValue, trend};
            }

            calculateTrend(current) {
                const prev = this.props.prev_value || 1013;
                const delta = current - prev;

                logger.log(`Trend calc: ${prev} → ${current} (Δ${delta.toFixed(1)})`);

                if (delta > 0.2) return "↑";
                if (delta < -0.2) return "↓";
                return ""; // Нет значимых изменений
            }

            update() {
                const value = this.baro_sensor.pressure;
                if (value && value > 500 && value < 1100) {
                    this.updateDisplay(value);
                }
            }

            updateDisplay(value) {
                const {trend} = this.getPressureAndTrend(value);
                let text = this.formatPressure(value);
                
                if (this.props.show_trend && trend) {
                    text += ` ${trend}`;
                }
                
                if (this.props.widget) {
                    this.props.widget.setProperty(hmUI.prop.TEXT, text);
                }
            }

            formatPressure(value) {
                if (this.props.unit_index === 0) {
                    return Math.round(value * 0.75006).toString();
                }
                return Math.round(value).toString();
            }

            toggleUnits() {
                this.props.unit_index = this.props.unit_index === 0 ? 1 : 0;
                hmFS.SysProSetInt('BaroUnitIndex', this.props.unit_index);
                hmUI.showToast({text: this.unitStr[this.props.unit_index][this.props.lang]});
                this.update();
            }

            destroy() {
                if (this.updateInterval) clearInterval(this.updateInterval);
            }
        }

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                const baro_text = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 273,
                    y: 120,
                    w: 146,
                    h: 29,
                    text_size: 30,
                    font: 'fonts/Rajdhani-SemiBold.ttf',
                    color: 0xFFFFFF,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    text: '1013',  // Начальное значение
                });

                barometer = new AdvancedBarometer({ widget: baro_text });

                Button_Baro = hmUI.createWidget(hmUI.widget.BUTTON, {
                    x: 183,
                    y: 183,
                    w: 100,
                    h: 100,
                    text: '',
                    press_src: 'Empty.png',
                    normal_src: 'Empty.png',
                    click_func: () => barometer.toggleUnits(),
                });
            },

            onInit() { logger.log('GTR4 Baro v1.6 onInit'); },
            build() { this.init_view(); logger.log('GTR4 Baro ready'); },
            onDestroy() { if (barometer) barometer.destroy(); }
        });
    })();
} catch (e) {
    console.log('GTR4 Baro Error:', e);
}