  function read_pressure() {
    console.log("read_pressure()");
    const file_name_alt = "../../../baro_altim/pressure.dat";
    const [fs_stat, err] = hmFS.stat(file_name_alt);
    if (err == 0) {
      let file_size = fs_stat.size;
      const len = file_size / 4;
      console.log(`size_alt: ${file_size}, lenght: ${len}`)
      const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY)
  
      let array_buffer = new Float32Array(len);
      hmFS.read(fh, array_buffer.buffer, 0, file_size);
      hmFS.close(fh);
      console.log(`value ${array_buffer[array_buffer.length -1]}`);
      return array_buffer;
    } else {
      console.log('err:', err)
    }
    return null;
  }
  
  function getPressureValue(pressure_array) {
    console.log("getPressureValue()");
    if(pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
    let start_index = pressure_array.length - 1;
    let end_index = start_index - 30*3; // 3 часа
    if(end_index < 0) end_index = 0;
    for (let index = start_index; index >= end_index; index--) {
      if(pressure_array[index] != 0) return parseInt(pressure_array[index] / 100);
    }
    return 0;
  }
  
  function changesPressure(pressure_array) {
    console.log("changesPressure()");
    if(pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
    let start_index = pressure_array.length - 1;
    let end_index = start_index - 30*3; // 3 часа
    let value = pressure_array[start_index];
    let result = 0;
    if(end_index < 0) end_index = 0;
    for (let index = start_index; index >= end_index; index--) {
      let element = pressure_array[index];
      if(element != 0) {
        if(Math.abs(value - element) > 10) { // учитываем только если разниза больше 0,1 hPa
          value = value - element;
          console.log(`element = ${element}`);
          console.log(`pressere_changes = ${value}`);
          return value;
        }
      }
    }
    return result;
  }
  
  function hPa_To_mmHg(hPa_value = 0) {
    let mmHg = Math.round(hPa_value * 0.750064);
    return mmHg;
  }
  //#endregion
  
  let text_pressere; // отображаем давление
  let text_pressere_changes; // отображаем изменение давления
 
  
  
    // start user_script.js
text_pressere = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 120,
              y: 380,
              w: 250,
               h: 50,
               text_size: 49,
              char_space: 0,
              line_space: 0,
              font: 'fonts/teleindicadores1.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "--",
  });
  text_pressere_changes = hmUI.createWidget(hmUI.widget.TEXT, {  // если нужно отображать изменение давления
              x: 90,
              y: 320,
              w: 275,
               h: 55,
               text_size: 55,
              char_space: 0,
              line_space: 0,
              font: 'fonts/teleindicadores1.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.NONE,
    text: "--",
  });
            // end user_script.js



            ///////widgetDelegate//////
            console.log('resume_call.js');
            let pressure_array = read_pressure();
          let value = getPressureValue(pressure_array);
          value = hPa_To_mmHg(value); // если нужно перевести в мм.рт.ст.
          let value_str = value == 0 ? "--" : value + " мм.рт.ст.";
          text_pressere.setProperty(hmUI.prop.TEXT, value_str);
          
          // если нужно отслеживать изменение давления
          let pressere_changes_str = "Давление не меняется";
          let pressere_changes = changesPressure(pressure_array);
          if(pressere_changes < 0) pressere_changes_str = "Давление падает";
          if(pressere_changes > 0) pressere_changes_str = "Давление растет";
          text_pressere_changes.setProperty(hmUI.prop.TEXT, pressere_changes_str);