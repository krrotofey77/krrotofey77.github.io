﻿/*
** Watch_Face_Editor tool
** watchface js version v2.1.1
** Copyright © SashaCX75. All Rights Reserved
*/

try {
(() => {
    //start of ignored block
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    function getApp() {
        return __$$app$$__.app;
    }
    function getCurrentPage() {
        return __$$app$$__.current && __$$app$$__.current.module;
    }
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
    const {px} = __$$app$$__.__globals__;
    const logger = Logger.getLogger('watchface_SashaCX75');
    //end of ignored block

    //dynamic modify start
    
    console.log('user_functions.js');
    // start user_functions.js

    function read_pressure() {
        console.log("read_pressure()");
        const file_name_alt = "../../../baro_altim/pressure.dat";
        const [fs_stat, err] = hmFS.stat(file_name_alt);
        if (err == 0) {
          let file_size = fs_stat.size;
          const len = file_size / 4;
          console.log(`size_alt: ${file_size}, lenght: ${len}`)
          const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY)
      
          let array_buffer = new Float32Array(len);
          hmFS.read(fh, array_buffer.buffer, 0, file_size);
          hmFS.close(fh);
          console.log(`value ${array_buffer[array_buffer.length -1]}`);
          return array_buffer;
        } else {
          console.log('err:', err)
        }
        return null;
    }
    
    function getPressureValue(pressure_array) {
        console.log("getPressureValue()");
        if(pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
        let start_index = pressure_array.length - 1;
        let end_index = start_index - 30*3; // 3 часа
        if(end_index < 0) end_index = 0;
        for (let index = start_index; index >= end_index; index--) {
          if(pressure_array[index] != 0) return parseInt(pressure_array[index] / 100);
        }
        return 0;
    }
    
    function hPa_To_mmHg(hPa_value = 0) {
        let mmHg = Math.round(hPa_value * 0.750064);
        return mmHg;
    }

    let text_pressere; // отображаем давление

    // end user_functions.js
      let normal_background_bg_img = ''
    let normal_altimeter_text_text_img = ''

    //dynamic modify end

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
        init_view() {
            //dynamic modify start
                
            console.log('Watch_Face.ScreenNormal');
normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 466,
          h: 466,
          src: 'bg.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 189,
              y: 323,
              font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');

                console.log('resume_call.js');
                // start resume_call.js
                
                let pressure_array = read_pressure();
                let value = getPressureValue(pressure_array);
                value = hPa_To_mmHg(value); // если нужно перевести в мм.рт.ст.
                let value_str = value == 0 ? "--" : value + "";
                normal_altimeter_text_text_img.setProperty(hmUI.prop.TEXT, value_str);
                    
                // end resume_call.js

              }),
            });

            //dynamic modify end
        },
        onInit() {
            logger.log('index page.js on init invoke');
        },
        build() {
            this.init_view();
            logger.log('index page.js on ready invoke');
        },
        onDestroy() {
            logger.log('index page.js on destroy invoke');
        }
    });
    ;
})();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}