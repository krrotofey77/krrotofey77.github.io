//------------- давление в мм рт.ст. --------------------
function read_pressure() {
    console.log("read_pressure()");
    const file_name_alt = "../../../baro_altim/pressure.dat";
    const [fs_stat, err] = hmFS.stat(file_name_alt);
    if (err == 0) {
        let file_size = fs_stat.size;
        const len = file_size / 4;
        console.log(`size_alt: ${file_size}, lenght: ${len}`)
        const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY)
    
        let array_buffer = new Float32Array(len);
        hmFS.read(fh, array_buffer.buffer, 0, file_size);
        hmFS.close(fh);
        console.log(`value ${array_buffer[array_buffer.length -1]}`);
        return array_buffer;
    } else {
        console.log('err:', err)
    }
    return null;
}

function getPressureValue(pressure_array) {
    console.log("getPressureValue()");
    if(pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
    let start_index = pressure_array.length - 1;
    let end_index = start_index - 30*3; // 3 часа
    if(end_index < 0) end_index = 0;
    for (let index = start_index; index >= end_index; index--) {
        if(pressure_array[index] != 0) return parseInt(pressure_array[index] / 100);
    }
    return 0;
}

function hPa_To_mmHg(hPa_value = 0) {
    let mmHg = Math.round(hPa_value * 0.750064);
    return mmHg;
}

function getPressureMMHG() {
    const pressure_array = read_pressure();
    const val = hPa_To_mmHg(getPressureValue(pressure_array));		// получаем давление и переводим в мм рт. ст.
    return val;
}

function updatePressure() {
    const pressureValue = getPressureMMHG();
    
    // Обновляем значение давления
    normal_altimeter_text_text_img.setProperty({
        x: 318,
        y: 112,
        font_array: ["32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png"],
        padding: false,
        h_space: 0,
        invalid_image: '45.png',
        text: pressureValue,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    // Обновляем текст "мм.рт.ст"
    normal_altimeter_text_mmhg.setProperty({
        x: 318 + 100, // Смещаем текст вправо от значения давления
        y: 112,
        text: "мм.рт.ст",
        color: 0xFFFFffff,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });
}

//---------------------------------
normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
    x: 318,
    y: 112,
    font_array: ["32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png"],
    padding: false,
    h_space: 0,
    invalid_image: '45.png',
    align_h: hmUI.align.LEFT,
    text: getPressureMMHG(),
    show_level: hmUI.show_level.ONLY_NORMAL,
});

// Создаем виджет для отображения "мм.рт.ст"
normal_altimeter_text_mmhg = hmUI.createWidget(hmUI.widget.TEXT, {
    x: 318 + 100, // Смещаем текст вправо от значения давления
    y: 112,
    text: "мм.рт.ст",
    color: 0xFFFFffff, 
    show_level: hmUI.show_level.ONLY_NORMAL,
});

///////////////////
const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
    resume_call: (function () {
        console.log('resume_call()');
        updatePressure();
    }),
});