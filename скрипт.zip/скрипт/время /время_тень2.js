try {
    (() => {
        // Получение текущего приложения и модуля
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        const __$$module$$__ = __$$app$$__.current;

        // Инициализация циферблата
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                // Создание фонового прямоугольника (черный фон)
                hmUI.createWidget(hmUI.widget.FILL_RECT, {
                    x: 0,
                    y: 0,
                    w: 466, // Ширина экрана
                    h: 466, // Высота экрана
                    color: 0x000000, // Черный цвет фона
                });

                // Базовые настройки для текстовых элементов
                const baseTextConfig = {
                    w: 150, // Ширина текстового блока
                    h: 120, // Высота текстового блока
                    text_size: 100, // Размер текста
                    align_v: hmUI.align.CENTER_V, // Вертикальное выравнивание по центру
                    text_style: hmUI.text_style.NONE, // Без стиля текста
                    show_level: hmUI.show_level.ONLY_NORMAL, // Уровень отображения
                    padding: true, // Внутренний отступ
                };

                // Координаты часов (основной текст)
                const hoursX = 50; // Координата X для часов
                const hoursY = 180; // Координата Y для часов

                // 1. Часы и их тень
                const hoursConfig = {
                    ...baseTextConfig,
                    x: hoursX,
                    y: hoursY,
                    align_h: hmUI.align.RIGHT, // Горизонтальное выравнивание
                    type: hmUI.data_type.HOUR, // Тип данных (часы)
                };
                // Тень часов
                hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                    ...hoursConfig,
                    x: hoursConfig.x + 5, // Смещение тени по X
                    y: hoursConfig.y + 5, // Смещение тени по Y
                    color: 0xff0000, // Цвет тени (красный)
                });
                // Основной текст часов
                hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                    ...hoursConfig,
                    color: 0xffffff, // Цвет текста (белый)
                });

                // 2. Двоеточие и его тень
                const colonSize = 100; // Размер двоеточия
                const colonX = hoursX + 140 + 10; // Координата X для двоеточия (150 — ширина часов, 20 — отступ)
                const colonY = hoursY; // Координата Y для двоеточия (выровнено по вертикали с часами)

                // Тень двоеточия
                hmUI.createWidget(hmUI.widget.TEXT, {
                    x: colonX + 5, // Смещение тени по X
                    y: colonY + 5, // Смещение тени по Y
                    w: colonSize / 2, // Ширина двоеточия
                    h: colonSize, // Высота двоеточия
                    color: 0xff0000, // Цвет тени (красный)
                    text: ':', // Текст двоеточия
                    text_size: colonSize, // Размер текста
                    align_h: hmUI.align.CENTER_H, // Горизонтальное выравнивание
                    align_v: hmUI.align.CENTER_V, // Вертикальное выравнивание
                    text_style: hmUI.text_style.NONE, // Без стиля текста
                    show_level: hmUI.show_level.ONLY_NORMAL, // Уровень отображения
                });
                // Основное двоеточие
                hmUI.createWidget(hmUI.widget.TEXT, {
                    x: colonX,
                    y: colonY,
                    w: colonSize / 2, // Ширина двоеточия
                    h: colonSize, // Высота двоеточия
                    color: 0xffffff, // Цвет текста (белый)
                    text: ':', // Текст двоеточия
                    text_size: colonSize, // Размер текста
                    align_h: hmUI.align.CENTER_H, // Горизонтальное выравнивание
                    align_v: hmUI.align.CENTER_V, // Вертикальное выравнивание
                    text_style: hmUI.text_style.NONE, // Без стиля текста
                    show_level: hmUI.show_level.ONLY_NORMAL, // Уровень отображения
                });

                // 3. Минуты и их тень
                const minutesX = colonX + colonSize / 2 - 5; // Координата X для минут (10 — отступ)
                const minutesY = hoursY; // Координата Y для минут (выровнено по вертикали с часами)

                const minutesConfig = {
                    ...baseTextConfig,
                    x: minutesX,
                    y: minutesY,
                    align_h: hmUI.align.LEFT, // Горизонтальное выравнивание
                    type: hmUI.data_type.MINUTE, // Тип данных (минуты)
                };
                // Тень минут
                hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                    ...minutesConfig,
                    x: minutesConfig.x + 5, // Смещение тени по X
                    y: minutesConfig.y + 5, // Смещение тени по Y
                    color: 0xff0000, // Цвет тени (красный)
                });
                // Основной текст минут
                hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                    ...minutesConfig,
                    color: 0xffffff, // Цвет текста (белый)
                });

                // 4. Секунды и их тень
                const secondsX = minutesX + 120 + 10; // Координата X для секунд (15 — отступ)
                const secondsY = hoursY + 40; // Координата Y для секунд (30 — вертикальный отступ)

                const secondsConfig = {
                    x: secondsX,
                    y: secondsY,
                    w: 110, // Ширина текстового блока
                    h: 60, // Высота текстового блока
                    text_size: 50, // Размер текста
                    align_h: hmUI.align.LEFT, // Горизонтальное выравнивание
                    align_v: hmUI.align.TOP, // Вертикальное выравнивание
                    text_style: hmUI.text_style.NONE, // Без стиля текста
                    type: hmUI.data_type.SECOND, // Тип данных (секунды)
                    padding: true, // Внутренний отступ
                    show_level: hmUI.show_level.ONLY_NORMAL, // Уровень отображения
                };
                // Тень секунд
                hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                    ...secondsConfig,
                    x: secondsConfig.x + 3, // Смещение тени по X
                    y: secondsConfig.y + 3, // Смещение тени по Y
                    color: 0xff0000, // Цвет тени (красный)
                });
                // Основной текст секунд
                hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                    ...secondsConfig,
                    color: 0xffffff, // Цвет текста (белый)
                });
            },

            onInit() {
                console.log('index page.js on init invoke');
            },

            build() {
                this.init_view();
                console.log('index page.js on ready invoke');
            },

            onDestroy() {
                console.log('index page.js on destroy invoke');
            },
        });
    })();
} catch (e) {
    // Обработка ошибок
    console.log('Mini Program Error', e);
    if (e && e.stack) {
        e.stack.split(/\n/).forEach((line) => console.log('error stack', line));
    }
}