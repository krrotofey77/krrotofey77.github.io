﻿    try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;

        const { width: DEVICE_WIDTH, height: DEVICE_HEIGHT } = hmSetting.getDeviceInfo();
		const radius = DEVICE_WIDTH / 2, centerX = DEVICE_WIDTH / 2, centerY = DEVICE_HEIGHT / 2
        


        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
               
				hmUI.createWidget(hmUI.widget.FILL_RECT, {
				  x: 0,
				  y: 0,
				  w: DEVICE_WIDTH,
				  h: DEVICE_HEIGHT,
				  color: 0x000000,
				});

               hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                    x: centerX - 20 - 150,
                    y: centerY - 60,
                    w: 150,
                    h: 120,
                    color: 0xffffff,
                    text_size: 100,
                    align_h: hmUI.align.RIGHT,
                    align_v: hmUI.align.CENTER_V,
                    text_style: hmUI.text_style.NONE,
                    type: hmUI.data_type.HOUR,
                    padding: true,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
				
                hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                    x: centerX + 20,
                    y: centerY - 60,
                    w: 150,
                    h: 120,
                    color: 0xffffff,
                    text_size: 100,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    text_style: hmUI.text_style.NONE,
                    type: hmUI.data_type.MINUTE,
                    padding: true,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                hmUI.createWidget(hmUI.widget.TEXT, {
                    x: centerX - 30,
                    y: centerY - 60,
                    w: 60,
                    h: 120,
                    color: 0xffffff,
					text: ':',
                    text_size: 100,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    text_style: hmUI.text_style.NONE,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                    x: centerX + 150,
                    y: centerY - 50,
                    w: 110,
                    h: 60,
                    color: 0xffffff,
                    text_size: 50,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.TOP,
                    text_style: hmUI.text_style.NONE,
                    type: hmUI.data_type.SECOND,
                    padding: true,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });


            },
            onInit() {
                console.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                console.log('index page.js on ready invoke');
            },
            onDestroy() {
                console.log('index page.js on destroy invoke');
            }
        });
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}