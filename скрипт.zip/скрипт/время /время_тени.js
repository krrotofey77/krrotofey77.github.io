﻿try {
    (() => {
        // Получение текущего приложения из менеджера приложений
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        // Получение текущего модуля приложения
        const __$$module$$__ = __$$app$$__.current;
        // Получение информации об устройстве (ширина и высота экрана)
        const { width: DEVICE_WIDTH, height: DEVICE_HEIGHT } = hmSetting.getDeviceInfo();
        // Вычисление центра экрана
        const centerX = DEVICE_WIDTH / 2, centerY = DEVICE_HEIGHT / 2;

        // Создание объекта WatchFace (циферблат)
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            // Функция инициализации видов (элементов интерфейса)
            init_view() {
                // Создание фонового прямоугольника, заполняющего весь экран
                hmUI.createWidget(hmUI.widget.FILL_RECT, {
                    x: 0, // Координата X
                    y: 0, // Координата Y
                    w: DEVICE_WIDTH, // Ширина
                    h: DEVICE_HEIGHT, // Высота
                    color: 0x000000, // Цвет (черный)
                });

                // Функция для создания текстовых элементов с тенью
                const createText = (x, y, w, alignH, type) => {
                    // Базовые настройки для текстового элемента
                    const baseConfig = {
                        x, // Координата X
                        y, // Координата Y
                        w, // Ширина
                        h: 120, // Высота
                        text_size: 100, // Размер текста
                        align_v: hmUI.align.CENTER_V, // Вертикальное выравнивание по центру
                        text_style: hmUI.text_style.NONE, // Стиль текста (без стиля)
                        show_level: hmUI.show_level.ONLY_NORMAL, // Уровень отображения (только нормальный)
                        type: type, // Тип данных (часы, минуты)
                        padding: true, // Внутренний отступ
                    };

                    // Создание тени для текста
                    hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                        ...baseConfig, // Копирование базовых настроек
                        x: x + 5, // Смещение по X для тени
                        y: y + 5, // Смещение по Y для тени
                        color: 0xff0000, // Цвет тени (красный)
                        align_h: alignH, // Горизонтальное выравнивание
                    });

                    // Создание основного текста
                    hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                        ...baseConfig, // Копирование базовых настроек
                        color: 0xffffff, // Цвет текста (белый)
                        align_h: alignH, // Горизонтальное выравнивание
                    });
                };

                // Создание часов
                createText(centerX - 20 - 150, centerY - 60, 150, hmUI.align.RIGHT, hmUI.data_type.HOUR);

                // Создание двоеточия (тень)
                hmUI.createWidget(hmUI.widget.TEXT, {
                    x: centerX - 30 + 5, // Смещение по X для тени
                    y: centerY - 60 + 5, // Смещение по Y для тени
                    w: 60, // Ширина
                    h: 120, // Высота
                    color: 0xff0000, // Цвет тени (красный)
                    text: ':', // Текст (двоеточие)
                    text_size: 100, // Размер текста
                    align_h: hmUI.align.CENTER_H, // Горизонтальное выравнивание по центру
                    align_v: hmUI.align.CENTER_V, // Вертикальное выравнивание по центру
                    text_style: hmUI.text_style.NONE, // Стиль текста (без стиля)
                    show_level: hmUI.show_level.ONLY_NORMAL // Уровень отображения (только нормальный)
                });
                // Создание основного двоеточия
                hmUI.createWidget(hmUI.widget.TEXT, {
                    x: centerX - 30, // Координата X
                    y: centerY - 60, // Координата Y
                    w: 60, // Ширина
                    h: 120, // Высота
                    color: 0xffffff, // Цвет текста (белый)
                    text: ':', // Текст (двоеточие)
                    text_size: 100, // Размер текста
                    align_h: hmUI.align.CENTER_H, // Горизонтальное выравнивание по центру
                    align_v: hmUI.align.CENTER_V, // Вертикальное выравнивание по центру
                    text_style: hmUI.text_style.NONE, // Стиль текста (без стиля)
                    show_level: hmUI.show_level.ONLY_NORMAL // Уровень отображения (только нормальный)
                });

                // Создание минут
                createText(centerX + 20, centerY - 60, 150, hmUI.align.LEFT, hmUI.data_type.MINUTE);

                // Настройки для секунд
                const secondsConfig = {
                    x: centerX + 150, // Координата X
                    y: centerY - 50, // Координата Y
                    w: 110, // Ширина
                    h: 60, // Высота
                    text_size: 50, // Размер текста
                    align_h: hmUI.align.LEFT, // Горизонтальное выравнивание по левому краю
                    align_v: hmUI.align.TOP, // Вертикальное выравнивание по верхнему краю
                    text_style: hmUI.text_style.NONE, // Стиль текста (без стиля)
                    type: hmUI.data_type.SECOND, // Тип данных (секунды)
                    padding: true, // Внутренний отступ
                    show_level: hmUI.show_level.ONLY_NORMAL // Уровень отображения (только нормальный)
                };

                // Создание тени для секунд
                hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                    ...secondsConfig, // Копирование настроек секунд
                    x: secondsConfig.x + 3, // Смещение по X для тени
                    y: secondsConfig.y + 3, // Смещение по Y для тени
                    color: 0xff0000, // Цвет тени (красный)
                });

                // Создание основного текста секунд
                hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                    ...secondsConfig, // Копирование настроек секунд
                    color: 0xffffff, // Цвет текста (белый)
                });
            },
            // Функция, вызываемая при инициализации циферблата
            onInit() {
                console.log('index page.js on init invoke');
            },
            // Функция, вызываемая при построении циферблата
            build() {
                this.init_view(); // Вызов функции инициализации видов
                console.log('index page.js on ready invoke');
            },
            // Функция, вызываемая при уничтожении циферблата
            onDestroy() {
                console.log('index page.js on destroy invoke');
            }
        });
    })();
} catch (e) {
    // Обработка ошибок
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}