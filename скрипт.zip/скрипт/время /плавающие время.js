﻿/*
** Watch_Face_Editor - для ZeppOS / Amazfit (GTR4, API ~3.5)
*/

try {
(() => {
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    const __$$module$$__ = __$$app$$__.current;
    const logger = DeviceRuntimeCore.HmLogger.getLogger('dvd_clock');

    // экран
    const canvasW = 466;
    const canvasH = 466;

    // блок для текста (ширина/высота — подними/опусти при необходимости)
    const timeBoxW = 230;
    const timeBoxH = 80;

    // частота движения (мс). 50 — плавно, но можно увеличить до 80-120 для экономии батареи.
    const tickMs = 60;

    // как часто сохранять состояние в SysPro (в тиках движения)
    const saveIntervalTicks = Math.round(1000 / tickMs); // примерно 1 сек

    // подгружаем сохранённое состояние (если нет — ставим дефолт)
    let posX = hmFS.SysProGetInt('dvd_x') || 120;
    let posY = hmFS.SysProGetInt('dvd_y') || 200;
    let velX = hmFS.SysProGetInt('dvd_vx') || 2;
    let velY = hmFS.SysProGetInt('dvd_vy') || 1;

    let clockWidget = null;
    let bgWidget = null;
    let moveTimer = null;
    let tickCounter = 0;
    let lastMinute = null;

    function formatTimeHHMM() {
        const d = new Date();
        const hh = String(d.getHours()).padStart(2,'0');
        const mm = String(d.getMinutes()).padStart(2,'0');
        return `${hh}:${mm}`;
    }

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
        init_view() {
            logger.log('init_view dvd_clock');

            // фон (если нужно)
            bgWidget = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0, y: 0, w: canvasW, h: canvasH,
                src: '3.png',
                show_level: hmUI.show_level.ONLY_NORMAL
            });

            // создаём текстовые часы (один раз)
            clockWidget = hmUI.createWidget(hmUI.widget.TEXT, {
                x: posX,
                y: posY,
                w: timeBoxW,
                h: timeBoxH,
                color: 0xFFFFFF,
                text_size: 90,
                align_h: hmUI.align.CENTER_H,
                align_v: hmUI.align.CENTER_V,
                text: formatTimeHHMM(),
                show_level: hmUI.show_level.ONLY_NORMAL
            });

            // инициализируем lastMinute
            lastMinute = (new Date()).getMinutes();

            // шаг движения
            const step = () => {
                posX += velX;
                posY += velY;

                // границы
                if (posX <= 0) {
                    posX = 0;
                    velX = Math.abs(velX);
                } else if (posX + timeBoxW >= canvasW) {
                    posX = canvasW - timeBoxW;
                    velX = -Math.abs(velX);
                }
                if (posY <= 0) {
                    posY = 0;
                    velY = Math.abs(velY);
                } else if (posY + timeBoxH >= canvasH) {
                    posY = canvasH - timeBoxH;
                    velY = -Math.abs(velY);
                }

                // обновляем координаты виджета (и, при необходимости, текст)
                const now = new Date();
                const curMinute = now.getMinutes();
                const needTextUpdate = (curMinute !== lastMinute);

                const props = {
                    x: Math.round(posX),
                    y: Math.round(posY),
                    w: timeBoxW,
                    h: timeBoxH
                };
                if (needTextUpdate) {
                    props.text = formatTimeHHMM();
                    lastMinute = curMinute;
                }

                // безопасно обновляем
                try {
                    clockWidget.setProperty(hmUI.prop.MORE, props);
                } catch (e) {
                    // в редких прошивках setProperty требует полный набор полей — пробуем добавить text если не было
                    try {
                        clockWidget.setProperty(hmUI.prop.MORE, Object.assign(props, { text: formatTimeHHMM() }));
                    } catch (err) {
                        console.log('setProperty failed:', err);
                    }
                }

                // сохраняем в SysPro не каждый тик, а с интервалом
                tickCounter++;
                if (tickCounter >= saveIntervalTicks) {
                    tickCounter = 0;
                    hmFS.SysProSetInt('dvd_x', Math.round(posX));
                    hmFS.SysProSetInt('dvd_y', Math.round(posY));
                    hmFS.SysProSetInt('dvd_vx', Math.round(velX));
                    hmFS.SysProSetInt('dvd_vy', Math.round(velY));
                }
            };

            // старт таймера
            if (moveTimer) clearInterval(moveTimer);
            moveTimer = setInterval(step, tickMs);
        },

        onInit() {
            logger.log('onInit dvd_clock');
        },

        build() {
            this.init_view();
        },

        onDestroy() {
            logger.log('onDestroy dvd_clock - stopping timer');
            if (moveTimer) {
                clearInterval(moveTimer);
                moveTimer = null;
            }
            // лучше один раз сохранить финальное состояние
            try {
                hmFS.SysProSetInt('dvd_x', Math.round(posX));
                hmFS.SysProSetInt('dvd_y', Math.round(posY));
                hmFS.SysProSetInt('dvd_vx', Math.round(velX));
                hmFS.SysProSetInt('dvd_vy', Math.round(velY));
            } catch (e) {
                console.log('save onDestroy failed', e);
            }
        }
    });
})();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}