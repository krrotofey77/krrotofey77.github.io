﻿
               
                function createTextWidget(type, x, y, w, h, alignH, alignV, textSize, color, text) {
                    return hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                        x: x,
                        y: y,
                        w: w,
                        h: h,
                        color: color,
                        text_size: textSize,
                        align_h: alignH,
                        align_v: alignV,
                        text_style: hmUI.text_style.NONE,
                        type: type,
                        padding: true,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                }
                
                // Фоновый прямоугольник
                hmUI.createWidget(hmUI.widget.FILL_RECT, {
                    x: 0,
                    y: 0,
                    w: DEVICE_WIDTH,
                    h: DEVICE_HEIGHT,
                    color: 0x000000,
                });
                
                // Часы
                createTextWidget(hmUI.data_type.HOUR, centerX - 170, centerY - 60, 150, 120, hmUI.align.RIGHT, hmUI.align.CENTER_V, 100, 0xffffff);
                
                // Минуты
                createTextWidget(hmUI.data_type.MINUTE, centerX + 20, centerY - 60, 150, 120, hmUI.align.LEFT, hmUI.align.CENTER_V, 100, 0xffffff);
                
                // Двоеточие
                hmUI.createWidget(hmUI.widget.TEXT, {
                    x: centerX - 30,
                    y: centerY - 60,
                    w: 60,
                    h: 120,
                    color: 0xffffff,
                    text: ':',
                    text_size: 100,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    text_style: hmUI.text_style.NONE,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                
                // Секунды
                createTextWidget(hmUI.data_type.SECOND, centerX + 150, centerY - 50, 110, 60, hmUI.align.LEFT, hmUI.align.TOP, 50, 0xffffff);
                

           