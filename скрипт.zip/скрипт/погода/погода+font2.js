﻿(() => {
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
    const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75');

    let normal_widget_text_1 = '';
    let previousTemperature = null;

    const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

    function updateTemperature() {
        let temperature_current_temp = weatherSensor.current || -100;
        temperature_current_temp = (temperature_current_temp >= 0 ? '+' : '') + temperature_current_temp;

        if (temperature_current_temp !== previousTemperature) {
            previousTemperature = temperature_current_temp;
            if (normal_widget_text_1) {
                normal_widget_text_1.setProperty(hmUI.prop.TEXT, temperature_current_temp + '°C');
            }
        }
    }

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
        init_view() {
            console.log('Watch_Face.ScreenNormal');

            normal_widget_text_1 = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 143,
                y: 225,
                w: 180,
                h: 70,
                text_size: 50,
                char_space: 0,
                color: 0xffffffff,
                line_space: 0,
                align_v: hmUI.align.TOP,
                text_style: hmUI.text_style.NONE,
                align_h: hmUI.align.CENTER_H,
                text: '54',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {
                console.log('scale_call()');
                updateTemperature();
            }

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                resume_call: function () {
                    console.log('resume_call()');
                    scale_call();
                    console.log('resume_call.js');
                }
            });
        },
        onInit() {
            logger.log('index page.js on init invoke');
        },
        build() {
            this.init_view();
            logger.log('index page.js on ready invoke');
        },
        onDestroy() {
            logger.log('index page.js on destroy invoke');
        }
    });
})();