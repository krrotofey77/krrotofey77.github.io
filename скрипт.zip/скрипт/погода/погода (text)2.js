﻿(() => {
  const __$$app$$__ = __$$hmAppManager$$__.currentApp;
  const __$$module$$__ = __$$app$$__.current;

  const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_weather');

  let curTime = null;
  let descriptionTextWidget = null;
  let weatherProvider = null;
  let minuteEndListener = null;

  try { curTime = hmSensor.createSensor(hmSensor.id.TIME); } 
  catch (e) { logger.error('Failed to create TIME sensor:', e); }

  class WeatherProvider {
    constructor(props = {}) {
      this.props = { description_widget: null, weather_sensor: null, ...props };
      this.description = [
        'Облачно','Временами дождь','Временами снег','Ясно','Пасмурно','Слабый дождь',
        'Слабый снег','Умеренный дождь','Умеренный снег','Сильный снегопад','Сильный дождь',
        'Песчаная буря','Мокрый снег','Туман','Дымка','Дождь с грозой','Метель','Пыльно',
        'Ливень','Дождь с градом','Сильный дождь с градом','Сильный дождь','Пыльная буря',
        'Сильная песчаная буря','Сильный дождь','Обновите погоду','Облачно ночью',
        'Дождливо ночью','Ясно ночью'
      ];
      try { this.props.weather_sensor = hmSensor.createSensor(hmSensor.id.WEATHER); } 
      catch (e) { logger.error('Failed to create WEATHER sensor:', e); this.props.weather_sensor = null; }
    }

    update() {
      try {
        const ws = this.props.weather_sensor;
        const widget = this.props.description_widget;
        if (!ws || !widget) { if (widget) widget.setProperty(hmUI.prop.TEXT, 'Нет данных'); return; }
        const icon = ws.curAirIconIndex ?? 0;
        const text = (icon >= 0 && icon < this.description.length) ? this.description[icon] : 'Нет данных';
        widget.setProperty(hmUI.prop.TEXT, text);
      } catch (e) {
        logger.error('Weather update error:', e);
        if (this.props.description_widget) this.props.description_widget.setProperty(hmUI.prop.TEXT, 'Ошибка');
      }
    }
  }

  __$$module$$__.module = DeviceRuntimeCore.WatchFace({
    init_view() {
      hmUI.createWidget(hmUI.widget.IMG, { x:0, y:0, w:466, h:466, src:'osn_1.png', show_level: hmUI.show_level.ONLY_NORMAL });

      descriptionTextWidget = hmUI.createWidget(hmUI.widget.TEXT, {
        x:50, y:200, w:366, h:60, text_size:28, color:0xFFFFFFFF,
        align_h: hmUI.align.CENTER_H, align_v: hmUI.align.CENTER_V,
        text_style: hmUI.text_style.WRAP, show_level: hmUI.show_level.ONLY_NORMAL
      });

      weatherProvider = new WeatherProvider({ description_widget: descriptionTextWidget });
      weatherProvider.update();

      if (curTime) {
        minuteEndListener = () => weatherProvider.update();
        curTime.addEventListener(curTime.event.MINUTEEND, minuteEndListener);
        logger.log('TIME sensor listener added.');
      } else logger.warn('TIME sensor not available.');
    },

    build() { this.init_view(); logger.log('Watchface ready.'); },

    onDestroy() {
      if (curTime && minuteEndListener) curTime.removeEventListener(curTime.event.MINUTEEND, minuteEndListener);
      weatherProvider = descriptionTextWidget = curTime = minuteEndListener = null;
      logger.log('Watchface destroyed.');
    }
  });
})();