 const weather = hmSensor.createSensor(hmSensor.id.WEATHER);

 let array_ic_weater = ["А", "Б", "В", "Г", "Д", "Е", "Ж", "З", "И", "Й", "К", "Л", "М", "Н", "О", "П", "Р", "С", "У", "Ф", "Х", "Ц", "Ч", "Ш", "?", "Ъ", "Ы", "Ь"];

//////////////////////////////////////////////////////
 hmUI.createWidget(hmUI.widget.TEXT, {
    x: 464,
    y: 464,
    w: 40,
    h: 40,
    text_size: 70,
    char_space: 0,
    line_space: 0,
    font: 'fonts/weater_by_Sever5187.ttf',
    color: 0xFFFFFFFF,
    align_h: hmUI.align.LEFT,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.NONE,
    text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
    show_level: hmUI.show_level.ONLY_NORMAL,
});
/////////////////////////////////////////////////
  normal_time_weather_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
                        x: 0,
                        y: 231 - 50,
                        w: 466,
                        h: 90,
                        text_size: 70,
                        // text: "В",
                        char_space: 0,
                        line_space: 0,
                        font: 'fonts/weater_by_Sever5187.ttf',
                        color: 0xffff00,
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.ELLIPSIS,
                        // padding: true,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

/////////////////////////////////////////////////////////
 const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                        resume_call: (function () {

                            let current = weather.current;
                            let curAirIconIndex = weather.curAirIconIndex;
                            normal_time_weather_text_font.setProperty(hmUI.prop.TEXT, array_ic_weater[curAirIconIndex]);



                        }),
                        pause_call: (function () {


                        }),
                    });

