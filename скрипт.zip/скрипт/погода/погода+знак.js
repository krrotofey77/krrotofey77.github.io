// 1. Создаём картинку плюса
const plusImg = hmUI.createWidget(hmUI.widget.IMG, {
  x: 135,                    // ← подстрой точно под свою циферблат (чуть левее начала цифр)
  y: 409,
  src: "112.png",            // ← твоя картинка плюса (убедись, что файл лежит в resources)
  visible: false,            // ← лучше сразу скрыть, чтобы не мелькал при старте
  show_level: hmUI.show_level.ONLY_NORMAL,
});

// 2. Текст температуры (твой код почти ок, но координаты x подвинулись из-за плюса)
const normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
  x: 160,                    // ← теперь начинается правее, чем плюс
  y: 409,
  font_array: [
    "51.png","52.png","53.png","54.png","55.png",
    "56.png","57.png","58.png","59.png","60.png"
  ],
  padding: false,
  h_space: 0,
  unit_sc: '111.png',
  unit_tc: '111.png',
  unit_en: '111.png',
  negative_image: '110.png',   // ← минус при < 0
  invalid_image: '63.png',     // ← желательно добавить, если раньше был
  align_h: hmUI.align.CENTER_H,
  type: hmUI.data_type.WEATHER_CURRENT,
  show_level: hmUI.show_level.ONLY_NORMAL,
});

// 3. Сенсор и обновление
const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

function updatePlus() {
  // Проверяем, что данные есть (иногда current может быть null/undefined при ошибке)
  if (weatherSensor.current != null && weatherSensor.current !== undefined) {
    if (weatherSensor.current > 0) {
      plusImg.setProperty(hmUI.prop.VISIBLE, true);
    } else {
      plusImg.setProperty(hmUI.prop.VISIBLE, false);
    }
  } else {
    // если данных нет — лучше скрыть плюс
    plusImg.setProperty(hmUI.prop.VISIBLE, false);
  }
}

// Подписываемся на обновление погоды
weatherSensor.addEventListener(hmSensor.event.UPDATE, updatePlus);

// Вызываем сразу при инициализации (очень важно!)
updatePlus();

// Опционально — обновление каждые 10 минут на случай, если событие UPDATE не всегда приходит
setInterval(updatePlus, 10 * 60 * 1000);