  const weather = hmSensor.createSensor(hmSensor.id.WEATHER);


  let shotWeaterhNames = ["Облачно", "Местами дождь", "Местами снег", "Ясно", "Пасмурно", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь", "Песчаная буря", "Сильная песчаная буря", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"];
/////////////////////////
    hmUI.createWidget(hmUI.widget.TEXT, {
                        x: 464,
                        y: 464,
                        w: 40,
                        h: 40,
                        text_size: 70,
                        char_space: 0,
                        line_space: 0,
                        font: 'fonts/weater_by_Sever5187.ttf',                   ////////////////////            шрифт
                        color: 0xFFFFFFFF,
                        align_h: hmUI.align.LEFT,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.NONE,
                        text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

     //////////////////////////////////////////////////////////////////

        normal_time_weather_text_font_2 = hmUI.createWidget(hmUI.widget.TEXT, {
                        x: 0,
                        y: 231 - 50 + 100,
                        w: 466,
                        h: 65,
                        text_size: 46,
                        // text: "В",
                        char_space: 0,
                        line_space: 0,
                        // font: 'fonts/weater_by_Sever5187.ttf',
                        color: 0x00ff06,
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.ELLIPSIS,
                        // padding: true,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

/////////////////////////////////////////////
    const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                        resume_call: (function () {

                            let current = weather.current;
                            let curAirIconIndex = weather.curAirIconIndex;
                            normal_time_weather_text_font_2.setProperty(hmUI.prop.TEXT, shotWeaterhNames[curAirIconIndex]);



                        }),
                        pause_call: (function () {


                        }),
                    });
          