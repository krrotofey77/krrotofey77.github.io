﻿(() => {
  const __$$app$$__ = __$$hmAppManager$$__.currentApp;
  const __$$module$$__ = __$$app$$__.current;

  const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_min');

  let curTime = null;
  try {
    curTime = hmSensor.createSensor(hmSensor.id.TIME);
  } catch (e) {}

  let descriptionText;
  let weatherProvider = null;

  // --- WeatherProvider ---
  class WeatherProvider {
    constructor(props = {}) {
      this.props = {
        description_widget: null,
        weather_sensor: null,
        lang: (hmSetting.getLanguage() === 4 ? 0 : 1),
        ...props
      };

      this.description = [
        ['Облачно','Временами дождь','Временами снег','Ясно','Пасмурно','Слабый дождь','Слабый снег','Умеренный дождь','Умеренный снег','Сильный снегопад','Сильный дождь','Песчаная буря','Мокрый снег','Туман','Дымка','Дождь с грозой','Метель','Пыльно','Ливень','Дождь с градом','Сильный дождь с градом','Сильный дождь','Пыльная буря','Сильная песчаная буря','Сильный дождь','Обновите погоду','Облачно ночью','Дождливо ночью','Ясно ночью'],
        ['Cloudy','Showers','Snow Showers','Sunny','Overcast','Light Rain','Light Snow','Moderate Rain','Moderate Snow','Heavy Snow','Heavy Rain','Sandstorm','Rain and Snow','Fog','Hazy','T-Storms','Snowstorm','Floating dust','Very Heavy Rainstorm','Rain and Hail','T-Storms and Hail','Heavy Rainstorm','Dust','Heavy sand storm','Rainstorm','Unknown','Cloudy Nighttime','Showers Nighttime','Sunny Nighttime']
      ];

      try {
        this.props.weather_sensor = hmSensor.createSensor(hmSensor.id.WEATHER);
      } catch (e) {
        this.props.weather_sensor = null;
      }
    }

    update() {
      try {
        const ws = this.props.weather_sensor;
        if (!ws) return;

        const icon = ws.curAirIconIndex ?? 0;
        const list = this.description[this.props.lang];

        const text = (icon >= 0 && icon < list.length)
          ? list[icon]
          : 'Нет данных';

        this.props.description_widget?.setProperty(hmUI.prop.TEXT, text);

      } catch (e) {
        console.log('weather update error', e);
      }
    }
  }

  // --- WatchFace ---
  __$$module$$__.module = DeviceRuntimeCore.WatchFace({
    init_view() {

      // ФОН
      hmUI.createWidget(hmUI.widget.IMG, {
        x: 0,
        y: 0,
        w: 466,
        h: 466,
        src: 'osn_1.png',
        show_level: hmUI.show_level.ONLY_NORMAL,
      });

      // ОБЫЧНЫЙ ТЕКСТ ПОГОДЫ
      descriptionText = hmUI.createWidget(hmUI.widget.TEXT, {
        x: 50,
        y: 200,
        w: 366,
        h: 60,
        text_size: 28,
        color: 0xFFFFFFFF,
        align_h: hmUI.align.CENTER_H,
        align_v: hmUI.align.CENTER_V,
        text_style: hmUI.text_style.WRAP,
        show_level: hmUI.show_level.ONLY_NORMAL,
      });

      // Погода
      weatherProvider = new WeatherProvider({
        description_widget: descriptionText
      });

      weatherProvider.update();

      // обновление каждую минуту
      if (curTime) {
        curTime.addEventListener(curTime.event.MINUTEEND, () => {
          weatherProvider.update();
        });
      }
    },

    build() {
      this.init_view();
      logger.log('watchface ready');
    },

    onDestroy() {
      weatherProvider = null;
    }
  });

})();