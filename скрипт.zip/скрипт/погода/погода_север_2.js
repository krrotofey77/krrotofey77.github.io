﻿
		 
        const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
 /////////////////////////////////////////////////////////////////////////////////    
      let weater_text_ttf = ''
      let shotWeaterhNames = ["Облачно", "Местами дождь", "Местами снег", "Cолнечно", "Пасмурно", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь", "Песчаная буря", "Сильная песчаная буря", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"];


    

///////////////////////////////////////////////////////////////////////////////////////
  // FontName: Bebas11.ttf; FontSize: 40; Cache: full
        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 464,
         y: 464,
         w: 48,      
         h: 48,
         text_size: 40,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFF8C00,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

     ////////////////////////////////////////////////////////////////////////////////////////

        weater_text_ttf = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 186,
         w: 466,
         h: 50,
         text_size: 40,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFF8C00,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         // unit_string: погода текстом ttf, Вт, Ср, Чт, Пт, Сб, Вс,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        function scale_call() {
         console.log('scale_call()');

         console.log('Weather city name');
         let curAirIconIndex = weatherSensor.curAirIconIndex;//номер текущего погодного состояния
         weater_text_ttf.setProperty(hmUI.prop.TEXT, shotWeaterhNames[curAirIconIndex]);

        };

        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
         resume_call: (function () {
          console.log('resume_call()');
          scale_call();
         }),
        });

     