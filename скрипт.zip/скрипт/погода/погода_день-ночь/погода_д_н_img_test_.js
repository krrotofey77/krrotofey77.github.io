const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

const NIGHT_ICONS = ["Ъ", "Ы", "Э", "Ь", "Д", "Е", "Ж", "З", "И", "Й", "К", "Л", "М", "Н", "О", "П", "Р", "С", "У", "Ф", "Х", "Ц", "Ч", "Ш", "?", "Ъ", "Ы", "Ь"];
const DAY_ICONS = ["А", "Б", "В", "Г", "Д", "Е", "Ж", "З", "И", "Й", "К", "Л", "М", "Н", "О", "П", "Р", "С", "У", "Ф", "Х", "Ц", "Ч", "Ш", "?", "Ъ", "Ы", "Ь"];

const normal_time_weather_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
  x: 0,
  y: 181, // Упрощено из 231 - 50
  w: 466,
  h: 90,
  text_size: 70,
  char_space: 0,
  line_space: 0,
  font: 'fonts/weater_by_Sever5187.ttf',
  color: 0xffff00,
  align_h: hmUI.align.CENTER_H,
  align_v: hmUI.align.CENTER_V,
  text_style: hmUI.text_style.ELLIPSIS,
  show_level: hmUI.show_level.ONLY_NORMAL,
});

function scale_call() {
  const weatherData = weatherSensor.getForecastWeather();
  const curAirIconIndex = weatherSensor.curAirIconIndex;

  let sunriseMins, sunsetMins;
  if (weatherData.tideData.count > 0) {
    const today = weatherData.tideData.data[0];
    sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
    sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
  } else {
    sunriseMins = sunriseMins_def; // Предполагается, что определено где-то
    sunsetMins = sunsetMins_def;   // Предполагается, что определено где-то
  }

  const curMins = timeSensor.hour * 60 + timeSensor.minute;
  const isDayNow = curMins >= sunriseMins && curMins < sunsetMins;
  const array_ic_weater = isDayNow ? DAY_ICONS : NIGHT_ICONS;

  const newText = array_ic_weater[curAirIconIndex];
  if (normal_time_weather_text_font.getProperty(hmUI.prop.TEXT) !== newText) {
    normal_time_weather_text_font.setProperty(hmUI.prop.TEXT, newText);
  }
}

const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
  resume_call: scale_call,
});