// Создаём датчики погоды и времени
const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

// Массивы погодных названий
const WEATHER_DAY = [
    "Облачно", "Местами дождь", "Местами снег", "Солнечно",
    "Пасмурно", "Слабый дождь", "Слабый снег", "Умеренный дождь",
    "Умеренный снег", "Сильный снег", "Сильный дождь",
    "Песчаная буря", "Мокрый снег", "Туман", "Дымка",
    "Гроза", "Метель", "Пыльно", "Ливень", "Град",
    "Сильный град", "Сильный дождь", "Песчаная буря",
    "Сильная песчаная буря", "Ливень", "Неизвестно",
    "Облачно ночью", "Дождь ночью", "Ясно ночью"
];

const WEATHER_NIGHT = [
    "Облачно ночью", "Местами дождь", "Местами снег", "Ясно ночью",
    "Пасмурно ночью", "Слабый дождь", "Слабый снег",
    "Умеренный дождь", "Умеренный снег", "Сильный снег",
    "Сильный дождь", "Песчаная буря", "Мокрый снег",
    "Туман", "Дымка", "Гроза", "Метель", "Пыльно",
    "Ливень", "Град", "Сильный град", "Сильный дождь",
    "Песчаная буря", "Сильная песчаная буря", "Ливень",
    "Неизвестно", "Облачно ночью", "Дождь ночью", "Ясно ночью"
];

// Создаём виджет для текста погоды
const weatherText = hmUI.createWidget(hmUI.widget.TEXT, {
    x: 0,
    y: 186,
    w: 466,
    h: 50,
    text_size: 40,
    font: "fonts/Bebas11.ttf",
    color: 0xFFFF8C00,
    align_h: hmUI.align.CENTER_H,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.ELLIPSIS,
    text: "--"
});

// Функция обновления текста погоды
function updateWeather() {

    // Индекс иконки погоды
    const idx = weatherSensor.curAirIconIndex;

    if (idx === undefined || idx < 0 || idx >= WEATHER_DAY.length) {
        weatherText.setProperty(hmUI.prop.TEXT, "Нет данных");
        return;
    }

    // Определяем день или ночь
    let isDay = true;

    try {
        const weatherData = weatherSensor.getForecastWeather();

        if (weatherData && weatherData.tideData && weatherData.tideData.count > 0) {
            const today = weatherData.tideData.data[0];

            const sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
            const sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
            const nowMins = timeSensor.hour * 60 + timeSensor.minute;

            isDay = nowMins >= sunriseMins && nowMins < sunsetMins;
        }
    } catch (e) {
        // Если нет данных о солнце — считаем день
        isDay = true;
    }

    const names = isDay ? WEATHER_DAY : WEATHER_NIGHT;

    weatherText.setProperty(
        hmUI.prop.TEXT,
        names[idx] || "Неизвестно"
    );
}

// Инициализация
updateWeather();

// Обновление при изменении погоды
weatherSensor.addEventListener(hmSensor.event.CHANGE, updateWeather);

// Обновление после выхода из AOD
hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
    resume_call: updateWeather
});