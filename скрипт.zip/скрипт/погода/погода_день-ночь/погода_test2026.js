﻿// Датчики
const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

// Основной массив погодных условий
const WEATHER_BASE = [
    "Облачно",
    "Местами дождь",
    "Местами снег",
    "Солнечно",
    "Пасмурно",
    "Слабый дождь",
    "Слабый снег",
    "Умеренный дождь",
    "Умеренный снег",
    "Сильный снег",
    "Сильный дождь",
    "Песчаная буря",
    "Мокрый снег",
    "Туман",
    "Дымка",
    "Гроза",
    "Метель",
    "Пыльно",
    "Ливень",
    "Град",
    "Сильный град",
    "Неизвестно"
];

// Виджет текста погоды
const weatherText = hmUI.createWidget(hmUI.widget.TEXT, {
    x: 0,
    y: 186,
    w: 466,
    h: 50,
    text_size: 40,
    font: "fonts/Bebas11.ttf",
    color: 0xFFFF8C00,
    align_h: hmUI.align.CENTER_H,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.ELLIPSIS,
    text: "--"
});

// Функция обновления текста погоды
function updateWeather() {
    const idx = weatherSensor.curAirIconIndex;

    if (idx === undefined || idx < 0 || idx >= WEATHER_BASE.length) {
        weatherText.setProperty(hmUI.prop.TEXT, "Нет данных");
        return;
    }

    // Определяем день или ночь
    let isDay = true;
    try {
        const weatherData = weatherSensor.getForecastWeather();
        if (weatherData?.tideData?.count > 0) {
            const today = weatherData.tideData.data[0];
            const sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
            const sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
            const nowMins = timeSensor.hour * 60 + timeSensor.minute;
            isDay = nowMins >= sunriseMins && nowMins < sunsetMins;
        }
    } catch (e) {
        isDay = true; // если нет данных о солнце
    }

    // Составляем массив для текущего времени
    const names = isDay
        ? WEATHER_BASE
        : WEATHER_BASE.map(name => {
            // Для основных погодных условий добавляем "ночью"
            if (["Облачно", "Солнечно", "Пасмурно"].includes(name)) {
                return name + " ночью";
            }
            return name; // остальное оставляем
        });

    weatherText.setProperty(hmUI.prop.TEXT, names[idx] || "Неизвестно");
}

// Инициализация
updateWeather();

// Обновление при изменении погоды
weatherSensor.addEventListener(hmSensor.event.CHANGE, updateWeather);

// Обновление после выхода из AOD
hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
    resume_call: updateWeather
});