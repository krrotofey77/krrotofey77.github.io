﻿const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
      let weather_day = ''
      let isDayIcons = false

      let shotWeaterhNames = [];


    /////////////////////////////////////////////////////////////////////


        // FontName: Bebas11.ttf; FontSize: 40; Cache: full
        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 464,
         y: 464,
         w: 48,
         h: 48,
         text_size: 40,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFF8C00,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

       ///////////////////////////////////////////////////////////////////////////
       

        weather_day = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 186,
         w: 466,
         h: 50,
         text_size: 40,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFF8C00,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         // unit_string: погода текстом ttf, Вт, Ср, Чт, Пт, Сб, Вс,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

////////////////////////////////////////////////////////////////////////
        function scale_call() {

         let weatherData = weatherSensor.getForecastWeather();
         let timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

         let tideData = weatherData.tideData;
         let curAirIconIndex = weatherSensor.curAirIconIndex;

         sunData = weatherData.tideData;
         if (sunData.count > 0) {
          today = sunData.data[0];
          sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
          sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
         } else {
          sunriseMins = sunriseMins_def;
          sunsetMins = sunsetMins_def;
         }
         curMins = timeSensor.hour * 60 + timeSensor.minute;
         let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);

         if (isDayNow) {
          if (!isDayIcons) {
           isDayIcons = true;
          }
         } else {
          if (isDayIcons) {
           isDayIcons = false;
          }
         }


         shotWeaterhNames = isDayIcons == false ? ["Облачно ночью", "Местами дождь", "Местами снег", "Ясно ночью", "Пасмурно ночью", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"] : ["Облачно", "Местами дождь", "Местами снег", "Cолнечно", "Пасмурно", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря ", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"];
         weather_day.setProperty(hmUI.prop.TEXT, shotWeaterhNames[curAirIconIndex]);


        };

        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
         resume_call: (function () {
          scale_call();
         }),
        });

     