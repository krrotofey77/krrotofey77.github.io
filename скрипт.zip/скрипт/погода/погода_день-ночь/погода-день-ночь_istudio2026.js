﻿try {
  (() => {
      const __$$app$$__ = __$$hmAppManager$$__.currentApp;
      const __$$module$$__ = __$$app$$__.current;
      const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
      
      // Датчики
      const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
      const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

      // 1. Виджет для текста погоды
      const weatherTextWidget = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 0,
          y: 286, // Координата Y из вашего кода
          w: 466,
          h: 50,
          text_size: 24,
          color: 0xFFFFFF,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.TOP,
          text: '',
          show_level: hmUI.show_level.ONLY_NORMAL,
      });

      // 2. Массивы названий (Дневные и Ночные)
      const dayNames = ["Облачно", "Местами дождь", "Местами снег", "Cолнечно", "Пасмурно", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря ", "Сильный дождь", "Неизвестно", "Облачно ночью", "Дождливо ночью", "Ясно ночью"];
      
      const nightNames = ["Облачно ночью", "Местами дождь", "Местами снег", "Ясно ночью", "Пасмурно ночью", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря", "Сильный дождь", "Неизвестно", "Облачно ночью", "Дождливо ночью", "Ясно ночью"];

      // 3. Функция обновления текста
      function updateWeatherText() {
          const weatherData = weatherSensor.getForecastWeather();
          const sunData = weatherData.tideData;
          
          // Определяем время суток
          let sunriseMins = 8 * 60; // дефолт 08:00
          let sunsetMins = 20 * 60;  // дефолт 20:00
          
          if (sunData && sunData.count > 0) {
              const today = sunData.data[0];
              sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
              sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
          }

          const curMins = timeSensor.hour * 60 + timeSensor.minute;
          const isDay = (curMins >= sunriseMins) && (curMins < sunsetMins);

          // Получаем индекс иконки погоды
          const iconIndex = weatherSensor.curAirIconIndex;
          
          // Выбираем массив и устанавливаем текст
          const currentArray = isDay ? dayNames : nightNames;
          let description = currentArray[iconIndex] || "Неизвестно";

          weatherTextWidget.setProperty(hmUI.prop.TEXT, description.toUpperCase());
      }

      // 4. Регистрация событий
      const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: () => {
              updateWeatherText();
          }
      });

      // Также обновляем при изменении минуты
      timeSensor.addEventListener(timeSensor.event.MINUTEEND, () => {
          updateWeatherText();
      });

  })();
} catch (e) {
  console.log('Error:', e);
}