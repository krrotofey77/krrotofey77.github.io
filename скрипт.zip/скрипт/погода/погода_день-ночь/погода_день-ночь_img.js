﻿   
        const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
        
        let isDayIcons = false
        let array_ic_weater = [];

       
  

       ///////////////////////////////////////
              // FontName:weater_by_Sever5187.ttf; FontSize: 40; Cache: full
              hmUI.createWidget(hmUI.widget.TEXT, {
                x: 464,
                y: 464,
                w: 466,
              h: 90,
              text_size: 70,
                char_space: 0,
                line_space: 0,
                font: 'fonts/weater_by_Sever5187.ttf',
                color: 0xFFFFFFFF,
                align_h: hmUI.align.LEFT,
                align_v: hmUI.align.CENTER_V,
                text_style: hmUI.text_style.NONE,
                text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
                show_level: hmUI.show_level.ONLY_NORMAL,
            });
         
                
          /////////////////////////////////////////////
            normal_time_weather_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 231 - 50,
              w: 466,
              h: 90,
              text_size: 70,
              // text: "В",
              char_space: 0,
              line_space: 0,
              font: 'fonts/weater_by_Sever5187.ttf',
              color: 0xffff00,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
          });


         /////////////////////////////////////////////////////////////////
            function scale_call() {

              let weatherData = weatherSensor.getForecastWeather();
              let timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
     
              let tideData = weatherData.tideData;
              let curAirIconIndex = weatherSensor.curAirIconIndex;
     
              sunData = weatherData.tideData;
              if (sunData.count > 0) {
               today = sunData.data[0];
               sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
               sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
              } else {
               sunriseMins = sunriseMins_def;
               sunsetMins = sunsetMins_def;
              }
              curMins = timeSensor.hour * 60 + timeSensor.minute;
              let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);
     
              if (isDayNow) {
               if (!isDayIcons) {
                isDayIcons = true;
               }
              } else {
               if (isDayIcons) {
                isDayIcons = false;
               }
              }
     
     
              array_ic_weater = isDayIcons == false ? ["Ъ", "Ы", "Э", "Ь", "Д", "Е", "Ж", "З", "И", "Й", "К", "Л", "М", "Н", "О", "П", "Р", "С", "У", "Ф", "Х", "Ц", "Ч", "Ш", "?", "Ъ", "Ы", "Ь"] : ["А", "Б", "В", "Г", "Д", "Е", "Ж", "З", "И", "Й", "К", "Л", "М", "Н", "О", "П", "Р", "С", "У", "Ф", "Х", "Ц", "Ч", "Ш", "?", "Ъ", "Ы", "Ь"];
              normal_time_weather_text_font.setProperty(hmUI.prop.TEXT, array_ic_weater[curAirIconIndex]);

     
             };
             const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
               scale_call();
              }),
             });