const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

// Константы лучше вынести наверх
const TEXT_CONFIG = {
    font: 'fonts/Bebas11.ttf',
    text_size: 40,
    char_space: 0,
    line_space: 0,
    color: 0xFFFF8C00,
    align_h: hmUI.align.CENTER_H,
    align_v: hmUI.align.CENTER_V,
    show_level: hmUI.show_level.ONLY_NORMAL
};

// Список погодных условий можно сделать объектом для лучшей читаемости и производительности
const WEATHER_NAMES = {
    day: [
        "Облачно", "Местами дождь", "Местами снег", "Cолнечно", "Пасмурно",
        "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег",
        "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег",
        "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень",
        "Дождь с градом", "Сильный дождь с градом", "Сильный дождь",
        "Песчаная буря", "Сильная песчаная буря", "Сильный дождь",
        "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"
    ],
    night: [
        "Облачно ночью", "Местами дождь", "Местами снег", "Ясно ночью", "Пасмурно ночью",
        "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег",
        "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег",
        "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень",
        "Дождь с градом", "Сильный дождь с градом", "Сильный дождь",
        "Песчаная буря", "Сильная песчаная буря", "Сильный дождь",
        "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"
    ]
};

// Создание виджетов с использованием констант
hmUI.createWidget(hmUI.widget.TEXT, {
    ...TEXT_CONFIG,
    x: 464,
    y: 464,
    w: 48,
    h: 48,
    text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя ҐЄІЇґєії _-.,:;`'%°\\/",
    text_style: hmUI.text_style.NONE
});

const weatherDay = hmUI.createWidget(hmUI.widget.TEXT, {
    ...TEXT_CONFIG,
    x: 0,
    y: 186,
    w: 466,
    h: 50,
    text_style: hmUI.text_style.ELLIPSIS
});

function updateWeather() {
    const weatherData = weatherSensor.getForecastWeather();
    const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
    const curAirIconIndex = weatherSensor.curAirIconIndex;
    
    // Оптимизация расчета времени
    const { tideData } = weatherData;
    const [today] = tideData.count > 0 ? tideData.data : [];
    const sunriseMins = today ? 
        today.sunrise.hour * 60 + today.sunrise.minute : 
        sunriseMins_def;
    const sunsetMins = today ? 
        today.sunset.hour * 60 + today.sunset.minute : 
        sunsetMins_def;
    const curMins = timeSensor.hour * 60 + timeSensor.minute;
    
    const isDay = curMins >= sunriseMins && curMins < sunsetMins;
    const weatherNames = isDay ? WEATHER_NAMES.day : WEATHER_NAMES.night;
    
    weatherDay.setProperty(hmUI.prop.TEXT, weatherNames[curAirIconIndex]);
}

hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
    resume_call: updateWeather
});