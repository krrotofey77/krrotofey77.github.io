﻿// ========================
// 1️⃣ Датчики
// ========================
const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

// ========================
// 2️⃣ Массив погодных условий
// Индексы должны соответствовать curAirIconIndex
// ========================
const WEATHER_BASE = [
    "Облачно",
    "Местами дождь",
    "Местами снег",
    "Солнечно",
    "Пасмурно",
    "Слабый дождь",
    "Слабый снег",
    "Умеренный дождь",
    "Умеренный снег",
    "Сильный снег",
    "Сильный дождь",
    "Песчаная буря",
    "Мокрый снег",
    "Туман",
    "Дымка",
    "Гроза",
    "Метель",
    "Пыльно",
    "Ливень",
    "Град",
    "Сильный град",
    "Неизвестно"
];

// ========================
// 3️⃣ Виджет текста погоды
// ========================
const weatherText = hmUI.createWidget(hmUI.widget.TEXT, {
    x: 0,
    y: 186,
    w: 466,
    h: 50,
    text_size: 40,
    font: "fonts/Bebas11.ttf",
    color: 0xFFFF8C00,
    align_h: hmUI.align.CENTER_H,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.ELLIPSIS,
    text: "--"
});

// ========================
// 4️⃣ Функция обновления погоды
// ========================
function updateWeather() {
    const idx = weatherSensor?.curAirIconIndex;

    // Проверка индекса
    if (idx === undefined || idx < 0 || idx >= WEATHER_BASE.length) {
        weatherText.setProperty(hmUI.prop.TEXT, "Нет данных");
        return;
    }

    // Определяем день или ночь
    let isDay = true;

try {
    const weatherData = weatherSensor.getForecastWeather?.();

    if (weatherData?.tideData?.count > 0) {
        const today = weatherData.tideData.data[0];

        const sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
        const sunsetMins = today.sunset.hour * 60 + today.sunset.minute;

        const nowMins = ((timeSensor?.hour ?? 12) * 60) + (timeSensor?.minute ?? 0);

        isDay = nowMins >= sunriseMins && nowMins < sunsetMins;
    }

} catch (e) {
    isDay = true;
}

    // Создаём массив с учетом дня/ночи
    const names = WEATHER_BASE.map(name => {
        if (!isDay && ["Облачно", "Солнечно", "Пасмурно"].includes(name)) {
            return name + " ночью";
        }
        return name;
    });

    weatherText.setProperty(hmUI.prop.TEXT, names[idx] || "Неизвестно");
}

// ========================
// 5️⃣ Инициализация
// ========================
updateWeather();

// ========================
// 6️⃣ Обновление при изменении данных
// ========================
weatherSensor.addEventListener(hmSensor.event.CHANGE, updateWeather);

// ========================
// 7️⃣ Обновление после выхода из AOD
// ========================
hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
    resume_call: updateWeather
});