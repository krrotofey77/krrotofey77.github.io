﻿
        let hands_smoth_btn = ''
        let hands_smoth_state = 0 // 0 - smoth, 1 - normal
        let hands_smoth_state_txt = ''
        
        
        function click_bot_hsmoth_Switcher() {
        
          let bot_hands_state_total = 2;
        
          hands_smoth_state = (hands_smoth_state + 1) % bot_hands_state_total;
        
          switch (hands_smoth_state) {
        
              case 0:
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
                hands_smoth_state_txt = 'Normal Seconds';
                  break;
        
              case 1:
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
              normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
                hands_smoth_state_txt = 'Smooth Seconds';
                  break;
        
              default:
                  break;
          }
        
          hmUI.showToast({ text: hands_smoth_state_txt });
        
        }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////////    

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 's_1.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 23,
              second_posY: 205,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);                      скрытие
//////////////////////////////////////////////////////////////////////////////////////////////////////////////        
          

            btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 197,
              y: 197,
              text: '',
              w: 73,
              h: 73,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
            click_zona1();
              },
            longpress_func: () => {
             click_bot_hsmoth_Switcher();
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

           