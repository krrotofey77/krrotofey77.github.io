		let mask_bg = ''

                    jstime = hmSensor.createSensor(hmSensor.id.TIME);

                    jstime.addEventListener(jstime.event.MINUTEEND, function () {

                        var min = jstime.minute;
                        if (min == 0) {
                            setBgAngle(jstime.hour);
                        }
                    });

                    setBgAngle(jstime.hour);

                    function setBgAngle(currentHour) {
                        switch (currentHour) {
                            case 12:
                            case 24:
                            case 0:
                                maskBgRotation(0);
                                break;
                            case 13:
                            case 1:
                                maskBgRotation(30);
                                break;
                            case 14:
                            case 2:
                                maskBgRotation(60);
                                break;
                            case 15:
                            case 3:
                                maskBgRotation(90);
                                break;
                            case 16:
                            case 4:
                                maskBgRotation(120);
                                break;
                            case 17:
                            case 5:
                                maskBgRotation(150);
                                break;
                            case 18:
                            case 6:
                                maskBgRotation(180);
                                break;
                            case 19:
                            case 7:
                                maskBgRotation(210);
                                break;
                            case 20:
                            case 8:
                                maskBgRotation(240);
                                break;
                            case 21:
                            case 9:
                                maskBgRotation(270);
                                break;
                            case 22:
                            case 10:
                                maskBgRotation(300);
                                break;
                            case 23:
                            case 11:
                                maskBgRotation(330);
                                break;

                        }
                    }
/////////////////////////////////////////////////////////////////////////////////////////////////////////
                    function maskBgRotation(angle) {
                        // mask_bg.setProperty(hmUI.prop.ANGLE,angle);
                        mask_bg.setProperty(hmUI.prop.MORE, {
                            x: 0,
                            y: 0,
                            w: 466,
                            h: 466,
                            center_x: 233,
                            center_y: 233,
                            src: rootPath + "img/maskBg.png",
                            angle: angle,
                        });
                    }
             
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                    mask_bg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 0,
                        y: 0,
                        w: 466,
                        h: 466,
                        src: rootPath + "img/maskBg.png",
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

