﻿//Поэтому лучше сделать так: я дам готовый блок, который можно просто вставить в твой текущий код.
//В секцию переменных сверху добавь//

let normal_image_img = null;
let btn_mask = null;

let mask_num = 1;
const mask_all = 5;

const MASK_KEY = "mask_num";
function loadMask() {
    try {
        const value = hmFS.SysProGetChars(MASK_KEY);

        if (value) {
            const num = Number(value);

            if (num >= 1 && num <= mask_all) {
                mask_num = num;
            }
        }
    } catch (e) {
        console.log("loadMask error");
    }
}

function saveMask() {
    try {
        hmFS.SysProSetChars(
            MASK_KEY,
            String(mask_num)
        );
    } catch (e) {
        console.log("saveMask error");
    }
}

function updateMask() {
    if (!normal_image_img) return;

    normal_image_img.setProperty(
        hmUI.prop.SRC,
        `mask_${mask_num}.png`
    );
}

function click_mask() {
    mask_num++;

    if (mask_num > mask_all) {
        mask_num = 1;
    }

    updateMask();
    saveMask();

    hmUI.showToast({
        text: `Маска ${mask_num}`
    });
}
//Перед созданием виджета маски вставь//

loadMask();
//Блок маски полностью замени на//
normal_image_img = hmUI.createWidget(
    hmUI.widget.IMG,
    {
        x: 0,
        y: 0,
        src: `mask_${mask_num}.png`,
        show_level: hmUI.show_level.ONLY_NORMAL,
    }
);
//кнопка//
btn_mask = hmUI.createWidget(
    hmUI.widget.BUTTON,
    {
        x: 183,
        y: 183,
        w: 100,
        h: 100,
        text: '',
        normal_src: 'null.png',
        press_src: 'null.png',
        click_func: click_mask,
        show_level: hmUI.show_level.ONLY_NORMAL,
    }
);