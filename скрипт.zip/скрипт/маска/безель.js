  

   let bezel_img = ''
        let btn_bezel = ''
        let bezel_num = 1
        let bezel_all = 5

        function click_Bezel() {
            if(bezel_num>=bezel_all) {bezel_num=1;}
            else { bezel_num=bezel_num+1;}
            hmUI.showToast({text: "Bezel " + parseInt(bezel_num) });
                  bezel_img.setProperty(hmUI.prop.SRC, "Bezel_" + parseInt(bezel_num) + ".png");
            }
	
//сама картинка
            bezel_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,//x картинки
              y: 0,//y картинки
              src: 'bezel_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			  
//кнопка
            btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 183,//x кнопки
              y: 183,//y кнопки
              text: '',
              w: 100,//ширина кнопки
              h: 100,//высота кнопки
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_Bezel();//имя вызываемой функции
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel.setProperty(hmUI.prop.VISIBLE, true);
