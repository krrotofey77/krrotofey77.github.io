﻿
		let image_top_img = ''
    
        let bot_circle_btn = ''
        //let mask_img = ''
        let btn_mask = ''
        let mask_num = 1
        let mask_all = 5

        function click_mask() {
        if(mask_num>=mask_all) {mask_num=1;}
        else { mask_num=mask_num+1;}
        hmUI.showToast({text: "<Маска> " + parseInt(mask_num) });
        normal_image_img.setProperty(hmUI.prop.SRC, "mask_" + parseInt(mask_num) + ".png");
}

     //////////////////// 

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
        
	////////////////////
			
			 btn_mask = hmUI.createWidget(hmUI.widget.BUTTON, {
            x: 233,
            y: 233,
            text: '',
            w: 150,
            h: 150,
            normal_src: 'null.png',
            press_src: 'null.png',
            click_func: () => {
            click_mask();
            },
            show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_mask.setProperty(hmUI.prop.VISIBLE, true);


        