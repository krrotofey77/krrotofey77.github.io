﻿let mask_num = 1;
const mask_all = 5;

function click_mask() {
    mask_num = (mask_num % mask_all) + 1;

    hmUI.showToast({
        text: `<Маска> ${mask_num}`
    });

    normal_image_img.setProperty(
        hmUI.prop.SRC,
        `mask_${mask_num}.png`
    );
}

normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
    x: 0,
    y: 0,
    src: 'mask_1.png',
    show_level: hmUI.show_level.ONLY_NORMAL,
});

btn_mask = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 233,
    y: 233,
    w: 150,
    h: 150,
    text: '',
    normal_src: 'null.png',
    press_src: 'null.png',
    click_func: click_mask,
    show_level: hmUI.show_level.ONLY_NORMAL,
});