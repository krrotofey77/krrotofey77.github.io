let mask_bg = hmUI.createWidget(hmUI.widget.IMG, {
    x: 0,
    y: 0,
    w: 466,
    h: 466,
    src: 'maska.png',
    show_level: hmUI.show_level.ONLY_NORMAL,
});

const jstime = hmSensor.createSensor(hmSensor.id.TIME);

jstime.addEventListener(jstime.event.MINUTEEND, function () {
    if (jstime.minute === 0) {
        updateBgAngle(jstime.hour);
    }
});

// Инициализируем фон при запуске
updateBgAngle(jstime.hour);

function updateBgAngle(currentHour) {
    const angle = (currentHour % 12) * 30; // Вычисляем угол для текущего часа
    maskBgRotation(angle);
}

function maskBgRotation(angle) {
    mask_bg.setProperty(hmUI.prop.MORE, {
        x: 0,
        y: 0,
        w: 466,
        h: 466,
        center_x: 233,
        center_y: 233,
        src: 'maska.png',
        angle: angle,
    });
}
