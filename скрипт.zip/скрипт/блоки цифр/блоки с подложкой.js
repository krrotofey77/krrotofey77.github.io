﻿/*
** Watch_Face_Editor tool
** watchface js version v2.1.1
** Custom digital clock v1.0
*/

try {
(() => {
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    const __$$module$$__ = __$$app$$__.current;
    const logger = DeviceRuntimeCore.HmLogger.getLogger("custom_digit_text");
    const { px } = __$$app$$__.__globals__;

    // ================== ФУНКЦИЯ СОЗДАНИЯ БЛОКА ==================
    function createCustomDigitBlock(options) {
        return {
            top: hmUI.createWidget(hmUI.widget.TEXT, {
                x: options.xTop,
                y: options.yTop,
                w: 200,
                h: options.sizeTop,
                text: "0",
                color: options.colorTop,
                text_size: options.sizeTop,
                font: 'fonts/mi-Bold.ttf',
                align_h: hmUI.align.CENTER_H,
                align_v: hmUI.align.CENTER_V,
                show_level: hmUI.show_level.ONLY_NORMAL
            }),
            middle: hmUI.createWidget(hmUI.widget.TEXT, {
                x: options.xMiddle,
                y: options.yMiddle,
                w: 200,
                h: options.sizeMiddle,
                text: "0",
                color: options.colorMiddle,
                text_size: options.sizeMiddle,
              font: 'fonts/mi-Bold.ttf',
                align_h: hmUI.align.CENTER_H,
                align_v: hmUI.align.CENTER_V,
                show_level: hmUI.show_level.ONLY_NORMAL
            }),
            bottom: hmUI.createWidget(hmUI.widget.TEXT, {
                x: options.xBottom,
                y: options.yBottom,
                w: 200,
                h: options.sizeBottom,
                text: "0",
                color: options.colorBottom,
                text_size: options.sizeBottom,
                font: 'fonts/mi-Bold.ttf',
                align_h: hmUI.align.CENTER_H,
                align_v: hmUI.align.CENTER_V,
                show_level: hmUI.show_level.ONLY_NORMAL
            })
        };
    }

    // ================== ФУНКЦИЯ ОБНОВЛЕНИЯ ==================
    function updateDigitBlock(block, value) {
        let prev = (value - 1 + 10) % 10;
        let next = (value + 1) % 10;

        block.top.setProperty(hmUI.prop.TEXT, next.toString());
        block.middle.setProperty(hmUI.prop.TEXT, value.toString());
        block.bottom.setProperty(hmUI.prop.TEXT, prev.toString());
    }

    // ================== WATCHFACE ==================
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
        init_view() {
            logger.log("Init custom digital clock");

            // ====== ДОБАВЛЕННЫЙ КОД: ПОДЛОЖКА (Фон) ======
            // Создаем черный прямоугольник, который будет служить фоном.
            // Он должен быть создан ПЕРЕД текстовыми блоками, чтобы быть под ними.
            hmUI.createWidget(hmUI.widget.FILL_RECT, {
                x: 160,    // Координата X начала подложки
                y: 200,   // Координата Y начала подложки
                w: 250,   // Ширина подложки
                h: 80,   // Высота подложки
                color: 0x282828, // Черный цвет
                radius: 10,      // Скругление углов (опционально)
                show_level: hmUI.show_level.ONLY_NORMAL
            });
            // ===============================================


            const time = hmSensor.createSensor(hmSensor.id.TIME);

            // ====== СОЗДАЁМ БЛОКИ ======
            let hourTens  = createCustomDigitBlock({
                xTop: 100, yTop: 150, sizeTop: 50, colorTop: 0x282828,
                xMiddle: 100, yMiddle: 200, sizeMiddle: 80, colorMiddle: 0xFFFFFF,
                xBottom: 100, yBottom: 280, sizeBottom: 50, colorBottom: 0x282828
            });

            let hourOnes  = createCustomDigitBlock({
                xTop: 150, yTop: 150, sizeTop: 50, colorTop: 0x282828,
                xMiddle: 150, yMiddle: 200, sizeMiddle: 80, colorMiddle: 0xFFFFFF,
                xBottom: 150, yBottom: 280, sizeBottom: 50, colorBottom: 0x282828
            });

            let minTens   = createCustomDigitBlock({
                xTop: 220, yTop: 150, sizeTop: 50, colorTop: 0x282828,
                xMiddle: 220, yMiddle: 200, sizeMiddle: 80, colorMiddle: 0xFFFFFF,
                xBottom: 220, yBottom: 280, sizeBottom: 50, colorBottom: 0x282828
            });

            let minOnes   = createCustomDigitBlock({
                xTop: 270, yTop: 150, sizeTop: 50, colorTop: 0x282828,
                xMiddle: 270, yMiddle: 200, sizeMiddle: 80, colorMiddle: 0xFFFFFF,
                xBottom: 270, yBottom: 280, sizeBottom: 50, colorBottom: 0x282828
            });

            // ====== ФУНКЦИЯ ОБНОВЛЕНИЯ ВРЕМЕНИ ======
            function updateClock() {
                const h = time.hour;
                const m = time.minute;

                updateDigitBlock(hourTens, Math.floor(h / 10));
                updateDigitBlock(hourOnes, h % 10);
                updateDigitBlock(minTens, Math.floor(m / 10));
                updateDigitBlock(minOnes, m % 10);
            }

            // Первичное обновление
            updateClock();

            // Таймер: обновление каждую минуту
            timer.createTimer(0, 1000, () => {
                if (time.second === 0) updateClock();
            });
        },

        onInit() { logger.log("onInit"); },
        build()  { this.init_view(); logger.log("onReady"); },
        onDestroy() { logger.log("onDestroy"); }
    });

})();
} catch(e) {
    console.log("Error:", e);
}   
