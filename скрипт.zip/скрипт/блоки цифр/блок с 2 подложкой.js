﻿/*
** Watch_Face_Editor tool
** watchface js version v2.1.1
** Custom digital clock v1.0
*/

try {
(() => {
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    const __$$module$$__ = __$$app$$__.current;
    const logger = DeviceRuntimeCore.HmLogger.getLogger("custom_digit_text");
    const { px } = __$$app$$__.__globals__;

    // ================== ФУНКЦИЯ СОЗДАНИЯ БЛОКА ==================
    function createCustomDigitBlock(options) {
        return {
            top: hmUI.createWidget(hmUI.widget.TEXT, {
                x: options.xTop,
                y: options.yTop,
                w: 200,
                h: options.sizeTop,
                text: "0",
                color: options.colorTop,
                text_size: options.sizeTop,
                font: 'fonts/mi-Bold.ttf',
                align_h: hmUI.align.CENTER_H,
                align_v: hmUI.align.CENTER_V,
                show_level: hmUI.show_level.ONLY_NORMAL
            }),
            middle: hmUI.createWidget(hmUI.widget.TEXT, {
                x: options.xMiddle,
                y: options.yMiddle,
                w: 200,
                h: options.sizeMiddle,
                text: "0",
                color: options.colorMiddle,
                text_size: options.sizeMiddle,
              font: 'fonts/mi-Bold.ttf',
                align_h: hmUI.align.CENTER_H,
                align_v: hmUI.align.CENTER_V,
                show_level: hmUI.show_level.ONLY_NORMAL
            }),
            bottom: hmUI.createWidget(hmUI.widget.TEXT, {
                x: options.xBottom,
                y: options.yBottom,
                w: 200,
                h: options.sizeBottom,
                text: "0",
                color: options.colorBottom,
                text_size: options.sizeBottom,
                font: 'fonts/mi-Bold.ttf',
                align_h: hmUI.align.CENTER_H,
                align_v: hmUI.align.CENTER_V,
                show_level: hmUI.show_level.ONLY_NORMAL
            })
        };
    }

    // ================== ФУНКЦИЯ ОБНОВЛЕНИЯ ==================
    function updateDigitBlock(block, value) {
        let prev = (value - 1 + 10) % 10;
        let next = (value + 1) % 10;

        block.top.setProperty(hmUI.prop.TEXT, next.toString());
        block.middle.setProperty(hmUI.prop.TEXT, value.toString());
        block.bottom.setProperty(hmUI.prop.TEXT, prev.toString());
    }

    // ================== WATCHFACE ==================
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
        init_view() {
            logger.log("Init custom digital clock");

            // ====== КОД: ПОДЛОЖКА ДЛЯ ЧАСОВ ======
        // x: 80, покрывает 100 и 150
        hmUI.createWidget(hmUI.widget.FILL_RECT, {
            x: 170,
            y: 200,
            w: 110, // Ширина 
            h: 80,
            color: 0x414141, 
            radius: 10,
            show_level: hmUI.show_level.ONLY_NORMAL
        });

        // ====== КОД: ПОДЛОЖКА ДЛЯ МИНУТ ======
        // x: 210, покрывает 220 и 270.
        hmUI.createWidget(hmUI.widget.FILL_RECT, {
            x: 285, 
            y: 200,
            w: 110, // Ширина 
            h: 80,
            color: 0x414141, 
            radius: 10,
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        // ===============================================


            const time = hmSensor.createSensor(hmSensor.id.TIME);

            // ====== СОЗДАЁМ БЛОКИ ======
            let hourTens  = createCustomDigitBlock({
                xTop: 100, yTop: 150, sizeTop: 50, colorTop: 0xcccccc,
                xMiddle: 100, yMiddle: 200, sizeMiddle: 80, colorMiddle: 0xFFFFFF,
                xBottom: 100, yBottom: 280, sizeBottom: 50, colorBottom: 0xcccccc
            });

            let hourOnes  = createCustomDigitBlock({
                xTop: 150, yTop: 150, sizeTop: 50, colorTop: 0xcccccc,
                xMiddle: 150, yMiddle: 200, sizeMiddle: 80, colorMiddle: 0xFFFFFF,
                xBottom: 150, yBottom: 280, sizeBottom: 50, colorBottom: 0xcccccc
            });

            let minTens   = createCustomDigitBlock({
                xTop: 220, yTop: 150, sizeTop: 50, colorTop: 0xcccccc,
                xMiddle: 220, yMiddle: 200, sizeMiddle: 80, colorMiddle: 0xFFFFFF,
                xBottom: 220, yBottom: 280, sizeBottom: 50, colorBottom: 0xcccccc
            });

            let minOnes   = createCustomDigitBlock({
                xTop: 270, yTop: 150, sizeTop: 50, colorTop: 0xcccccc,
                xMiddle: 270, yMiddle: 200, sizeMiddle: 80, colorMiddle: 0xFFFFFF,
                xBottom: 270, yBottom: 280, sizeBottom: 50, colorBottom: 0xcccccc
            });

            // ====== ФУНКЦИЯ ОБНОВЛЕНИЯ ВРЕМЕНИ ======
            function updateClock() {
                const h = time.hour;
                const m = time.minute;

                updateDigitBlock(hourTens, Math.floor(h / 10));
                updateDigitBlock(hourOnes, h % 10);
                updateDigitBlock(minTens, Math.floor(m / 10));
                updateDigitBlock(minOnes, m % 10);
            }

            // Первичное обновление
            updateClock();

            // Таймер: обновление каждую минуту
            timer.createTimer(0, 1000, () => {
                if (time.second === 0) updateClock();
            });
        },

        onInit() { logger.log("onInit"); },
        build()  { this.init_view(); logger.log("onReady"); },
        onDestroy() { logger.log("onDestroy"); }
    });

})();
} catch(e) {
    console.log("Error:", e);
}   
