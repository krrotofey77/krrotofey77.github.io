Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 120,
  y: 250,
  w: 100,
  h: 100,
  text: '',
  normal_src: 'empty.png',
  press_src: 'empty.png',
  click_func: () => {
	hmApp.startApp({ appid: 1051195, 
		url: 'page/index',
		params: {
			from_wf: true,
		}
	});
  },
});
