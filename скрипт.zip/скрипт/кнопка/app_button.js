 let Button_1 = ''

 Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 40,
    y: 184,
    w: 100,
    h: 100,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: '20.png',
    normal_src: '20.png',
    click_func: (button_widget) => {
      hmApp.startApp({ appid: 1066653, url: 'page/index.page' });
    }, // end func
    show_level: hmUI.show_level.ONLY_NORMAL,
  }); // end button