/*
** Watch_Face_Editor tool
** watchface js version v2.1.1
** Copyright © SashaCX75. All Rights Reserved
*/

try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');

        let normal_background_bg = null;
        let normal_city_name_text = null;
        const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

        function createBackground() {
            return hmUI.createWidget(hmUI.widget.FILL_RECT, {
                x: 0,
                y: 0,
                w: 466,
                h: 466,
                color: '0xFF6A6A6A',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });
        }

        function createCircularText(center_x, center_y, radius, text) {
            const diameter = 2 * radius;
            return hmUI.createWidget(hmUI.widget.TEXT, {
                x: center_x - radius,
                y: center_y - radius,
                w: diameter,
                h: diameter,
                text_size: 28,
                char_space: 0,
                font: 'fonts/Impact.ttf',
                color: 0xFFFFFFFF,
                align_h: hmUI.align.CENTER_H,
                align_v: hmUI.align.CENTER_V,
                text_style: hmUI.text_style.ELLIPSIS,
                text: text,
                start_angle: -20,
                end_angle: 200,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });
        }

        function updateCityName() {
            try {
                const weatherData = weatherSensor.getForecastWeather();
                const cityName = weatherData?.cityName || "--";
                normal_city_name_text.setProperty(hmUI.prop.TEXT, cityName);
            } catch (error) {
                console.error('Ошибка при получении данных о погоде:', error);
                normal_city_name_text.setProperty(hmUI.prop.TEXT, "--");
            }
        }

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                console.log('Watch_Face.ScreenNormal');
                normal_background_bg = createBackground();

                const center_x = 233;  // Центр экрана по X (466 / 2)
                const center_y = 233;  // Центр экрана по Y (466 / 2)
                const initial_radius = 100;
                const delta_r = 50;
                const new_radius = initial_radius + delta_r;

                normal_city_name_text = createCircularText(center_x, center_y, new_radius, "--");

                updateCityName();

                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: updateCityName,
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e?.stack?.split(/\n/).forEach(i => console.log('error stack', i));
}