﻿   
        let normal_city_name_text = '';

       //////////////////////////////////////////////////////////
            let center_x = 233;  // Центр экрана по X (466 / 2)
            let center_y = 233;  // Центр экрана по Y (466 / 2)
            let new_radius = 100;  // Начальный радиус круга
            let delta_r = 50;     // Регулировка радиуса (может быть положительной или отрицательной)
            
            // Вычисляем новый радиус
            new_radius += delta_r;
            
            // Пересчитываем параметры для виджета
            let new_w = 2 * new_radius;  // Ширина = диаметр круга
            let new_h = 2 * new_radius;  // Высота = диаметр круга
            let new_x = center_x - new_radius;  // Новый x (центр минус радиус)
            let new_y = center_y - new_radius;  // Новый y (центр минус радиус)
            
            // Создаем виджет с новыми параметрами
            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
                x: new_x,
                y: new_y,
                w: new_w,
                h: new_h,
                text_size: 28,
                char_space: 0,
                font: 'fonts/Impact.ttf',
                color: 0xFFFFFFFF,
                align_h: hmUI.align.CENTER_H,
                align_v: hmUI.align.CENTER_V,
                text_style: hmUI.text_style.ELLIPSIS,
                text: "--",
                start_angle: -20,
                end_angle: 200,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);


            function updateCityName() {
                try {
                  let weatherData = weatherSensor.getForecastWeather();
                  if (weatherData && weatherData.cityName) {
                    normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);
                  } else {
                    normal_city_name_text.setProperty(hmUI.prop.TEXT, "--");
                  }
                } catch (error) {
                  console.error('Ошибка при получении данных о погоде:', error);
                  normal_city_name_text.setProperty(hmUI.prop.TEXT, "--");
                }
              }
              
              // Обновляем название города при запуске
              updateCityName();
              
              // Обновляем название города при возобновлении работы устройства
              const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                resume_call: () => {
                  updateCityName();
                },
              });
                