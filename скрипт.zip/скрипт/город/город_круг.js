﻿


  let normal_city_name_text = '';

  ///////////////////////////////////////////////////////////////////////////

let normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
  x: 44,
  y: 44,
  w: 392,
  h: 392,
  text_size: 28,
  char_space: 0,
  font: 'fonts/Impact.ttf',
  color: 0xFFFFFFFF,
  align_h: hmUI.align.CENTER_H,
  align_v: hmUI.align.CENTER_V,
  text_style: hmUI.text_style.ELLIPSIS,
  text: "--",
  start_angle: -200,
  end_angle: 20,
  show_level: hmUI.show_level.ONLY_NORMAL,
});

const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
///////////////////////////////////////////////////////////////
function updateCityName() {
  try {
    let weatherData = weatherSensor.getForecastWeather();
    if (weatherData && weatherData.cityName) {
      normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);
    } else {
      normal_city_name_text.setProperty(hmUI.prop.TEXT, "--");
    }
  } catch (error) {
    console.error('Ошибка при получении данных о погоде:', error);
    normal_city_name_text.setProperty(hmUI.prop.TEXT, "--");
  }
}

// Обновляем название города при запуске
updateCityName();

// Обновляем название города при возобновлении работы устройства
const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
  resume_call: () => {
    updateCityName();
  },
});
