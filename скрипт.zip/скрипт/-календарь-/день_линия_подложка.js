/*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
*/

try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        const __$$module$$__ = __$$app$$__.current;

        let timeSensor = null;
        let dayWidgets = []; // Массив для хранения текстовых виджетов дней
        let todayBackground = null; // Виджет подложки для текущего дня

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                // Создаем сенсор времени
                if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

                // Создаем подложку для текущего дня (квадратная с закругленными краями)
                todayBackground = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                    x: 0,
                    y: 0,
                    w: 45, // Ширина подложки
                    h: 40, // Высота подложки
                    radius: 10, // Закругленные углы
                    color: 0xFFA500, // Оранжевый цвет подложки
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                todayBackground.setProperty(hmUI.prop.VISIBLE, false); // Сначала скрываем

                // Создаем текстовые виджеты для дней недели
                for (let i = 0; i < 7; i++) {
                    dayWidgets.push(hmUI.createWidget(hmUI.widget.TEXT, {
                        x: 20 + i * 45, // Расположение по горизонтали (7 дней с шагом 45 пикселей)
                        y: 100,         // Фиксированная высота линии
                        w: 45,          // Ширина текстового блока
                        h: 40,          // Высота текстового блока
                        text_size: 21,  // Размер текста
                        color: 0xFFFFFFFF, // Белый цвет по умолчанию
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.ELLIPSIS,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    }));
                }

                // Обновление дней при смене дня
                timeSensor.addEventListener(timeSensor.event.DAYCHANGE, () => {
                    this.updateDays();
                });

                // Инициализация отображения
                this.updateDays();
            },

            // Функция обновления дней недели
            updateDays() {
                if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

                const currentDay = timeSensor.day;    // Текущий день месяца
                const currentMonth = timeSensor.month; // Текущий месяц
                const weekDay = timeSensor.week - 1;  // День недели (0-6, ПН-ВС)

                // Вычисляем начало недели относительно текущего дня
                let startDay = currentDay - weekDay;

                // Отображаем 7 дней, начиная с первого дня недели
                for (let i = 0; i < 7; i++) {
                    let displayDay = startDay + i;

                    // Корректировка дней за пределами месяца
                    if (displayDay < 1) {
                        displayDay += new Date(timeSensor.year, currentMonth - 1, 0).getDate(); // Предыдущий месяц
                    } else if (displayDay > new Date(timeSensor.year, currentMonth, 0).getDate()) {
                        displayDay -= new Date(timeSensor.year, currentMonth, 0).getDate(); // Следующий месяц
                    }

                    // Устанавливаем текст и цвет
                    dayWidgets[i].setProperty(hmUI.prop.MORE, {
                        text: displayDay.toString(),
                        color: i === weekDay ? 0xFF0000 : 0xFFFFFFFF, // Красный для текущего дня, белый для остальных
                    });

                    // Если это текущий день, обновляем подложку
                    if (i === weekDay) {
                        const x = 20 + i * 45; // Позиция по X
                        const y = 100;        // Позиция по Y

                        todayBackground.setProperty(hmUI.prop.MORE, {
                            x: x,
                            y: y,
                            w: 45,
                            h: 40,
                            radius: 10, // Закругленные углы
                            color: 0xFFA500, // Оранжевый цвет подложки
                        });
                        todayBackground.setProperty(hmUI.prop.VISIBLE, true); // Показываем подложку
                    }
                }
            },

            onInit() {
                // Инициализация при запуске
            },

            build() {
                this.init_view();
            },

            onDestroy() {
                // Очистка при уничтожении
            }
        });
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}