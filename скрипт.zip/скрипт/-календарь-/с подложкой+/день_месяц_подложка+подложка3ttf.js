﻿try {
    (() => {
        // Инициализация приложения и текущего модуля
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        const __$$module$$__ = __$$app$$__.current;

        // Путь к стороннему шрифту (пример: шрифт в папке assets)
        const customFont = 'fonts/mi-Bold_0.ttf'; // Укажите правильный путь к вашему шрифту

        // Определение циферблата (WatchFace)
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            widgets: [],
            timer: null,

            cellSizeWidth: 30,
            cellSizeHeight: 25,
            cellSpacing: 2,

            updateView() {
                this.widgets.forEach(widget => hmUI.deleteWidget(widget));
                this.widgets = [];

                const today = new Date();
                const year = today.getFullYear();
                const month = today.getMonth();
                const day = today.getDate();

                const firstDay = (new Date(year, month, 1).getDay() + 6) % 7;
                const daysInMonth = new Date(year, month + 1, 0).getDate();

                const monthNames = ["Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
                    "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"];
                const daysOfWeek = ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"];

                const startX = 210;
                const startY = 195;

                const colorWeekday = 0xFFFFFF;
                const colorSaturday = 0xecb2b2;
                const colorSunday = 0xecb2b2;
                const colorToday = 0xFF0000;
                const backgroundColor = 0x333333;
                const backgroundRadius = 8;
                const todayBackgroundColor = 0x555555;

                // Отображение названия месяца и года с использованием стороннего шрифта
                this.widgets.push(hmUI.createWidget(hmUI.widget.TEXT, {
                    x: startX + 50,
                    y: startY,
                    w: 200,
                    h: 40,
                    color: 0xFFFFFF,
                    text_size: 20,
                    align_h: hmUI.align.CENTER_H,
                    text: `${monthNames[month]} ${year}`,
                    font: customFont // Добавляем сторонний шрифт
                }));

                // Фон для заголовков дней недели
                this.widgets.push(hmUI.createWidget(hmUI.widget.FILL_RECT, {
                    x: startX - 5,
                    y: startY + 30 - 5,
                    w: this.cellSizeWidth * 7 + 10,
                    h: 30,
                    radius: backgroundRadius,
                    color: backgroundColor
                }));

                // Заголовки дней недели с использованием стороннего шрифта
                for (let i = 0; i < 7; i++) {
                    this.widgets.push(hmUI.createWidget(hmUI.widget.TEXT, {
                        x: startX + i * this.cellSizeWidth,
                        y: startY + 30,
                        w: this.cellSizeWidth,
                        h: 30,
                        color: 0xC8C8C8,
                        text_size: 18,
                        align_h: hmUI.align.CENTER_H,
                        text: daysOfWeek[i],
                        font: customFont // Добавляем сторонний шрифт
                    }));
                }

                // Дни месяца с использованием стороннего шрифта
                for (let i = 1; i <= daysInMonth; i++) {
                    let x = startX + ((i + firstDay - 1) % 7) * this.cellSizeWidth;
                    let y = startY + 60 + Math.floor((i + firstDay - 1) / 7) * this.cellSizeHeight;

                    if (i === day) {
                        this.widgets.push(hmUI.createWidget(hmUI.widget.FILL_RECT, {
                            x: x - this.cellSpacing,
                            y: y - this.cellSpacing,
                            w: this.cellSizeWidth + this.cellSpacing * 2,
                            h: this.cellSizeHeight + this.cellSpacing * 2,
                            radius: 6,
                            color: todayBackgroundColor
                        }));
                    }

                    let textColor = ((i + firstDay - 1) % 7 === 5) ? colorSaturday :
                        ((i + firstDay - 1) % 7 === 6) ? colorSunday :
                            colorWeekday;
                    if (i === day) textColor = colorToday;

                    this.widgets.push(hmUI.createWidget(hmUI.widget.TEXT, {
                        x: x,
                        y: y,
                        w: this.cellSizeWidth,
                        h: this.cellSizeHeight,
                        color: textColor,
                        text_size: 18,
                        align_h: hmUI.align.CENTER_H,
                        text: `${i}`,
                        font: customFont // Добавляем сторонний шрифт
                    }));
                }
            },

            onInit() {
                this.updateView();
                this.timer = hmApp.registerTimer(60000, () => {
                    const now = new Date();
                    const midnight = new Date(now);
                    midnight.setHours(0, 0, 0, 0);
                    if (now.getDate() !== midnight.getDate()) {
                        this.updateView();
                    }
                });
            },

            build() {
                this.updateView();
            },

            onDestroy() {
                if (this.timer) {
                    hmApp.unregisterTimer(this.timer);
                }
                this.widgets.forEach(widget => hmUI.deleteWidget(widget));
                this.widgets = [];
            }
        });
    })();
} catch (e) {
    if (console && console.log) {
        console.log('Mini Program Error:', e.message);
        if (e.stack) {
            e.stack.split(/\n/).forEach(line => console.log('Error stack:', line));
        }
    } else {
        console.error('Error occurred:', e);
    }
}