﻿try {
    (() => {
        // Инициализация приложения и текущего модуля
        const __$$app$$__ = __$$hmAppManager$$__.currentApp; // Получение текущего приложения
        const __$$module$$__ = __$$app$$__.current; // Получение текущего модуля

        // Определение циферблата (WatchFace)
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            widgets: [], // Массив для хранения всех создаваемых виджетов интерфейса
            timer: null, // Переменная для хранения идентификатора таймера обновления

            // Функция обновления отображения календаря
            updateView() {
                this.widgets.forEach(widget => hmUI.deleteWidget(widget)); // Удаление всех существующих виджетов
                this.widgets = []; // Очистка массива виджетов для новой отрисовки

                // Получение текущей даты
                const today = new Date(); // Создание объекта текущей даты
                const year = today.getFullYear(); // Извлечение текущего года
                const month = today.getMonth(); // Извлечение текущего месяца (0-11)
                const day = today.getDate(); // Извлечение текущего дня месяца

                // Вычисление параметров месяца
                const firstDay = (new Date(year, month, 1).getDay() + 6) % 7; // Первый день месяца (0 - понедельник)
                const daysInMonth = new Date(year, month + 1, 0).getDate(); // Количество дней в текущем месяце

                // Массивы с названиями месяцев и дней недели
                const monthNames = ["Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
                                  "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"]; // Названия месяцев на русском
                const daysOfWeek = ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"]; // Сокращения дней недели

                // Константы для позиционирования и стилизации
                const startX = 100; // Начальная координата X для календаря
                const startY = 150; // Начальная координата Y для календаря
                const cellSize = 30; // Размер одной ячейки календаря (ширина и высота)

                // Цветовые константы
                const colorWeekday = 0xFFFFFF; // Цвет текста для будних дней (белый)
                const colorSaturday = 0xecb2b2; // Цвет текста для субботы (светло-розовый)
                const colorSunday = 0xecb2b2; // Цвет текста для воскресенья (светло-розовый)
                const colorToday = 0xFF0000; // Цвет текста для текущего дня (красный)
                const backgroundColor = 0x333333; // Цвет подложки под заголовок дней недели (темно-серый)
                const backgroundRadius = 8; // Радиус скругления углов подложек
                const todayBackgroundColor = 0x555555; // Цвет подложки для текущего дня (средне-серый)

                // Отображение названия месяца и года
                this.widgets.push(hmUI.createWidget(hmUI.widget.TEXT, {
                    x: startX + 50, // Позиция X с небольшим смещением
                    y: startY, // Позиция Y вверху календаря
                    w: 200, // Ширина текстового поля
                    h: 40, // Высота текстового поля
                    color: 0xFFFFFF, // Белый цвет текста
                    text_size: 20, // Размер шрифта
                    align_h: hmUI.align.CENTER_H, // Центрирование по горизонтали
                    text: `${monthNames[month]} ${year}` // Текст в формате "Месяц Год"
                }));

                // Создание подложки под заголовки дней недели
                this.widgets.push(hmUI.createWidget(hmUI.widget.FILL_RECT, {
                    x: startX - 5, // Смещение влево для отступа
                    y: startY + 30 - 5, // Позиция под заголовком месяца с отступом
                    w: cellSize * 7 + 10, // Ширина для 7 дней с дополнительным отступом
                    h: 40, // Высота подложки
                    radius: backgroundRadius, // Скругление углов
                    color: backgroundColor // Цвет подложки
                }));

                // Отрисовка заголовков дней недели
                for (let i = 0; i < 7; i++) {
                    this.widgets.push(hmUI.createWidget(hmUI.widget.TEXT, {
                        x: startX + i * cellSize, // Позиция X для каждого дня
                        y: startY + 30, // Позиция Y под заголовком месяца
                        w: cellSize, // Ширина ячейки
                        h: 30, // Высота ячейки
                        color: 0xC8C8C8, // Светло-серый цвет текста
                        text_size: 18, // Размер шрифта
                        align_h: hmUI.align.CENTER_H, // Центрирование текста
                        text: daysOfWeek[i] // Текст дня недели
                    }));
                }

                // Отрисовка дней месяца
                for (let i = 1; i <= daysInMonth; i++) {
                    let x = startX + ((i + firstDay - 1) % 7) * cellSize; // Вычисление позиции X с учетом первого дня
                    let y = startY + 60 + Math.floor((i + firstDay - 1) / 7) * cellSize; // Вычисление позиции Y по строкам

                    // Добавление подложки для текущего дня
                    if (i === day) {
                        this.widgets.push(hmUI.createWidget(hmUI.widget.FILL_RECT, {
                            x: x - 2, // Смещение влево для отступа
                            y: y - 2, // Смещение вверх для отступа
                            w: cellSize + 4, // Ширина с небольшим запасом
                            h: cellSize + 4, // Высота с небольшим запасом
                            radius: 6, // Скругление углов
                            color: todayBackgroundColor // Цвет подложки текущего дня
                        }));
                    }

                    // Определение цвета текста в зависимости от дня недели и текущего дня
                    let textColor = ((i + firstDay - 1) % 7 === 5) ? colorSaturday : // Суббота
                                  ((i + firstDay - 1) % 7 === 6) ? colorSunday : // Воскресенье
                                  colorWeekday; // Будний день
                    if (i === day) textColor = colorToday; // Переопределение цвета для текущего дня

                    // Создание текстового виджета для каждого дня
                    this.widgets.push(hmUI.createWidget(hmUI.widget.TEXT, {
                        x: x, // Позиция X
                        y: y, // Позиция Y
                        w: cellSize, // Ширина ячейки
                        h: 30, // Высота ячейки
                        color: textColor, // Цвет текста
                        text_size: 18, // Размер шрифта
                        align_h: hmUI.align.CENTER_H, // Центрирование текста
                        text: `${i}` // Номер дня
                    }));
                }
            },

            // Инициализация при запуске циферблата
            onInit() {
                this.updateView(); // Первоначальная отрисовка календаря
                
                // Установка таймера для проверки смены дня
                this.timer = hmApp.registerTimer(60000, () => { // Проверка каждые 60 секунд
                    const now = new Date(); // Текущая дата и время
                    const midnight = new Date(now); // Копия даты для полуночи
                    midnight.setHours(0, 0, 0, 0); // Установка времени на полночь

                    // Обновление при смене дня
                    if (now.getDate() !== midnight.getDate()) {
                        this.updateView(); // Перерисовка календаря
                    }
                });
            },

            // Построение интерфейса при запуске
            build() {
                this.updateView(); // Вызов отрисовки календаря
            },

            // Очистка ресурсов при закрытии циферблата
            onDestroy() {
                if (this.timer) {
                    hmApp.unregisterTimer(this.timer); // Остановка таймера
                }
                this.widgets.forEach(widget => hmUI.deleteWidget(widget)); // Удаление всех виджетов
                this.widgets = []; // Очистка массива виджетов
            }
        });
    })();
} catch (e) {
    // Обработка ошибок выполнения
    if (console && console.log) {
        console.log('Mini Program Error:', e.message); // Вывод сообщения об ошибке
        if (e.stack) {
            e.stack.split(/\n/).forEach(line => console.log('Error stack:', line)); // Вывод стека ошибки
        }
    } else {
        console.error('Error occurred:', e); // Альтернативный вывод ошибки
    }
}