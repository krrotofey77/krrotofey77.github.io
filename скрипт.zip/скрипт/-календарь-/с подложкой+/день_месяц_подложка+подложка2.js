﻿try {
    (() => {
        // Инициализация приложения и текущего модуля
        const __$$app$$__ = __$$hmAppManager$$__.currentApp; // Получаем текущее приложение
        const __$$module$$__ = __$$app$$__.current; // Получаем текущий модуль

        // Определение циферблата (WatchFace)
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            widgets: [], // Массив для хранения всех виджетов
            timer: null, // Идентификатор таймера

            // Настройка размеров ячеек и отступов
            cellSizeWidth: 35, // Ширина ячейки календаря
            cellSizeHeight: 30, // Высота ячейки календаря
            cellSpacing: 2, // Отступ между ячейками

            // Функция обновления отображения календаря
            updateView() {
                // Удаляем все существующие виджеты
                this.widgets.forEach(widget => hmUI.deleteWidget(widget));
                this.widgets = [];

                // Получаем текущую дату
                const today = new Date();
                const year = today.getFullYear();
                const month = today.getMonth();
                const day = today.getDate();

                // Вычисляем параметры месяца
                const firstDay = (new Date(year, month, 1).getDay() + 6) % 7; // Первый день месяца (0 - понедельник)
                const daysInMonth = new Date(year, month + 1, 0).getDate(); // Количество дней в месяце

                // Названия месяцев и дней недели
                const monthNames = ["Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
                    "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"];
                const daysOfWeek = ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"];

                // Параметры позиционирования
                const startX = 100;
                const startY = 150;

                // Цвета
                const colorWeekday = 0xFFFFFF; // Будние дни
                const colorSaturday = 0xecb2b2; // Суббота
                const colorSunday = 0xecb2b2; // Воскресенье
                const colorToday = 0xFF0000; // Текущий день
                const backgroundColor = 0x333333; // Фон заголовка дней недели
                const backgroundRadius = 8; // Радиус скругления фона
                const todayBackgroundColor = 0x555555; // Фон текущего дня

                // Отображение названия месяца и года
                this.widgets.push(hmUI.createWidget(hmUI.widget.TEXT, {
                    x: startX + 50,
                    y: startY,
                    w: 200,
                    h: 40,
                    color: 0xFFFFFF,
                    text_size: 20,
                    align_h: hmUI.align.CENTER_H,
                    text: `${monthNames[month]} ${year}`
                }));

                // Создание фона для заголовков дней недели
                this.widgets.push(hmUI.createWidget(hmUI.widget.FILL_RECT, {
                    x: startX - 5,
                    y: startY + 30 - 5,
                    w: this.cellSizeWidth * 7 + 10, // Ширина с учетом размеров ячеек
                    h: 40,
                    radius: backgroundRadius,
                    color: backgroundColor
                }));

                // Отрисовка заголовков дней недели
                for (let i = 0; i < 7; i++) {
                    this.widgets.push(hmUI.createWidget(hmUI.widget.TEXT, {
                        x: startX + i * this.cellSizeWidth, // Позиция X с учетом ширины ячейки
                        y: startY + 30,
                        w: this.cellSizeWidth, // Ширина ячейки
                        h: 30,
                        color: 0xC8C8C8,
                        text_size: 18,
                        align_h: hmUI.align.CENTER_H,
                        text: daysOfWeek[i]
                    }));
                }

                // Отрисовка дней месяца
                for (let i = 1; i <= daysInMonth; i++) {
                    let x = startX + ((i + firstDay - 1) % 7) * this.cellSizeWidth; // Позиция X
                    let y = startY + 60 + Math.floor((i + firstDay - 1) / 7) * this.cellSizeHeight; // Позиция Y

                    // Подсветка текущего дня
                    if (i === day) {
                        this.widgets.push(hmUI.createWidget(hmUI.widget.FILL_RECT, {
                            x: x - this.cellSpacing, // Отступ слева
                            y: y - this.cellSpacing, // Отступ сверху
                            w: this.cellSizeWidth + this.cellSpacing * 2, // Ширина с учетом отступов
                            h: this.cellSizeHeight + this.cellSpacing * 2, // Высота с учетом отступов
                            radius: 6,
                            color: todayBackgroundColor
                        }));
                    }

                    // Определение цвета текста
                    let textColor = ((i + firstDay - 1) % 7 === 5) ? colorSaturday :
                        ((i + firstDay - 1) % 7 === 6) ? colorSunday :
                            colorWeekday;
                    if (i === day) textColor = colorToday;

                    // Создание виджета для дня месяца
                    this.widgets.push(hmUI.createWidget(hmUI.widget.TEXT, {
                        x: x,
                        y: y,
                        w: this.cellSizeWidth, // Ширина ячейки
                        h: this.cellSizeHeight, // Высота ячейки
                        color: textColor,
                        text_size: 18,
                        align_h: hmUI.align.CENTER_H,
                        text: `${i}`
                    }));
                }
            },

            // Инициализация при запуске циферблата
            onInit() {
                this.updateView(); // Первоначальная отрисовка

                // Таймер для проверки смены дня
                this.timer = hmApp.registerTimer(60000, () => {
                    const now = new Date();
                    const midnight = new Date(now);
                    midnight.setHours(0, 0, 0, 0);

                    // Обновление при смене дня
                    if (now.getDate() !== midnight.getDate()) {
                        this.updateView();
                    }
                });
            },

            // Построение интерфейса
            build() {
                this.updateView();
            },

            // Очистка ресурсов при закрытии циферблата
            onDestroy() {
                if (this.timer) {
                    hmApp.unregisterTimer(this.timer); // Остановка таймера
                }
                this.widgets.forEach(widget => hmUI.deleteWidget(widget)); // Удаление виджетов
                this.widgets = [];
            }
        });
    })();
} catch (e) {
    // Обработка ошибок
    if (console && console.log) {
        console.log('Mini Program Error:', e.message);
        if (e.stack) {
            e.stack.split(/\n/).forEach(line => console.log('Error stack:', line));
        }
    } else {
        console.error('Error occurred:', e);
    }
}