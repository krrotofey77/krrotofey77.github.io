﻿try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        const __$$module$$__ = __$$app$$__.current;

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            widgets: [], // Массив для хранения всех виджетов
            timer: null, // Переменная для таймера

            updateView() { // Функция обновления календаря
                this.widgets.forEach(widget => hmUI.deleteWidget(widget)); // Удаление старых виджетов
                this.widgets = []; // Очистка массива

                const today = new Date(); // Текущая дата
                const year = today.getFullYear(); // Год
                const month = today.getMonth(); // Месяц (0-11)
                const day = today.getDate(); // День месяца

                const firstDay = (new Date(year, month, 1).getDay() + 6) % 7; // Первый день месяца (ПН=0)
                const daysInMonth = new Date(year, month + 1, 0).getDate(); // Количество дней в месяце

                const monthNames = ["Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
                                    "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"]; // Названия месяцев
                const daysOfWeek = ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"]; // Дни недели

                const startX = 100; // Начальная X-координата
                const startY = 150; // Начальная Y-координата
                const cellSize = 30; // Размер ячейки

                const colorWeekday = 0xFFFFFF; // Цвет будних дней
                const colorSaturday = 0xecb2b2; // Цвет субботы
                const colorSunday = 0xecb2b2; // Цвет воскресенья
                const colorToday = 0xFF0000; // Цвет текущего дня
                const backgroundColor = 0x333333; // Цвет подложки
                const backgroundRadius = 8; // Радиус подложки

                this.widgets.push(hmUI.createWidget(hmUI.widget.TEXT, { // Текст месяца и года
                    x: startX + 50,
                    y: startY,
                    w: 200,
                    h: 40,
                    color: 0xFFFFFF,
                    text_size: 20,
                    align_h: hmUI.align.CENTER_H,
                    text: `${monthNames[month]} ${year}`
                }));

                this.widgets.push(hmUI.createWidget(hmUI.widget.FILL_RECT, { // Подложка под дни недели
                    x: startX - 5,
                    y: startY + 30 - 5,
                    w: cellSize * 7 + 10,
                    h: 40,
                    radius: backgroundRadius,
                    color: backgroundColor
                }));

                for (let i = 0; i < 7; i++) { // Цикл для дней недели
                    this.widgets.push(hmUI.createWidget(hmUI.widget.TEXT, {
                        x: startX + i * cellSize,
                        y: startY + 30,
                        w: cellSize,
                        h: 30,
                        color: 0xC8C8C8,
                        text_size: 18,
                        align_h: hmUI.align.CENTER_H,
                        text: daysOfWeek[i]
                    }));
                }

                for (let i = 1; i <= daysInMonth; i++) { // Цикл для дней месяца
                    let x = startX + ((i + firstDay - 1) % 7) * cellSize;
                    let y = startY + 60 + Math.floor((i + firstDay - 1) / 7) * cellSize;

                    let textColor = ((i + firstDay - 1) % 7 === 5) ? colorSaturday :
                                  ((i + firstDay - 1) % 7 === 6) ? colorSunday : 
                                  colorWeekday;
                    if (i === day) textColor = colorToday;

                    this.widgets.push(hmUI.createWidget(hmUI.widget.TEXT, {
                        x: x,
                        y: y,
                        w: cellSize,
                        h: 30,
                        color: textColor,
                        text_size: 18,
                        align_h: hmUI.align.CENTER_H,
                        text: `${i}`
                    }));
                }
            },

            onInit() { // Инициализация при запуске
                this.updateView(); // Первое отображение
                
                this.timer = hmApp.registerTimer(60000, () => { // Таймер каждые 60 секунд
                    const now = new Date();
                    const midnight = new Date(now);
                    midnight.setHours(0, 0, 0, 0);

                    if (now.getDate() !== midnight.getDate()) { // Проверка смены дня
                        this.updateView();
                    }
                });
            },

            build() { // Построение интерфейса
                this.updateView();
            },

            onDestroy() { // Очистка при закрытии
                if (this.timer) {
                    hmApp.unregisterTimer(this.timer); // Остановка таймера
                }
                this.widgets.forEach(widget => hmUI.deleteWidget(widget)); // Удаление виджетов
                this.widgets = []; // Очистка массива
            }
        });
    })();
} catch (e) { // Обработка ошибок
    if (console && console.log) {
        console.log('Mini Program Error:', e.message);
        if (e.stack) {
            e.stack.split(/\n/).forEach(line => console.log('Error stack:', line));
        }
    } else {
        console.error('Error occurred:', e);
    }
}