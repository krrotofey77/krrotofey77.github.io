﻿/*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
*/

try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        const __$$module$$__ = __$$app$$__.current;

        let timeSensor = null;
        let dayWidgets = [];
        let timer = null; // Переменная для таймера

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

                const rows = 6;
                const cols = 7;
                const dayWidth = 45;
                const dayHeight = 40;
                const startX = 20;
                const startY = 100;

                for (let row = 0; row < rows; row++) {
                    for (let col = 0; col < cols; col++) {
                        const x = startX + col * dayWidth;
                        const y = startY + row * dayHeight;

                        dayWidgets.push(hmUI.createWidget(hmUI.widget.TEXT, {
                            x: x,
                            y: y,
                            w: dayWidth,
                            h: dayHeight,
                            text_size: 21,
                            color: 0xFFFFFFFF,
                            align_h: hmUI.align.CENTER_H,
                            align_v: hmUI.align.CENTER_V,
                            text_style: hmUI.text_style.ELLIPSIS,
                            show_level: hmUI.show_level.ONLY_NORMAL,
                        }));
                    }
                }

                // Начальное обновление
                this.updateDays();

                // Создаем таймер для проверки времени каждые 60 секунд
                timer = hmApp.setInterval(() => {
                    const currentHour = timeSensor.hour;
                    const currentMinute = timeSensor.minute;
                    const currentSecond = timeSensor.second;

                    // Проверяем, наступило ли 00:00
                    if (currentHour === 0 && currentMinute === 0 && currentSecond === 0) {
                        this.updateDays();
                    }
                }, 60000); // 60000 мс = 60 секунд

                // Также оставляем слушатель событий для надежности
                timeSensor.addEventListener(timeSensor.event.DAYCHANGE, () => {
                    this.updateDays();
                });
            },

            updateDays() {
                if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

                const day_num = [31, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
                const year = timeSensor.year;
                if (year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0)) {
                    day_num[2] = 29;
                }

                const currentDay = timeSensor.day;
                const currentMonth = timeSensor.month;
                const firstDayOfWeek = new Date(year, currentMonth - 1, 1).getDay();
                const startOffset = firstDayOfWeek === 0 ? 6 : firstDayOfWeek - 1;

                for (let i = 0; i < dayWidgets.length; i++) {
                    const displayDay = i - startOffset + 1;

                    if (displayDay < 1 || displayDay > day_num[currentMonth]) {
                        dayWidgets[i].setProperty(hmUI.prop.MORE, {
                            text: "",
                            color: 0xFFFFFFFF,
                        });
                    } else {
                        const dayOfWeek = (firstDayOfWeek + displayDay - 1) % 7;
                        let color;
                        if (displayDay === currentDay) {
                            color = 0xFF0000;
                        } else if (dayOfWeek === 0) {
                            color = 0xfff75e5e;
                        } else if (dayOfWeek === 6) {
                            color = 0xfff48686;
                        } else {
                            color = 0xFFFFFFFF;
                        }

                        dayWidgets[i].setProperty(hmUI.prop.MORE, {
                            text: displayDay.toString(),
                            color: color,
                        });
                    }
                }
            },

            onInit() {},

            build() {
                this.init_view();
            },

            onDestroy() {
                // Очищаем таймер при уничтожении
                if (timer) {
                    hmApp.clearInterval(timer);
                    timer = null;
                }
            }
        });
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}