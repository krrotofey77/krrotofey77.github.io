﻿/*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
*/

try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        const __$$module$$__ = __$$app$$__.current;

        let timeSensor = null;
        let normal_day_text_font_ = [];
        let timer = null; // Переменная для таймера

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

                for (let i = 0; i < 7; i++) {
                    normal_day_text_font_[i] = hmUI.createWidget(hmUI.widget.TEXT, {
                        x: 69 + i * 45,
                        y: 356,
                        w: 60,
                        h: 40,
                        text_size: 21,
                        color: 0xFFFFFFFF,
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.ELLIPSIS,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                }

                // Начальное обновление
                this.updateDays();

                // Создаем таймер для проверки времени каждые 60 секунд
                timer = hmApp.setInterval(() => {
                    const currentHour = timeSensor.hour;
                    const currentMinute = timeSensor.minute;
                    const currentSecond = timeSensor.second;

                    // Проверяем, наступило ли 00:00
                    if (currentHour === 0 && currentMinute === 0 && currentSecond === 0) {
                        this.updateDays();
                    }
                }, 60000); // 60000 мс = 60 секунд

                // Слушатель событий для дополнительной надежности
                timeSensor.addEventListener(timeSensor.event.DAYCHANGE, () => {
                    this.updateDays();
                });
            },

            updateDays() {
                if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

                const day_num = [31, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
                const year = timeSensor.year;
                if (year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0)) {
                    day_num[2] = 29;
                }

                const currentDay = timeSensor.day;
                const currentMonth = timeSensor.month;
                const weekDay = timeSensor.week - 1;

                let startDay = currentDay - weekDay;

                for (let i = 0; i < 7; i++) {
                    let displayDay = startDay + i;

                    if (displayDay < 1) {
                        displayDay += day_num[currentMonth === 1 ? 12 : currentMonth - 1];
                    } else if (displayDay > day_num[currentMonth]) {
                        displayDay -= day_num[currentMonth];
                    }

                    normal_day_text_font_[i].setProperty(hmUI.prop.MORE, {
                        x: 69 + i * 45,
                        y: 356,
                        w: 60,
                        h: 40,
                        text_size: 21,
                        text: displayDay.toString(),
                        color: i === weekDay ? 0xFF0000 : 0xFFFFFFFF,
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
                        text_style: hmUI.text_style.ELLIPSIS,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                }
            },

            onInit() {},

            build() {
                this.init_view();
            },

            onDestroy() {
                // Очищаем таймер при уничтожении
                if (timer) {
                    hmApp.clearInterval(timer);
                    timer = null;
                }
            }
        });
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}