/*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
*/

try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        const __$$module$$__ = __$$app$$__.current;

        let timeSensor = null;
        let dayWidgets = []; // Массив для хранения виджетов дней
        let todayBackground = null; // Виджет подложки для текущего дня

        // Параметры графика
        let gridStartX = 20; // Начальная позиция по X
        let gridStartY = 100; // Начальная позиция по Y
        let dayWidth = 45; // Ширина одного дня
        let dayHeight = 40; // Высота одного дня

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                // Создаем сенсор времени
                if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

                // Создаем подложку для текущего дня (квадратная с закругленными краями)
                todayBackground = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                    x: 0,
                    y: 0,
                    w: dayWidth,
                    h: dayHeight,
                    radius: 10, // Закругленные углы
                    color: 0xFFA500, // Оранжевый цвет подложки
                    alpha: 100,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                todayBackground.setProperty(hmUI.prop.VISIBLE, false); // Сначала скрываем

                // Создаем текстовые виджеты для дней
                this.createDayWidgets();

                // Обновление дней при смене дня
                timeSensor.addEventListener(timeSensor.event.DAYCHANGE, () => {
                    this.updateDays();
                });

                // Инициализация отображения
                this.updateDays();
            },

            // Создание виджетов для дней
            createDayWidgets() {
                const rows = 6; // Максимальное количество строк для отображения дней
                const cols = 7; // 7 дней в неделе

                for (let row = 0; row < rows; row++) {
                    for (let col = 0; col < cols; col++) {
                        const x = gridStartX + col * dayWidth;
                        const y = gridStartY + row * dayHeight;

                        dayWidgets.push(hmUI.createWidget(hmUI.widget.TEXT, {
                            x: x,
                            y: y,
                            w: dayWidth,
                            h: dayHeight,
                            text_size: 21,
                            color: 0xFFFFFFFF, // Белый цвет по умолчанию
                            align_h: hmUI.align.CENTER_H,
                            align_v: hmUI.align.CENTER_V,
                            text_style: hmUI.text_style.ELLIPSIS,
                            show_level: hmUI.show_level.ONLY_NORMAL,
                        }));
                    }
                }
            },

            // Функция обновления дней месяца
            updateDays() {
                if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

                // Массив дней в месяце для високосного и невисокосного года
                const day_num = [31, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
                const year = timeSensor.year;
                if (year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0)) {
                    day_num[2] = 29; // Високосный год
                }

                const currentDay = timeSensor.day;    // Текущий день месяца
                const currentMonth = timeSensor.month; // Текущий месяц
                const firstDayOfWeek = new Date(year, currentMonth - 1, 1).getDay(); // День недели первого дня месяца (0-6, ВС-СБ)

                // Корректировка для начала недели с понедельника (если нужно)
                const startOffset = firstDayOfWeek === 0 ? 6 : firstDayOfWeek - 1; // Если неделя начинается с понедельника

                // Отображаем все дни месяца
                for (let i = 0; i < dayWidgets.length; i++) {
                    const displayDay = i - startOffset + 1;

                    if (displayDay < 1 || displayDay > day_num[currentMonth]) {
                        // Дни за пределами текущего месяца
                        dayWidgets[i].setProperty(hmUI.prop.MORE, {
                            text: "",
                            color: 0xFFFFFFFF, // Пустые дни
                        });
                    } else {
                        // Определяем день недели для текущего дня
                        const dayOfWeek = (firstDayOfWeek + displayDay - 1) % 7; // 0-6 (ВС-СБ)

                        // Выбираем цвет в зависимости от дня недели
                        let color;
                        if (displayDay === currentDay) {
                            color = 0xFF0000; // Красный для текущего дня
                        } else if (dayOfWeek === 0) {
                            color = 0x00FF00; // Зеленый для воскресенья
                        } else if (dayOfWeek === 6) {
                            color = 0x0000FF; // Синий для субботы
                        } else {
                            color = 0xFFFFFFFF; // Белый для остальных дней
                        }

                        // Устанавливаем текст и цвет
                        dayWidgets[i].setProperty(hmUI.prop.MORE, {
                            text: displayDay.toString(),
                            color: color,
                        });

                        // Если это текущий день, обновляем подложку
                        if (displayDay === currentDay) {
                            const x = gridStartX + (i % 7) * dayWidth; // Позиция по X
                            const y = gridStartY + Math.floor(i / 7) * dayHeight; // Позиция по Y

                            todayBackground.setProperty(hmUI.prop.MORE, {
                                x: x,
                                y: y,
                                w: dayWidth,
                                h: dayHeight,
                                radius: 10, // Закругленные углы
                                color: 0xFFA500, // Оранжевый цвет подложки
                            });
                            todayBackground.setProperty(hmUI.prop.VISIBLE, true); // Показываем подложку
                        }
                    }
                }
            },

            // Обновление параметров графика
            updateGridParams(newStartX, newStartY, newDayWidth, newDayHeight) {
                gridStartX = newStartX;
                gridStartY = newStartY;
                dayWidth = newDayWidth;
                dayHeight = newDayHeight;

                // Пересоздаем виджеты дней с новыми параметрами
                dayWidgets.forEach(widget => widget.delete());
                dayWidgets = [];
                this.createDayWidgets();

                // Обновляем отображение дней
                this.updateDays();
            },

            onInit() {
                // Инициализация при запуске
            },

            build() {
                this.init_view();
            },

            onDestroy() {
                // Очистка при уничтожении
            }
        });
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}