// ======================================================
// === AUTO DAY / NIGHT BACKGROUND ======================
// ======================================================

// ---------- ФОН ----------
let bg = hmUI.createWidget(hmUI.widget.IMG, {
  x: 0,
  y: 0,
  w: 466,
  h: 466,
  src: "day.png",
  show_level: hmUI.show_level.ONLY_NORMAL,
});

// ---------- СЕНСОРЫ ----------
const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

// ---------- КОНСТАНТЫ ПО УМОЛЧАНИЮ ----------
const DEFAULT_SUNRISE = 8 * 60;   // 08:00
const DEFAULT_SUNSET  = 20 * 60;  // 20:00

// ---------- СОСТОЯНИЕ ----------
let isDayBg = null;  // null = ещё не определяли

// ======================================================
// === ОСНОВНАЯ ФУНКЦИЯ ================================
// ======================================================

function autoToggleBg() {

  let sunrise = DEFAULT_SUNRISE;
  let sunset  = DEFAULT_SUNSET;

  const weatherData = weatherSensor.getForecastWeather();

  // --- Получаем данные о солнце ---
  if (weatherData && weatherData.tideData && weatherData.tideData.count > 0) {
    const today = weatherData.tideData.data[0];

    if (today.sunrise && today.sunset) {
      sunrise = today.sunrise.hour * 60 + today.sunrise.minute;
      sunset  = today.sunset.hour  * 60 + today.sunset.minute;
    }
  }

  // --- Текущее время ---
  const now = timeSensor.hour * 60 + timeSensor.minute;

  const isDayNow = now >= sunrise && now < sunset;

  // --- Переключаем только если состояние изменилось ---
  if (isDayNow !== isDayBg) {
    bg.setProperty(
      hmUI.prop.SRC,
      isDayNow ? "day.png" : "night.png"
    );
    isDayBg = isDayNow;
  }
}

// ======================================================
// === ОБНОВЛЕНИЯ ======================================
// ======================================================

// При старте
autoToggleBg();

// Каждую минуту
timeSensor.addEventListener(
  hmSensor.event.MINUTE_CHANGE,
  autoToggleBg
);

// При возврате на экран
hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
  resume_call: function () {
    autoToggleBg();
  }
});