try {
(() => {
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    const time = hmSensor.createSensor(hmSensor.id.TIME);

    // ============================================================
    // ⚙️ Настройки шрифта и позиционирования текста времени
    // ============================================================
    const hourText = hmUI.createWidget(hmUI.widget.TEXT, {
        x: 0,
        y: 0,
        w: 192,
        h: 100,
        color: 0xffffff,    // начальный цвет (белый)
        text_size: 60,
        align_h: hmUI.align.CENTER_H,
        align_v: hmUI.align.CENTER_V,
        text_style: hmUI.text_style.NONE,
        font: "fonts/MyFont.ttf",
        text: "",
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    // ============================================================
    // Функция обновления времени (12-часовой формат)
    // ============================================================
    function TimeUpdate() {
        let hr = time.hour % 12;
        if (hr === 0) hr = 12;
        hourText.setProperty(hmUI.prop.TEXT, hr.toString());
    }

    // ============================================================
    // Параметры для пульсации свечения (цвета RGB)
    // Изменяем здесь желаемый основной цвет свечения
    // Здесь пример с красным свечением
    // ============================================================
    let glowIntensity = 0;
    let glowStep = 0.05; // скорость пульсации

    function pulseGlow() {
        glowIntensity += glowStep;
        if (glowIntensity > 1 || glowIntensity < 0) glowStep = -glowStep;
        let redValue = 0x80 + Math.floor(glowIntensity * 0x7F); // яркость от 128 до 255
        // Формируем цвет красного свечения (R, G, B)
        let glowColor = (redValue << 16) | 0x0000 | 0x0000; 
        hourText.setProperty(hmUI.prop.COLOR, glowColor);
    }

    // Запускаем интервал для постоянной пульсации свечения каждую 50 мс
    setInterval(pulseGlow, 50);

    // ============================================================
    // Слушатель смены минуты для обновления цифр времени
    // ============================================================
    time.addEventListener(time.event.MINUTEEND, () => {
        TimeUpdate();
    });

    // ============================================================
    // Обновление при возвращении к циферблату (резюме)
    // ============================================================
    const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
        resume_call: () => {
            console.log('resume_call()');
            TimeUpdate();
        },
        pause_call: () => {
            console.log("ui pause");
        },
    });

    // Инициалное обновление времени при запуске
    TimeUpdate();
})();
} catch (e) {
    console.log("Error in clock script:", e);
}