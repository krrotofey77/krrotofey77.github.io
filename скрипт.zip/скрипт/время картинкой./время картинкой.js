                                

            let normal_image_img = ''

             //////////////////////////////////////////////////////////////////////////////////////////////////////// 
                const time = hmSensor.createSensor(hmSensor.id.TIME);      
                
                
                normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    src: 'h_0.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });


          

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    


           

            function TimeUpdate() {
                let hr = time.hour;
                if (hr >= 12) {
                  hr = hr - 12;
                }
                
                
                normal_image_img.setProperty(hmUI.prop.SRC, 'h_' + hr.toString() + '.png');
              }
      
              time.addEventListener(time.event.MINUTEEND, function () {
                TimeUpdate();
              });
      //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
              const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                resume_call: (function () {
                  console.log('resume_call()');
                  TimeUpdate();
                }),
                pause_call: (function () {
                  console.log("ui pause");
                }),
              });


           