﻿try {
(() => {
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    const time = hmSensor.createSensor(hmSensor.id.TIME);

    // ============================================================
    // ⚙️ Настройки шрифта и позиционирования
    // ============================================================
    const hourText = hmUI.createWidget(hmUI.widget.TEXT, {
        x: 0,
        y: 0,
        w: 192,               // ширина области вывода
        h: 100,               // высота области вывода
        color: 0xffffff,      // цвет текста (например, белый)
        text_size: 60,        // размер шрифта
        align_h: hmUI.align.CENTER_H, 
        align_v: hmUI.align.CENTER_V,
        text_style: hmUI.text_style.NONE,
        font: "fonts/MyFont.ttf", // ⚠️ путь к шрифту в resources/fonts/
        text: "",
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    // ============================================================
    // ⏰ Обновление текста по времени
    // ============================================================
    function TimeUpdate() {
        let hr = time.hour % 12;
        if (hr === 0) hr = 12; // показываем 12 вместо 0
        hourText.setProperty(hmUI.prop.TEXT, hr.toString());
    }

    time.addEventListener(time.event.MINUTEEND, () => {
        TimeUpdate();
    });

    // ============================================================
    // 🔄 Перерисовка при возврате на циферблат
    // ============================================================
    const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
        resume_call: () => {
            console.log('resume_call()');
            TimeUpdate();
        },
        pause_call: () => {
            console.log("ui pause");
        },
    });

    // Инициализация при запуске
    TimeUpdate();
})();
} catch (e) {
    console.log("Error in clock script:", e);
}