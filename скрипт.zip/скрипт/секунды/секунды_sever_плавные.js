﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');

        let normal_stand_circle_scale = '';
        let normal_analog_clock_time_pointer_second = '';
        let timeSensor = '';

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                // Создаём круговой прогресс для секунд
                normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 233,
                    center_y: 233,
                    start_angle: 0,
                    end_angle: 360,
                    radius: 165,
                    line_width: 50,
                    corner_flag: 3,
                    color: 0xFFFF921D,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // Создаём секундную стрелку
                normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 467,
                    h: 467,
                    pos_x: 233-25,
                    pos_y: 233-234,
                    center_x: 233,
                    center_y: 233,
                    angle: 0,
                    src: 'str_S.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // Инициализируем сенсор времени
                if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

                // Делегат для управления обновлениями
                const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: (function () {
                        // Таймер для плавного обновления
                        timer.createTimer(0, 50, (function (option) { // Обновляем каждые 50 мс для плавности
                            const now = new Date();
                            const seconds = now.getSeconds();
                            const milliseconds = now.getMilliseconds();

                            // Плавный угол для секундной стрелки
                            const smoothSecondsAngle = (seconds + milliseconds / 1000) * 6; // 6 градусов в секунду
                            normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.ANGLE, smoothSecondsAngle);

                            // Плавный прогресс для кругового индикатора
                            const progressStand = (seconds + milliseconds / 1000) / 60;
                            const level = Math.round(progressStand * 100);
                            if (normal_stand_circle_scale) {
                                normal_stand_circle_scale.setProperty(hmUI.prop.MORE, {
                                    center_x: 233,
                                    center_y: 233,
                                    start_angle: 0,
                                    end_angle: 360,
                                    radius: 165,
                                    line_width: 50,
                                    corner_flag: 3,
                                    color: 0xFFFF921D,
                                    show_level: hmUI.show_level.ONLY_NORMAL,
                                    level: level,
                                });
                            }
                        }));
                    }),
                    pause_call: (function () {
                        timer.stopTimer(normal_timerTimeUpdate);
                    }),
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}