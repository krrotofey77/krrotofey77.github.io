чистый универсальный шаблон для Zepp OS (API 3.5), который можно вставлять в любой циферблат,
и который уже содержит:

плавную анимацию секундной стрелки,

плавный круговой прогресс секунд,

синхронизацию с системным временем,

простые методы инициализации / остановки (чтобы было легко подключать к watchface).


Вот готовый шаблон:

🧩 ШАБЛОН SmoothTimeAnimator.js

/*
** SmoothTimeAnimator v1.0
** Универсальный модуль для плавной анимации секунд и кольца
** Для Zepp OS API 3.5 (Amazfit GTR / GTS / T-Rex 2)
*/

export const SmoothTimeAnimator = (() => {
  let timeSensor = null;
  let timerAnim = null;
  let timerProgress = null;

  let secondHand = null;
  let secondCircle = null;

  /** 
   * Инициализация
   * @param {Object} opts
   * @param {hmUI.widget.IMG} opts.secondHand — виджет секундной стрелки (hmUI.widget.IMG)
   * @param {hmUI.widget.ARC_PROGRESS} opts.secondCircle — виджет кольца секунд (hmUI.widget.ARC_PROGRESS)
   * @param {number} [opts.interval=50] — период обновления в миллисекундах (рекомендуется 50)
   */
  function init(opts = {}) {
    if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

    secondHand = opts.secondHand || null;
    secondCircle = opts.secondCircle || null;

    const interval = opts.interval || 50;

    start(interval);
  }

  /** 
   * Запуск анимации
   */
  function start(interval = 50) {
    if (timerAnim) return;

    timerAnim = timer.createTimer(0, interval, () => {
      updateFrame();
    });

    timerProgress = timer.createTimer(0, interval, () => {
      updateProgress();
    });
  }

  /** 
   * Остановка анимации
   */
  function stop() {
    if (timerAnim) {
      timer.stopTimer(timerAnim);
      timerAnim = undefined;
    }
    if (timerProgress) {
      timer.stopTimer(timerProgress);
      timerProgress = undefined;
    }
  }

  /** 
   * Обновление позиции стрелки
   */
  function updateFrame() {
    if (!secondHand) return;
    let now = hmSensor.createSensor(hmSensor.id.TIME);
    let secondAngle = (360 * (now.second + (now.utc % 1000) / 1000)) / 60;
    secondHand.setProperty(hmUI.prop.ANGLE, secondAngle);
  }

  /** 
   * Обновление уровня прогресса кольца
   */
  function updateProgress() {
    if (!secondCircle) return;
    let now = hmSensor.createSensor(hmSensor.id.TIME);
    let progress = (100 * (now.second + (now.utc % 1000) / 1000)) / 60;
    secondCircle.setProperty(hmUI.prop.LEVEL, progress);
  }

  return {
    init,
    start,
    stop,
    updateFrame,
    updateProgress,
  };
})();


---

⚙️ Как использовать в циферблате

Пример интеграции в index.js вашего циферблата:

import { SmoothTimeAnimator } from "./SmoothTimeAnimator.js";

try {
(() => {
  const __$$app$$__ = __$$hmAppManager$$__.currentApp;
  const __$$module$$__ = __$$app$$__.current;
  const logger = DeviceRuntimeCore.HmLogger.getLogger("smooth_example");

  let secondHand, secondCircle;

  __$$module$$__.module = DeviceRuntimeCore.WatchFace({
    init_view() {
      // --- Фон ---
      hmUI.createWidget(hmUI.widget.IMG, {
        x: 0, y: 0, src: "1.png", show_level: hmUI.show_level.ONLY_NORMAL,
      });

      // --- Секундное кольцо ---
      secondCircle = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
        center_x: 233,
        center_y: 233,
        start_angle: 0,
        end_angle: 360,
        radius: 176,
        line_width: 115,
        color: 0xFFFF712D,
        show_level: hmUI.show_level.ONLY_NORMAL,
      });

      // --- Секундная стрелка ---
      secondHand = hmUI.createWidget(hmUI.widget.IMG, {
        x: 0, y: 0,
        w: 467, h: 467,
        center_x: 233, center_y: 233,
        angle: 0,
        src: "animation/second.png",
        show_level: hmUI.show_level.ONLY_NORMAL,
      });

      // --- Делегат ---
      hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
        resume_call: () => {
          SmoothTimeAnimator.init({
            secondHand,
            secondCircle,
            interval: 50,
          });
        },
        pause_call: () => {
          SmoothTimeAnimator.stop();
        },
      });
    },

    build() {
      this.init_view();
    },
  });
})();
} catch (e) {
  console.log("Error:", e);
}


---

💎 Преимущества шаблона

Возможность	Описание

✅ Плавность	Плавное движение стрелки и кольца (обновление 20 FPS)
🔄 Синхронизация	Берёт utc % 1000 для суб-секундного расчёта
🔌 Модульность	Можно импортировать и подключать в любой watchface
💤 Энергосбережение	Анимация автоматически останавливается при pause_call()
⚙️ Настраиваемость	Можно задать свой интервал обновления (например, 33 мс = 30 FPS)
