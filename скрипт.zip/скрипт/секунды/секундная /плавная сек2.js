﻿// Секундная стрелка с плавной анимацией
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    second_path: 'HAND_S.png',      // Убедитесь, что файл HAND_S.png лежит в папке assets
                    second_centerX: 233,
                    second_centerY: 233,
                    second_posX: 166,               // Координата "кончика" стрелки по X
                    second_posY: 233,               // Координата "кончика" стрелки по Y
                    fresh_frequency: 25,            // Плавное движение (25 кадров в секунду)
                    show_level: hmUI.show_level.ONLY_NORMAL   // В AOD секунда обычно не показывается
                });