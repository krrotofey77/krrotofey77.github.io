﻿/*
** Watch face: Minimal Smooth Second Hand
** ZeppOS SDK v2.1.1+
*/

try {
  (() => {
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    const __$$module$$__ = __$$app$$__.current;
    const logger = DeviceRuntimeCore.HmLogger.getLogger('MinimalSmoothSeconds');

    const h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__)
    );

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        logger.log("Initializing smooth seconds...");

        // Плавная секундная стрелка
        hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          second_path: 'Sec.png',         // Изображение стрелки
          second_centerX: 233,               // Центр вращения (X)
          second_centerY: 233,               // Центр вращения (Y)
          second_posX: 166,                  // Конечная точка (X)
          second_posY: 233,                  // Конечная точка (Y)
          fresh_frequency: 25,               // Обновление 25 раз в секунду (плавно)
          show_level: hmUI.show_level.ONLY_NORMAL,  // Только в нормальном режиме (не AOD)
        });
      },

      onInit() {
        logger.log("Watch face initialized.");
      },

      build() {
        this.init_view();
        logger.log("Watch face built.");
      },

      onDestroy() {
        logger.log("Watch face destroyed.");
      },
    });
  })();
} catch (e) {
  console.log('Mini Program Error', e);
  e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}
////////
┌───────────────────────┐
 │   Запуск WatchFace    │
 └──────────┬────────────┘
            │
            ▼
 ┌───────────────────────┐
 │   onInit() → логгер   │
 └──────────┬────────────┘
            │
            ▼
 ┌──────────────────────────────┐
 │ build() → вызов init_view() │
 └──────────┬──────────────────┘
            │
            ▼
 ┌─────────────────────────────────────────┐
 │ hmUI.createWidget(TIME_POINTER, {...})  │
 │   • Загружаем картинку стрелки           │
 │   • Центр вращения (X, Y)                │
 │   • Конечная точка (X, Y)                │
 │   • Частота обновления (fresh_frequency) │
 │   • Уровень показа (show_level)          │
 └──────────┬──────────────────────────────┘
            │
            ▼
 ┌──────────────────────────────────────────┐
 │ SDK следит за временем:                  │
 │   каждое обновление кадра                │
 │   вычисляет угол поворота стрелки:       │
 │   угол = (2π/60) × (секунды + доля)      │
 │   (доля = прогресс между секундами)      │
 └──────────┬───────────────────────────────┘
            │
            ▼
 ┌───────────────────────┐
 │   Поворот стрелки     │
 │   и отрисовка кадра   │
 └──────────┬────────────┘
            │
            ▼
 ┌───────────────────────────────┐
 │   fresh_frequency раз/сек     │
 │   (у тебя = 25 → плавно)      │
 └──────────┬────────────────────┘
            │
            ▼
 ┌───────────────────────┐
 │   Следующее обновление │
 └───────────────────────┘
 /////////