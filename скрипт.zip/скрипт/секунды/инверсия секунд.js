// --- Секундное кольцо ---
            normal_second_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                center_x: 233, 
                center_y: 233, 
                start_angle: 362, //стирание прогресса//. начало
                end_angle: 0, //стирание прогресса//. конец
                radius: 176,
                line_width: 115, 
                corner_flag: 3,
                color: 0xFFf973826,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_second_circle_scale.setAlpha(255);


    // Инвертированный прогресс (эффект стирания)
    let normal_secondCircleProgress = 100 - (100 * (second + (timeSensor.utc % 1000)/1000) / 60);
    