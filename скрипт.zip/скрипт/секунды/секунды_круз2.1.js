let normal_second_circle_scale = '';
let s_Timer = null;
const now = hmSensor.createSensor(hmSensor.id.TIME);

// Функция для обновления прогресс-бара
function DisplaySeconds() {
    let cs = now.second * 6; // Преобразование секунд в градусы
    normal_second_circle_scale.setProperty(hmUI.prop.MORE, {
        end_angle: cs - 90, // Установка угла
    });
}

// Создание виджета ARC
normal_second_circle_scale = hmUI.createWidget(hmUI.widget.ARC, {
    x: 3,
    y: 3,
    w: 460,
    h: 460,
    start_angle: -90,
    end_angle: 270,
    color: 0xFFFF0000,
    line_width: 30,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

// Первоначальный вызов для отображения текущих секунд
DisplaySeconds();

// Создание таймера для обновления каждую секунду
s_Timer = timer.createTimer(1000, 1000, DisplaySeconds, {});

// Делегат виджета для управления поведением
const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
    resume_call: () => {
        DisplaySeconds(); // Обновление при возобновлении
        if (s_Timer == null) {
            s_Timer = timer.createTimer(1000, 1000, DisplaySeconds, {});
        }
    },
    pause_call: () => {
        if (s_Timer) {
            timer.stopTimer(s_Timer); // Остановка таймера
            s_Timer = null;
        }
    },
});
