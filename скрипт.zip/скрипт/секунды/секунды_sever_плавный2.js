﻿

       
 // Константы для улучшения читаемости
 const CENTER_X = 233;
 const CENTER_Y = 233;
 const CIRCLE_RADIUS = 150;
 const CIRCLE_COLOR = 0xFF06E8F1;
 const CIRCLE_LINE_WIDTH = 150;
 const CIRCLE_CORNER_FLAG = 3;
        // Переменные для виджетов и таймера
        let backgroundImage;
        let circleProgress;
        let secondHand;
        let hourHand;
        let minuteHand;
        let imageWidget; // Добавлен виджет изображения
        let timeSensor;
        let updateTimer = null;

        // Конфигурация для кругового прогресса
        const circleScaleConfig = {
            center_x: CENTER_X,
            center_y: CENTER_Y,
            start_angle: 0,
            end_angle: 360,
            radius: CIRCLE_RADIUS,
            line_width: CIRCLE_LINE_WIDTH,
            corner_flag: CIRCLE_CORNER_FLAG,
            color: CIRCLE_COLOR,
            show_level: hmUI.show_level.ONLY_NORMAL,
        };

    //////////////////////////////////////////////////////////
                // Создание фонового изображения
                backgroundImage = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 466,
                    h: 466,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                

                // Создание кругового прогресса
                circleProgress = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, circleScaleConfig);

// Создание дополнительного изображения
                imageWidget = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    src: '3.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                // Создание секундной стрелки
                secondHand = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 467,
                    h: 467,
                    pos_x: CENTER_X - 28,
                    pos_y: CENTER_Y - 227,
                    center_x: CENTER_X,
                    center_y: CENTER_Y,
                    angle: 0,
                    src: '102.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // Создание часовой и минутной стрелок
                hourHand = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_path: '101.png',
                    hour_centerX: CENTER_X,
                    hour_centerY: CENTER_Y,
                    hour_posX: 27,
                    hour_posY: 228,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                minuteHand = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    minute_path: '100.png',
                    minute_centerX: CENTER_X,
                    minute_centerY: CENTER_Y,
                    minute_posX: 28,
                    minute_posY: 228,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // Инициализация сенсора времени
                timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

                // Создание делегата для управления жизненным циклом
                const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: () => {
                        updateTimer = timer.createTimer(0, 50, () => {
                            const now = new Date();
                            const seconds = now.getSeconds();
                            const milliseconds = now.getMilliseconds();

                            // Плавный угол для секундной стрелки
                            const smoothSecondsAngle = (seconds + milliseconds / 1000) * 6; // 6 градусов в секунду
                            secondHand.setProperty(hmUI.prop.ANGLE, smoothSecondsAngle);

                            // Плавный прогресс для кругового индикатора
                            const progressStand = (seconds + milliseconds / 1000) / 60;
                            const level = Math.round(progressStand * 100);
                            circleScaleConfig.level = level;
                            circleProgress.setProperty(hmUI.prop.MORE, circleScaleConfig);
                        });
                    },
                    pause_call: () => {
                        if (updateTimer) {
                            timer.stopTimer(updateTimer);
                            updateTimer = null;
                        }
                    },
                });
           