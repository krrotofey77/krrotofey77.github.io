/*
** Watch_Face_Editor tool
** Секундная стрелка с bounce (минимальный шаблон)
** Copyright © CashaCX75. All Rights Reserved
*/

try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

    'use strict';

    // Глобальные для секунд
    let normal_analog_clock_pro_second_pointer_img = '';
    let normal_timerUpdateSec = undefined;
    let timeSensor;

    // Logger (опционально)
    const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({

      init_view() {
        const deviceInfo = hmSetting.getDeviceInfo();
        if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

        // --- СЕКУНДНАЯ стрелка ---
        normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0, y: 0, w: deviceInfo.width, h: deviceInfo.height,
          pos_x: 233 - 26, pos_y: 233 - 233,  // адаптируй под твою стрелку
          center_x: 233, center_y: 233,
          src: 'S_1.png',
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // 🔧 Настройки bounce-анимации
        const bounceSettings = {
          bounce_back_angle: -4,
          bounce_forward_angle: 6,
          dur_back: 80,
          dur_forward: 100,
          dur_return: 60,
          anim_fps: 99
        };

        // ⚙️ Функция bounce
        function bounceSecond(second) {
          if (timeSensor.second !== second) {
            // logger.log(`Mismatch! Sensor: ${timeSensor.second}, arg: ${second}`);
            return;
          }
          const baseAngle = second * 6;
          const { bounce_back_angle, bounce_forward_angle, dur_back, dur_forward, dur_return, anim_fps } = bounceSettings;

          const anim = {
            anim_steps: [
              { anim_rate: 'ease-out', anim_duration: dur_back, anim_from: baseAngle, anim_to: baseAngle + bounce_back_angle, anim_key: 'angle' },
              { anim_rate: 'ease-in', anim_duration: dur_forward, anim_from: baseAngle + bounce_back_angle, anim_to: baseAngle + bounce_forward_angle, anim_key: 'angle' },
              { anim_rate: 'ease-out', anim_duration: dur_return, anim_from: baseAngle + bounce_forward_angle, anim_to: baseAngle, anim_key: 'angle' },
            ],
            anim_fps: anim_fps,
            anim_auto_start: 1,
            anim_repeat: 0,
            anim_auto_destroy: 1,
          };

          normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, anim);
          // logger.log(`Bounce to ${second} at ${baseAngle}°`);
        }

        // ⏱️ Таймер с синхронизацией
        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: function () {
            if (!normal_timerUpdateSec) {
              const nowMs = timeSensor.current;
              const currentSecond = timeSensor.second;
              const msToNext = (1000 - (nowMs % 1000)) % 1000;

              bounceSecond(currentSecond);

              normal_timerUpdateSec = timer.createTimer(msToNext, 1000, function () {
                bounceSecond(timeSensor.second);
                // logger.log(`Tick: ${timeSensor.second}`);
              });
              // logger.log(`Offset ${msToNext}ms, start: ${currentSecond}`);
            }
          },
          pause_call: function () {
            if (normal_timerUpdateSec) {
              timer.stopTimer(normal_timerUpdateSec);
              normal_timerUpdateSec = undefined;
            }
          },
        });
      },

      onInit() { logger.log('Seconds init'); },
      build() { this.init_view(); logger.log('Seconds ready'); },
      onDestroy() { logger.log('Seconds destroy'); }
    });
  })();
} catch (e) {
  console.log('Mini Program Error', e);
  e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}