/*
** Bounce Second WatchFace Pro
** by Grok (v2 – smooth, fixed, configurable)
** Для всех моделей Zepp OS (GTR/GTS)
*/

try {
  (() => {
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    const __$$module$$__ = __$$app$$__.current;
    const logger = DeviceRuntimeCore.HmLogger.getLogger("Bounce_Second_Pro");

    let timeSensor;
    let timerSec;

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        logger.log("init_view start");

        const deviceInfo = hmSetting.getDeviceInfo();
        if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

        // ==========================================================
        // 🌄 ФОН
        // ==========================================================
        const bg = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          src: "background.png",
        });

        // ==========================================================
        // 🕑 СЕКУНДНАЯ СТРЕЛКА
        // ==========================================================
        const cx = deviceInfo.width / 2;
        const cy = deviceInfo.height / 2;

        const secondHand = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: cx - 12,
          pos_y: cy - 203,
          center_x: cx,
          center_y: cy,
          src: "second.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // ==========================================================
        // ⚙️ НАСТРОЙКИ (загрузка из SysPro или дефолт)
        // ==========================================================
        let bounceSettings = {
          bounce_back_angle: -4,
          bounce_forward_angle: 6,
          dur_back: 80,
          dur_forward: 100,
          dur_return: 60,
          anim_fps: 99,
          enable_shake: true, // эффект дребезжания
          dur_shake: 50,      // длительность дребезга
          shake_angle: 1.5,   // амплитуда дребезга
        };

        try {
          const stored = hmFS.SysProGetChars("bounce_settings");
          if (stored) {
            const parsed = JSON.parse(stored);
            Object.assign(bounceSettings, parsed);
            logger.log("Custom bounce settings loaded");
          }
        } catch (err) {
          logger.log("No custom settings found or parse error");
        }

        // ==========================================================
        // ⚙️ BOUNCE + SHAKE АНИМАЦИЯ
        // ==========================================================
        function bounceSecond(second) {
          if (timeSensor.second !== second) return;

          // 🧹 [1] очистка предыдущей анимации (улучшение №1)
          try {
            secondHand.setProperty(hmUI.prop.ANIM, null);
          } catch (e) {}

          const baseAngle = second * 6;
          const {
            bounce_back_angle,
            bounce_forward_angle,
            dur_back,
            dur_forward,
            dur_return,
            anim_fps,
            enable_shake,
            dur_shake,
            shake_angle,
          } = bounceSettings;

          // базовые три фазы
          const anim_steps = [
            {
              anim_rate: "ease-out",
              anim_duration: dur_back,
              anim_from: baseAngle,
              anim_to: baseAngle + bounce_back_angle,
              anim_key: "angle",
            },
            {
              anim_rate: "ease-in",
              anim_duration: dur_forward,
              anim_from: baseAngle + bounce_back_angle,
              anim_to: baseAngle + bounce_forward_angle,
              anim_key: "angle",
            },
            {
              anim_rate: "ease-out",
              anim_duration: dur_return,
              anim_from: baseAngle + bounce_forward_angle,
              anim_to: baseAngle,
              anim_key: "angle",
            },
          ];

          // 💥 добавляем дребезжание (улучшение №8)
          if (enable_shake) {
            anim_steps.push(
              {
                anim_rate: "ease-in-out",
                anim_duration: dur_shake,
                anim_from: baseAngle,
                anim_to: baseAngle + shake_angle,
                anim_key: "angle",
              },
              {
                anim_rate: "ease-out",
                anim_duration: dur_shake,
                anim_from: baseAngle + shake_angle,
                anim_to: baseAngle,
                anim_key: "angle",
              }
            );
          }

          const anim = {
            anim_steps,
            anim_fps,
            anim_auto_start: 1,
            anim_repeat: 0,
            anim_auto_destroy: 1,
          };

          secondHand.setProperty(hmUI.prop.ANIM, anim);
        }

        // ==========================================================
        // ⏱️ ТАЙМЕР С СИНХРОНИЗАЦИЕЙ
        // ==========================================================
        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: function () {
            if (!timerSec) {
              const nowMs = timeSensor.current;
              const currentSecond = timeSensor.second;
              const msToNext = (1000 - (nowMs % 1000)) % 1000;

              bounceSecond(currentSecond);

              timerSec = timer.createTimer(msToNext, 1000, () => {
                bounceSecond(timeSensor.second);
              });
            }
          },
          pause_call: function () {
            if (timerSec) {
              timer.stopTimer(timerSec);
              timerSec = undefined;
            }
          },
        });
      },

      onInit() {
        logger.log("Bounce WatchFace Pro init");
      },

      build() {
        this.init_view();
        logger.log("Bounce WatchFace Pro ready");
      },

      onDestroy() {
        // 🧹 Очистка таймера при уничтожении (улучшение №6)
        if (timerSec) {
          timer.stopTimer(timerSec);
          timerSec = undefined;
        }
        logger.log("Bounce WatchFace Pro destroyed");
      },
    });
  })();
} catch (e) {
  console.log("Mini Program Error", e);
  e && e.stack && e.stack.split(/\n/).forEach(i => console.log("error stack", i));
}