
/*
** Bounce Second WatchFace Template
** by ChatGPT (GPT-5)
** Для всех моделей Zepp OS (GTR/GTS)
*/

try {
(() => {
  const __$$app$$__ = __$$hmAppManager$$__.currentApp;
  const __$$module$$__ = __$$app$$__.current;
  const logger = DeviceRuntimeCore.HmLogger.getLogger("Bounce_Second");

  let timeSensor;
  let timerSec;

  __$$module$$__.module = DeviceRuntimeCore.WatchFace({
    init_view() {
      logger.log("init_view start");

      const deviceInfo = hmSetting.getDeviceInfo();
      if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

      // ==========================================================
      // 🌄 ФОН (замени на свой)
      // ==========================================================
      const bg = hmUI.createWidget(hmUI.widget.IMG, {
        x: 0,
        y: 0,
        w: deviceInfo.width,
        h: deviceInfo.height,
        src: "background.png", // ⚠️ положи этот файл в resources/
      });

      // ==========================================================
      // 🕑 СЕКУНДНАЯ СТРЕЛКА
      // ==========================================================
      const secondHand = hmUI.createWidget(hmUI.widget.IMG, {
        x: 0,
        y: 0,
        w: deviceInfo.width,
        h: deviceInfo.height,
        pos_x: 233 - 12, // координата нижней точки стрелки
        pos_y: 233 - 203, // длина стрелки
        center_x: 233,
        center_y: 233,
        src: "second.png", // ⚠️ сюда вставь свой PNG стрелки
        angle: 0,
        show_level: hmUI.show_level.ONLY_NORMAL,
      });

      // ==========================================================
      // 🔧 НАСТРОЙКИ bounce-анимации секундной стрелки
      // ==========================================================
      const bounceSettings = {
        bounce_back_angle: -4,   // отклонение назад (в градусах)
        bounce_forward_angle: 6, // перелёт вперёд
        dur_back: 100,           // длительность фазы назад (мс)
        dur_forward: 120,        // длительность вперёд (мс)
        dur_return: 80,          // возврат в центр (мс)
        anim_fps: 30,            // частота кадров
      };

      // ==========================================================
      // ⚙️ ФУНКЦИЯ bounce-анимации
      // ==========================================================
      function bounceSecond(second) {
        const baseAngle = second * 6; // каждая секунда = 6°
        const {
          bounce_back_angle,
          bounce_forward_angle,
          dur_back,
          dur_forward,
          dur_return,
          anim_fps,
        } = bounceSettings;

        const anim = {
          anim_steps: [
            {
              anim_rate: "ease-out",
              anim_duration: dur_back,
              anim_from: baseAngle,
              anim_to: baseAngle + bounce_back_angle,
              anim_key: "angle",
            },
            {
              anim_rate: "ease-in",
              anim_duration: dur_forward,
              anim_from: baseAngle + bounce_back_angle,
              anim_to: baseAngle + bounce_forward_angle,
              anim_key: "angle",
            },
            {
              anim_rate: "ease-out",
              anim_duration: dur_return,
              anim_from: baseAngle + bounce_forward_angle,
              anim_to: baseAngle,
              anim_key: "angle",
            },
          ],
          anim_fps: anim_fps,
          anim_auto_start: 1,
          anim_repeat: 0,
          anim_auto_destroy: 1,
        };

        secondHand.setProperty(hmUI.prop.ANIM, anim);
      }

      // ==========================================================
      // 🕒 ТАЙМЕР ОБНОВЛЕНИЯ СЕКУНДНОЙ СТРЕЛКИ
      // ==========================================================
      const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
        resume_call: function () {
          if (!timerSec) {
            bounceSecond(timeSensor.second);
            timerSec = timer.createTimer(0, 1000, () => {
              bounceSecond(timeSensor.second);
            });
          }
        },
        pause_call: function () {
          if (timerSec) {
            timer.stopTimer(timerSec);
            timerSec = undefined;
          }
        },
      });
    },

    onInit() {
      logger.log("Bounce WatchFace init");
    },
    build() {
      this.init_view();
      logger.log("Bounce WatchFace ready");
    },
    onDestroy() {
      logger.log("Bounce WatchFace destroyed");
    },
  });
})();
} catch (e) {
  console.log("Mini Program Error", e);
  e && e.stack && e.stack.split(/\n/).forEach(i => console.log("error stack", i));
}