/*
** Watch_Face_Editor tool
** Секундная стрелка с bounce-анимацией
*/

try {
(() => {
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
    const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_second_hand');

    let normal_analog_clock_pro_second_pointer_img = '';
    let normal_timerUpdateSec = undefined;
    let timeSensor = '';

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
        init_view() {
            console.log('Watch_Face.SecondHand');

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

            // --- СЕКУНДНАЯ стрелка ---
            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0, y: 0, w: deviceInfo.width, h: deviceInfo.height,
              pos_x: 233 - 12, pos_y: 233 - 203,
              center_x: 233, center_y: 233,
              src: 'A100_026.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // 🔧 Настройки bounce-анимации
            const bounceSettings = {
              bounce_back_angle: -4,
              bounce_forward_angle: 6,
              dur_back: 100,
              dur_forward: 120,
              dur_return: 80,
              anim_fps: 30
            };

            // ⚙️ Функция bounce-анимации секундной стрелки
            function bounceSecond(second) {
              const baseAngle = second * 6;
              const {
                bounce_back_angle,
                bounce_forward_angle,
                dur_back,
                dur_forward,
                dur_return,
                anim_fps
              } = bounceSettings;

              const anim = {
                anim_steps: [
                  {
                    anim_rate: 'ease-out',
                    anim_duration: dur_back,
                    anim_from: baseAngle,
                    anim_to: baseAngle + bounce_back_angle,
                    anim_key: 'angle',
                  },
                  {
                    anim_rate: 'ease-in',
                    anim_duration: dur_forward,
                    anim_from: baseAngle + bounce_back_angle,
                    anim_to: baseAngle + bounce_forward_angle,
                    anim_key: 'angle',
                  },
                  {
                    anim_rate: 'ease-out',
                    anim_duration: dur_return,
                    anim_from: baseAngle + bounce_forward_angle,
                    anim_to: baseAngle,
                    anim_key: 'angle',
                  },
                ],
                anim_fps: anim_fps,
                anim_auto_start: 1,
                anim_repeat: 0,
                anim_auto_destroy: 1,
              };

              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, anim);
            }

            // ⏱️ Запуск таймера обновления секундной стрелки
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                if (!normal_timerUpdateSec) {
                  let animDelay = timeSensor.utc % 1000;
                  let animRepeat = 1000;
                  normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, function () {
                    bounceSecond(timeSensor.second);
                  });
                }
              }),
              pause_call: (function () {
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
              }),
            });
        },

        onInit() { logger.log('second hand init'); },
        build() { this.init_view(); logger.log('second hand ready'); },
        onDestroy() { logger.log('second hand destroy'); }
    });
})();
} catch (e) {
  console.log('Mini Program Error', e);
  e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}