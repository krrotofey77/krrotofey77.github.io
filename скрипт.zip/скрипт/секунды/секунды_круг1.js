let normal_second_circle_scale = ''
let normal_timerUpdateSec = undefined;
let idle_timerUpdateSec = undefined;
let anim_sec_angle = 0;
let timeSensor = '';
///////////////////////////////////////////////////
if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
let screenType = hmSetting.getScreenType();



normal_second_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
	center_x: 233,
	center_y: 233,
	start_angle: 0,
	end_angle: 0,
	radius: 221,
	line_width: 30,
	corner_flag: 3,
	color: 0xFF00FF00,
	level: 100,
	show_level: hmUI.show_level.ONLY_NORMAL,
  });
  //////////////////////////////////////////////////
  


			
  function arch_update() {
	// console.log('scale_call()');
	// console.log('update scales SECOND');


	let cur_second = timeSensor.second;
	if (cur_second == 0) cur_second = 60;
	anim_sec_angle = (cur_second * 6) + 2;
	let start_angle = 362
	if (anim_sec_angle > 362) anim_sec_angle = 2;
	//console.log(anim_sec_angle, start_angle)
	if (normal_second_circle_scale) {
	  normal_second_circle_scale.setProperty(hmUI.prop.MORE, {
		center_x: 233,
		center_y: 233,
		start_angle: anim_sec_angle,
		end_angle: start_angle,
		radius: 221,
		line_width: 25,
		corner_flag: 3,
		color: 0xFF00FF00,
		level: 100,
	  });
	};

  };
	
	//////////////////////////////////////////////
	const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
		resume_call: (function () {
		  console.log('resume_call()');
		  arch_update();
		  //time_update(true, true);
		  
		  if (screenType == hmSetting.screen_type.WATCHFACE) {
			if (!normal_timerUpdateSec) {
			  let animDelay = timeSensor.utc % 1000;
			  let animRepeat = 1000;
			  normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
				//time_update(false, true);
				arch_update();
			  }));  // end timer 
			};  // end timer check
		  };  // end screenType

		}),
		pause_call: (function () {
		  console.log('pause_call()');


		  if (normal_timerUpdateSec) {
			timer.stopTimer(normal_timerUpdateSec);
			normal_timerUpdateSec = undefined;
		  }
		  if (idle_timerUpdateSec) {
			timer.stopTimer(idle_timerUpdateSec);
			idle_timerUpdateSec = undefined;
		  }

		}),
	  });