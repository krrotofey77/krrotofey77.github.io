let timeSensor = '';
let normal_second_circle_scale = '';
let normal_timerUpdateSec = undefined;
const CENTER_X = 233;
const CENTER_Y = 233;
const RADIUS = 221;
const LINE_WIDTH = 30;
const COLOR = 0xFF00FF00;

if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
let screenType = hmSetting.getScreenType();

/////////////////////////////////////////////////////////////////////////////
normal_second_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
    center_x: CENTER_X,
    center_y: CENTER_Y,
    start_angle: 0,
    end_angle: 0,
    radius: RADIUS,
    line_width: LINE_WIDTH,
    corner_flag: 3,
    color: COLOR,
    level: 100,
    show_level: hmUI.show_level.ONLY_NORMAL,
});
////////////////////////////////////////////////////////////////////////////////////
function arch_update() {
    let cur_second = timeSensor.second || 60; // Если cur_second == 0, то используем 60
    let anim_sec_angle = (cur_second * 6) + 2;
    let start_angle = anim_sec_angle > 362 ? 2 : 362; // Упрощение условия

    if (normal_second_circle_scale) {
        normal_second_circle_scale.setProperty(hmUI.prop.MORE, {
            center_x: CENTER_X,
            center_y: CENTER_Y,
            start_angle: anim_sec_angle,
            end_angle: start_angle,
            radius: RADIUS,
            line_width: LINE_WIDTH - 5, // Уменьшение ширины для лучшего визуального эффекта
            corner_flag: 3,
            color: COLOR,
            level: 100,
        });
    }
}

function startTimer() {
    if (!normal_timerUpdateSec) {
        let animDelay = timeSensor.utc % 1000;
        normal_timerUpdateSec = timer.createTimer(animDelay, 1000, () => {
            arch_update();
        });
    }
}

const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
    resume_call: () => {
        console.log('resume_call()');
        arch_update();
        if (screenType === hmSetting.screen_type.WATCHFACE) {
            startTimer();
        }
    },
    pause_call: () => {
        console.log('pause_call()');
        if (normal_timerUpdateSec) {
            timer.stopTimer(normal_timerUpdateSec);
            normal_timerUpdateSec = undefined;
        }
    },
});
