	    let normal_second_circle_scale = ''		
		let s_Timer = null;
		let now = hmSensor.createSensor(hmSensor.id.TIME);

		function DisplaySeconds() {
			let cs = now.second * 6; //second minute hour
			normal_second_circle_scale.setProperty(hmUI.prop.MORE, {
				end_angle: cs - 90,
			});
		}				
		//////////////////////////////
		normal_second_circle_scale = hmUI.createWidget(hmUI.widget.ARC, {
			x: 69,
			y: 69,
			w: 340,
			h: 340,
			start_angle: -90,
			end_angle: 270,
			color: 0x009200,
			line_width: 24,
			show_level: hmUI.show_level.ONLY_NORMAL,
		});
		///////////////////////////////////
		const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
			resume_call: (function () {
					  DisplaySeconds();
					  if (s_Timer == null) s_Timer = timer.createTimer(1000, 1000, DisplaySeconds, {});
				  }),
				  pause_call: (function () {
					  timer.stopTimer(s_Timer);
					  s_Timer = null;				
			}),
		  });