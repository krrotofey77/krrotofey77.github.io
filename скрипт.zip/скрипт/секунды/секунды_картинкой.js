let normal_second_circle_scale = '';
let normal_timerUpdateSec = undefined;
let idle_timerUpdateSec = undefined;
let anim_sec_angle = 0;
let timeSensor = '';
///////////////////////////////////////////////////
if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
let screenType = hmSetting.getScreenType();

// Создаем виджет для отображения изображения
normal_second_circle_scale = hmUI.createWidget(hmUI.widget.IMG, {
  x: 0,
  y: 0,
  src: 'arc_0.png', // Начальное изображение
  show_level: hmUI.show_level.ONLY_NORMAL,
});

//////////////////////////////////////////////////

function arch_update() {
  let cur_second = timeSensor.second;
  if (cur_second == 0) cur_second = 60;
  let imageIndex = cur_second; // Индекс изображения соответствует текущей секунде
  let imagePath = `arc_${imageIndex}.png`; // Путь к изображению

  if (normal_second_circle_scale) {
    normal_second_circle_scale.setProperty(hmUI.prop.MORE, {
      src: imagePath,
    });
  }
}

//////////////////////////////////////////////
const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
  resume_call: (function () {
    console.log('resume_call()');
    arch_update();
    
    if (screenType == hmSetting.screen_type.WATCHFACE) {
      if (!normal_timerUpdateSec) {
        let animDelay = timeSensor.utc % 1000;
        let animRepeat = 1000;
        normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
          arch_update();
        }));  // end timer 
      };  // end timer check
    };  // end screenType

  }),
  pause_call: (function () {
    console.log('pause_call()');

    if (normal_timerUpdateSec) {
      timer.stopTimer(normal_timerUpdateSec);
      normal_timerUpdateSec = undefined;
    }
    if (idle_timerUpdateSec) {
      timer.stopTimer(idle_timerUpdateSec);
      idle_timerUpdateSec = undefined;
    }

  }),
});