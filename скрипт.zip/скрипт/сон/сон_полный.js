try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        const __$$module$$__ = __$$app$$__.current;
        const logger = Logger.getLogger('watchface_SashaCX75');

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                const sleep = hmSensor.createSensor(hmSensor.id.SLEEP);
                let sleepInfo = sleep.getBasicInfo();
                let sleepTotalTime = sleep.getTotalTime();
                let sleepStartTime = sleepInfo.startTime;
                let sleepEndTime = sleepInfo.endTime + 1;
                let sleepScore = sleepInfo.score;
                let sleepStageArray = sleep.getSleepStageData();
                const modelData = sleep.getSleepStageModel();

                // Создаем текстовые виджеты для отображения данных
                const sleepTimeText = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 50,
                    y: 100,
                    w: 200,
                    h: 30,
                    text_size: 24,
                    color: 0xFFFFFF,
                    align_h: hmUI.align.LEFT,
                    text: '--:--',
                });

                const sleepStartText = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 50,
                    y: 140,
                    w: 200,
                    h: 30,
                    text_size: 24,
                    color: 0xFFFFFF,
                    align_h: hmUI.align.LEFT,
                    text: 'Начало: --:--',
                });

                const sleepEndText = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 50,
                    y: 180,
                    w: 200,
                    h: 30,
                    text_size: 24,
                    color: 0xFFFFFF,
                    align_h: hmUI.align.LEFT,
                    text: 'Конец: --:--',
                });

                const wakeTimeText = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 50,
                    y: 220,
                    w: 200,
                    h: 30,
                    text_size: 24,
                    color: 0xFFFFFF,
                    align_h: hmUI.align.LEFT,
                    text: 'Бодрствование: -- мин.',
                });

                const sleepScoreText = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 50,
                    y: 260,
                    w: 200,
                    h: 30,
                    text_size: 24,
                    color: 0xFFFFFF,
                    align_h: hmUI.align.LEFT,
                    text: 'Оценка: --',
                });

                function updateSleepInfo() {
                    // Обновляем данные о сне
                    sleepTotalTime = sleep.getTotalTime();
                    sleepInfo = sleep.getBasicInfo();
                    sleepStartTime = sleepInfo.startTime;
                    if (sleepStartTime >= 24 * 60) {
                        sleepStartTime -= 24 * 60;
                    }

                    sleepEndTime = sleepInfo.endTime + 1;
                    if (sleepEndTime >= 24 * 60) {
                        sleepEndTime -= 24 * 60;
                    }

                    // Рассчитываем время бодрствования
                    let wakeTime = 0;
                    sleepStageArray = sleep.getSleepStageData();

                    for (let i = 0; i < sleepStageArray.length; i++) {
                        let data = sleepStageArray[i];
                        if (data.model == modelData.WAKE_STAGE) {
                            wakeTime += data.stop + 1 - data.start;
                        }
                    }

                    // Вычитаем время бодрствования из общего времени сна
                    sleepTotalTime -= wakeTime;

                    // Обновляем текстовые виджеты
                    sleepTimeText.setProperty(hmUI.prop.TEXT, 'Сон: ' + Math.floor(sleepTotalTime / 60).toString().padStart(2, "0") + ':' + (sleepTotalTime % 60).toString().padStart(2, "0"));
                    sleepStartText.setProperty(hmUI.prop.TEXT, 'Начало: ' + Math.floor(sleepStartTime / 60).toString().padStart(2, "0") + ':' + (sleepStartTime % 60).toString().padStart(2, "0"));
                    sleepEndText.setProperty(hmUI.prop.TEXT, 'Конец: ' + Math.floor(sleepEndTime / 60).toString().padStart(2, "0") + ':' + (sleepEndTime % 60).toString().padStart(2, "0"));
                    wakeTimeText.setProperty(hmUI.prop.TEXT, 'Бодрствование: ' + String(wakeTime) + ' мин.');
                    sleepScoreText.setProperty(hmUI.prop.TEXT, 'Оценка: ' + String(sleepScore));
                }

                // Создаем делегат для обновления данных при возобновлении работы
                const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: () => {
                        updateSleepInfo();
                    },
                });

                // Первоначальное обновление данных
                updateSleepInfo();
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}