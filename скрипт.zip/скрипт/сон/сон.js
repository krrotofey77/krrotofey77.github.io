﻿try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        const __$$module$$__ = __$$app$$__.current;
        const logger = Logger.getLogger('watchface_SashaCX75');

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                let sleep_time_txt = '';
                let sleep_start_time_txt = '';
                let sleep_end_time_txt = '';
                let sleep_score_txt = '';
                let wake_time_txt = '';

                const sleep = hmSensor.createSensor(hmSensor.id.SLEEP);
                let sleepInfo = sleep.getBasicInfo();
                let sleepTotalTime = sleep.getTotalTime();
                let sleepStartTime = sleepInfo.startTime;
                let sleepEndTime = sleepInfo.endTime + 1;
                let sleepScore = sleepInfo.score;
                let sleepStageArray = sleep.getSleepStageData();
                const modelData = sleep.getSleepStageModel();

                function updateSleepInfo() {
                    sleepTotalTime = sleep.getTotalTime();
                    sleepInfo = sleep.getBasicInfo();
                    sleepStartTime = sleepInfo.startTime;
                    if (sleepStartTime >= 24 * 60) {
                        sleepStartTime -= 24 * 60;
                    }

                    sleepEndTime = sleepInfo.endTime + 1;
                    if (sleepEndTime >= 24 * 60) {
                        sleepEndTime -= 24 * 60;
                    }

                    let wakeTime = 0;
                    sleepStageArray = sleep.getSleepStageData();

                    for (let i = 0; i < sleepStageArray.length; i++) {
                        let data = sleepStageArray[i];
                        if (data.model == modelData.WAKE_STAGE) {
                            wakeTime += data.stop + 1 - data.start;
                        }
                    }

                    sleepTotalTime -= wakeTime;

                    sleep_time_txt.setProperty(hmUI.prop.TEXT, ' ' + Math.floor(sleepTotalTime / 60).toString().padStart(2, "0") + ':' + (sleepTotalTime % 60).toString().padStart(2, "0"));
                    sleep_start_time_txt.setProperty(hmUI.prop.TEXT, Math.floor(sleepStartTime / 60).toString().padStart(2, "0") + ':' + (sleepStartTime % 60).toString().padStart(2, "0"));
                    sleep_end_time_txt.setProperty(hmUI.prop.TEXT, Math.floor(sleepEndTime / 60).toString().padStart(2, "0") + ':' + (sleepEndTime % 60).toString().padStart(2, "0"));
                    wake_time_txt.setProperty(hmUI.prop.TEXT, 'Не спали: ' + String(wakeTime) + ' мин.');
                    sleep_score_txt.setProperty(hmUI.prop.TEXT, ' ' + String(sleepScore));
                }

                sleep_time_txt = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 43,
                    y: 285,
                    w: 150,
                    h: 35,
                    text_size: 28,
                    char_space: 0,
                    line_space: 0,
                    font: 'fonts/Impact.ttf',
                    color: 0xFFFFFFFF,
                    align_h: hmUI.align.RIGHT,
                    align_v: hmUI.align.TOP,
                    text_style: hmUI.text_style.ELLIPSIS,
                    text: "--",
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: () => {
                        updateSleepInfo();
                    },
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}