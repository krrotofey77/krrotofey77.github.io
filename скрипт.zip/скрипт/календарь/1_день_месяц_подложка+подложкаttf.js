﻿/*
    ** Calendar Template for Watch Faces
    ** Based on Watch_Face_Editor tool, watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */

try {
    (() => {
        // Инициализация приложения и текущего модуля
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        const __$$module$$__ = __$$app$$__.current;

        // Настройки календаря
        const customFont = 'fonts/mi-Bold_0.ttf'; // Путь к шрифту для календаря
        let calendarWidgets = []; // Массив для хранения виджетов календаря
        let timeSensor = null; // Переменная для сенсора времени

        // Размеры и отступы для календаря
        const cellSizeWidth = 30; // Ширина ячейки дня
        const cellSizeHeight = 25; // Высота ячейки дня
        const cellSpacing = 2; // Отступ между ячейками

        // Функция обновления календаря
        function updateCalendar(day, month, year) {
            // Удаляем старые виджеты календаря
            calendarWidgets.forEach(widget => hmUI.deleteWidget(widget));
            calendarWidgets = [];

            // Используем переданные параметры или текущую дату
            const today = new Date(year, month, day);
            const currentDay = today.getDate();
            const currentMonth = today.getMonth();
            const currentYear = today.getFullYear();

            // Определяем первый день месяца и количество дней в месяце
            const firstDay = (new Date(currentYear, currentMonth, 1).getDay() + 6) % 7;
            const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();

            // Названия месяцев и дней недели
            const monthNames = ["Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
                "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"];
            const daysOfWeek = ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"];

            // Начальные координаты для отрисовки календаря
            const startX = 210; // Начальная позиция по X
            const startY = 195; // Начальная позиция по Y

            // Цвета для календаря
            const colorWeekday = 0xFFFFFF; // Цвет будних дней
            const colorSaturday = 0xecb2b2; // Цвет субботы
            const colorSunday = 0xecb2b2; // Цвет воскресенья
            const colorToday = 0xFF0000; // Цвет текущего дня
            const backgroundColor = 0x333333; // Цвет фона заголовков
            const backgroundRadius = 8; // Скругление углов фона
            const todayBackgroundColor = 0x555555; // Цвет фона текущего дня

            // Отображение названия месяца и года
            calendarWidgets.push(hmUI.createWidget(hmUI.widget.TEXT, {
                x: startX + 50,
                y: startY,
                w: 200,
                h: 40,
                color: 0xFFFFFF,
                text_size: 20,
                align_h: hmUI.align.CENTER_H,
                text: `${monthNames[currentMonth]} ${currentYear}`,
                font: customFont
            }));

            // Фон для заголовков дней недели
            calendarWidgets.push(hmUI.createWidget(hmUI.widget.FILL_RECT, {
                x: startX - 5,
                y: startY + 30 - 5,
                w: cellSizeWidth * 7 + 10,
                h: 30,
                radius: backgroundRadius,
                color: backgroundColor
            }));

            // Заголовки дней недели
            for (let i = 0; i < 7; i++) {
                calendarWidgets.push(hmUI.createWidget(hmUI.widget.TEXT, {
                    x: startX + i * cellSizeWidth,
                    y: startY + 30,
                    w: cellSizeWidth,
                    h: 30,
                    color: 0xC8C8C8,
                    text_size: 18,
                    align_h: hmUI.align.CENTER_H,
                    text: daysOfWeek[i],
                    font: customFont
                }));
            }

            // Дни месяца
            for (let i = 1; i <= daysInMonth; i++) {
                let x = startX + ((i + firstDay - 1) % 7) * cellSizeWidth;
                let y = startY + 60 + Math.floor((i + firstDay - 1) / 7) * cellSizeHeight;

                // Подсветка текущего дня
                if (i === currentDay) {
                    calendarWidgets.push(hmUI.createWidget(hmUI.widget.FILL_RECT, {
                        x: x - cellSpacing,
                        y: y - cellSpacing,
                        w: cellSizeWidth + cellSpacing * 2,
                        h: cellSizeHeight + cellSpacing * 2,
                        radius: 6,
                        color: todayBackgroundColor
                    }));
                }

                // Выбор цвета текста в зависимости от дня недели
                let textColor = ((i + firstDay - 1) % 7 === 5) ? colorSaturday :
                    ((i + firstDay - 1) % 7 === 6) ? colorSunday :
                        colorWeekday;
                if (i === currentDay) textColor = colorToday;

                // Отображение числа
                calendarWidgets.push(hmUI.createWidget(hmUI.widget.TEXT, {
                    x: x,
                    y: y,
                    w: cellSizeWidth,
                    h: cellSizeHeight,
                    color: textColor,
                    text_size: 18,
                    align_h: hmUI.align.CENTER_H,
                    text: `${i}`,
                    font: customFont
                }));
            }
        }

        // Основной модуль циферблата
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                // Создание сенсора времени
                if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

                // Подписка на событие смены дня
                timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
                    time_update(true);
                });

                // Инициализация календаря при старте
                time_update(true);

                // Отслеживание событий "пробуждения" и "паузы"
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: () => {
                        time_update(true); // Обновляем календарь при каждом "пробуждении"
                    },
                    pause_call: () => {}
                });

                // Функция обновления времени и календаря
                function time_update(updateDay = false) {
                    if (!timeSensor) return;
                    let g_day = timeSensor.day;
                    let g_month = timeSensor.month - 1; // Корректировка, так как month в hmSensor начинается с 1
                    let g_year = timeSensor.year;

                    if (updateDay) {
                        updateCalendar(g_day, g_month, g_year);
                    }
                }
            },

            onInit() {},

            build() {
                this.init_view();
            },

            onDestroy() {
                if (timeSensor) {
                    timeSensor.removeEventListener(timeSensor.event.DAYCHANGE);
                }
                calendarWidgets.forEach(widget => hmUI.deleteWidget(widget));
                calendarWidgets = [];
            }
        });
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}