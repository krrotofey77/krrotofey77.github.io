﻿// =====================================================
// ПРОСТАЯ СМЕНА ВИДЖЕТОВ ДЕНЬ / НОЧЬ
// =====================================================

// Сначала создаём сенсор времени
const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

// -------------------------------
// ИКОНКА ПУЛЬС
// -------------------------------
const heartIcon = hmUI.createWidget(hmUI.widget.IMG, {
    x: 100,
    y: 200,
    src: 'heart.png',
    show_level: hmUI.show_level.ONLY_NORMAL,
});




// -------------------------------
// ТЕКСТ ПУЛЬС
// -------------------------------

const heartText = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
    x: 90,
    y: 240,
    w: 100,
    h: 40,
    text_size: 22,
    color: 0xFFFFFFFF,
    type: hmUI.data_type.HEART,
    show_level: hmUI.show_level.ONLY_NORMAL,
});


// -------------------------------
// ИКОНКА КАЛОРИИ
// -------------------------------

const calIcon = hmUI.createWidget(hmUI.widget.IMG, {
    x: 100,
    y: 200,
    src: 'calories.png',
    show_level: hmUI.show_level.ONLY_NORMAL,
});


// -------------------------------
// ТЕКСТ КАЛОРИИ
// -------------------------------

const calText = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
    x: 90,
    y: 240,
    w: 100,
    h: 40,
    text_size: 22,
    color: 0xFFFFFFFF,
    type: hmUI.data_type.CAL,
    show_level: hmUI.show_level.ONLY_NORMAL,
});


// =====================================================
// ФУНКЦИЯ СМЕНЫ
// =====================================================

function updateDayNightWidgets() {

    // текущее время
    let hour = timeSensor.hour;

    // день = с 6 до 18
    let isDay = hour >= 6 && hour < 18;


    // =================================================
    // ДНЁМ ПОКАЗЫВАЕМ ПУЛЬС
    // =================================================

    if (isDay) {

        // показать пульс
        heartIcon.setProperty(hmUI.prop.VISIBLE, true);
        heartText.setProperty(hmUI.prop.VISIBLE, true);

        // скрыть калории
        calIcon.setProperty(hmUI.prop.VISIBLE, false);
        calText.setProperty(hmUI.prop.VISIBLE, false);
    }


    // =================================================
    // НОЧЬЮ ПОКАЗЫВАЕМ КАЛОРИИ
    // =================================================

    else {

        // скрыть пульс
        heartIcon.setProperty(hmUI.prop.VISIBLE, false);
        heartText.setProperty(hmUI.prop.VISIBLE, false);

        // показать калории
        calIcon.setProperty(hmUI.prop.VISIBLE, true);
        calText.setProperty(hmUI.prop.VISIBLE, true);
    }
}


// =====================================================
// ОБНОВЛЕНИЕ
// =====================================================

function time_update(updateMinute = false) {

    if (updateMinute) {

        // обновляем виджеты
        updateDayNightWidgets();
    }
}


// =====================================================
// ЗАПУСК
// =====================================================

// первый запуск
updateDayNightWidgets();


// обновление каждую минуту
timer.createTimer(
    0,
    60000,
    function () {

        updateDayNightWidgets();
    }
);