	
	let button_1 = ''
	let button_2 = ''
	let cc = 0
		
		let element_index = 0; 
        let element_count = 6;
		
		function click_PLUS() {
			element_index = (element_index + 1) % element_count;
			apply_content_switch();
		}
		
		function click_MINUS() {
			if (element_index == 0) {
			element_index = element_count - 1;
				} else {
			element_index = (element_index - 1) % element_count;
				}	
			apply_content_switch();
		}

		function apply_content_switch() {

			  normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 0);
			  normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, element_index == 0);
			  normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 0);
			  
			  normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);

			  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  
			  normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  
			  normal_stand_target_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  normal_stand_current_separator_img.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  normal_stand_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  
			  normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 5);
			  normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, element_index == 5);
			  normal_battery_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 5);
        };

/////////////////////////////////
Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {    //////////////////////создать кнопку  click_PLUS();
	x: 308,
	y: 364,
	w: 58,
	h: 49,
	text: '',
	color: 0xFFFF8C00,
	text_size: 24,
	press_src: 'Empty.png',
	normal_src: 'Empty.png',
	click_func: (button_widget) => {
	  click_PLUS();
	}, // end func
	show_level: hmUI.show_level.ONLY_NORMAL,
  }); // end button

  Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {     ////////////////////////////  создать кнопку  click_MINUS();
	x: 99,
	y: 364,
	w: 58,
	h: 49,
	text: '',
	color: 0xFFFF8C00,
	text_size: 24,
	press_src: 'Empty.png',
	normal_src: 'Empty.png',
	click_func: (button_widget) => {
	  click_MINUS();
	}, // end func
	show_level: hmUI.show_level.ONLY_NORMAL,
  }); // end button
////////////////////////////////////////////////////////////////////////////////////////////////////////////
if (cc ==0 ){
				
	normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
	normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
	
	normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
	normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
	normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

	normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
	normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
	normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
	
	normal_stand_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
	normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
	normal_stand_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
	normal_stand_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
	
	normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
	normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
	normal_battery_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
  cc = 1;
  }

