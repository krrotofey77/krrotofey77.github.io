﻿  

        let btn_zona1 = ''       
        let zona1_num = 0       
        let zona1_all = 2

        function click_zona1() {		  
        zona1_num = (zona1_num + 1) % (zona1_all + 1);  
        if (zona1_num == 0) {	
          normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false); 
          min_heart_txt.setProperty(hmUI.prop.VISIBLE, false);
          max_heart_txt.setProperty(hmUI.prop.VISIBLE, false);
          normal_distance_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_group_ForecastWeather.setProperty(hmUI.prop.VISIBLE, true);            
          normal_forecast_date_week_font.setProperty(hmUI.prop.VISIBLE, true);			
          normal_forecast_date_week_font_Array.setProperty(hmUI.prop.VISIBLE, true);		
          normal_forecast_average_text_img.setProperty(hmUI.prop.VISIBLE, true);
          normal_forecast_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
          normal_forecast_image_array.setProperty(hmUI.prop.VISIBLE, true);           
          hmUI.showToast({     
          });        
        };
      
          if (zona1_num == 1) {
            normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, false);
            normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false); 
            min_heart_txt.setProperty(hmUI.prop.VISIBLE, false);
            max_heart_txt.setProperty(hmUI.prop.VISIBLE, false);
            normal_distance_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
            normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
            normal_group_ForecastWeather.setProperty(hmUI.prop.VISIBLE, false);            
            normal_forecast_date_week_font.setProperty(hmUI.prop.VISIBLE, false);			
            normal_forecast_date_week_font_Array.setProperty(hmUI.prop.VISIBLE, false);		
            normal_forecast_average_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_forecast_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
            normal_forecast_image_array.setProperty(hmUI.prop.VISIBLE, false);           
            hmUI.showToast({          
          });        
        };
      
          if (zona1_num == 2) {
            normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
          normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true); 
          min_heart_txt.setProperty(hmUI.prop.VISIBLE, true);
          max_heart_txt.setProperty(hmUI.prop.VISIBLE, true);
          normal_distance_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_group_ForecastWeather.setProperty(hmUI.prop.VISIBLE, false);            
          normal_forecast_date_week_font.setProperty(hmUI.prop.VISIBLE, false);			
          normal_forecast_date_week_font_Array.setProperty(hmUI.prop.VISIBLE, false);		
          normal_forecast_average_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_forecast_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
          normal_forecast_image_array.setProperty(hmUI.prop.VISIBLE, false);           
          hmUI.showToast({                                
     });
     };
     }

     
       
    

            btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {             
              x: 153,             
              y: 261,              
              text: '',              
              w: 170,             
              h: 80,             
              normal_src: 'Empty.png',              
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
	    	     click_zona1();
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
             btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
             normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
             normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, false);
             normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false); 
             min_heart_txt.setProperty(hmUI.prop.VISIBLE, false);
             max_heart_txt.setProperty(hmUI.prop.VISIBLE, false);
             normal_distance_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
             normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
             normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, false);

          