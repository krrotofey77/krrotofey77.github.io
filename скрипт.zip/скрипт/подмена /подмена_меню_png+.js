﻿/*
** Watch_Face_Editor tool
** watchface js version v2.1.1
*/

try {
(() => {

// ===== SYSTEM INIT (не трогать) =====
const __$$app$$__ = __$$hmAppManager$$__.currentApp;
const __$$module$$__ = __$$app$$__.current;
const h = new DeviceRuntimeCore.WidgetFactory(
    new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__)
);
const logger = Logger.getLogger('watchface_SashaCX75');


// ===== CONFIG =====

// цифры для всех текстовых виджетов
const FONT = [
    "Bat_number00.png","Bat_number01.png","Bat_number02.png",
    "Bat_number03.png","Bat_number04.png","Bat_number05.png",
    "Bat_number06.png","Bat_number07.png","Bat_number08.png","Bat_number09.png"
];

// индексы виджетов (чтобы не путаться в цифрах)
const WIDGET = {
    BATTERY: 0,
    HEART: 1,
    STEP: 2,
    CALORIE: 3
};


// ===== STATE (текущее состояние UI) =====

// массив всех виджетов (text + icon)
let widgets = [];

// массив кнопок меню
let buttons = [];

// фон меню
let menuBackground = null;

// открыто ли меню
let menuVisible = false;


// ===== LOGIC =====

// показать один виджет и скрыть остальные
function showWidget(id) {

    // скрываем всё
    widgets.forEach(w => {
        w.text.setProperty(hmUI.prop.VISIBLE, false);
        w.icon.setProperty(hmUI.prop.VISIBLE, false);
    });

    // показываем нужный
    widgets[id].text.setProperty(hmUI.prop.VISIBLE, true);
    widgets[id].icon.setProperty(hmUI.prop.VISIBLE, true);
}


// управление видимостью меню (фон + кнопки)
function setMenuVisible(state) {
    menuVisible = state;

    menuBackground.setProperty(hmUI.prop.VISIBLE, state);

    // показываем/скрываем все кнопки меню
    buttons.forEach(b => b.setProperty(hmUI.prop.VISIBLE, state));
}


// переключение меню (открыть/закрыть)
function toggleMenu() {
    setMenuVisible(!menuVisible);
}


// заглушка под вибрацию (можно потом добавить hmApp.vibrate)
function click_Vibrate() {
    // TODO: добавить вибрацию
}


// ===== MAIN WATCHFACE =====
__$$module$$__.module = DeviceRuntimeCore.WatchFace({

init_view() {

    // ===== BACKGROUND =====

    // основной фон циферблата
    hmUI.createWidget(hmUI.widget.IMG, {
        x: 0, y: 0, w: 466, h: 466,
        src: '0119.png',
        show_level: hmUI.show_level.ONLY_NORMAL,
    });


    // ===== DATA WIDGETS (батарея, пульс, шаги, калории) =====

    // типы данных
    const types = [
        hmUI.data_type.BATTERY,
        hmUI.data_type.HEART,
        hmUI.data_type.STEP,
        hmUI.data_type.CAL
    ];

    // соответствующие иконки
    const icons = ['0012.png','0013.png','0014.png','0015.png'];

    // создаём все 4 виджета в цикле
    for (let i = 0; i < 4; i++) {

        // текст (цифры)
        let text = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            x: 300, y: 150,
            font_array: FONT,
            h_space: 1,
            align_h: hmUI.align.LEFT,
            type: types[i],
            show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // иконка справа
        let icon = hmUI.createWidget(hmUI.widget.IMG, {
            x: 350, y: 150,
            src: icons[i],
            show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // сохраняем в массив
        widgets.push({ text, icon });
    }


    // ===== MENU =====

    // фон меню (оверлей)
    menuBackground = hmUI.createWidget(hmUI.widget.IMG, {
        x: 0, y: 0, w: 466, h: 466,
        src: 'menu.png',
        show_level: hmUI.show_level.ONLY_NORMAL,
    });


    // центральная кнопка (открыть меню)
    hmUI.createWidget(hmUI.widget.BUTTON, {
        x: 183, y: 183, w: 100, h: 100,
        normal_src: 'Empty.png',
        press_src: 'Empty.png',
        click_func: () => {
            toggleMenu();
            click_Vibrate();
        },
        show_level: hmUI.show_level.ONLY_NORMAL,
    });


    // названия кнопок меню
    const names = ['заряд','пульс','шаги','калории'];

    // создаём кнопки выбора виджета
    for (let i = 0; i < 4; i++) {

        let btn = hmUI.createWidget(hmUI.widget.BUTTON, {
            x: 80,
            y: 150 + i * 70, // вертикальный список
            w: 200,
            h: 50,
            text: names[i],
            normal_src: 'Empty.png',
            press_src: 'Empty.png',
            click_func: () => {
                showWidget(i);        // переключаем виджет
                setMenuVisible(false); // закрываем меню
                click_Vibrate();
            },
            show_level: hmUI.show_level.ONLY_NORMAL,
        });

        buttons.push(btn);
    }


    // ===== INITIAL STATE =====

    setMenuVisible(false);              // меню скрыто
    showWidget(WIDGET.BATTERY);         // по умолчанию батарея
},


onInit() {
    logger.log('init');
},

build() {
    this.init_view();
    logger.log('ready');
},

onDestroy() {
    logger.log('destroy');
}

});

})();
} catch (e) {
console.log('Error', e);
}