﻿        let element_index = 1;  // Selected element index
        let element_count = 4;  // Number of elements 

        function click_btn() {  // Function to enable and disable the visibility of elements
          element_index++;
          if(element_index > element_count) element_index = 1;

         normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);

          normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
                                                                                                        
          normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
          
          normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 4);
          if (element_index == 1) {
            hmUI.showToast({text: 'Distance'});
           };
           if (element_index == 2) {
             hmUI.showToast({text: 'Heart Rete'});
           };
           if (element_index == 3) {
             hmUI.showToast({text: 'Calories'});
           };
           if (element_index == 4) {
            hmUI.showToast({text: 'Steps'});
          };
        };
        ////////////////////////////////////////////////////////////////////////////////////////////////

        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

        //////////////////////////////////////////////////////////////////////////////////////////////////////

 // Button to switch elements. This block should be after all blocks with display elements.
 Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 180,  // x coordinate of the button
  y: 180,  // y coordinate of the button
  text: '',
  w: 120,  // button width
  h: 120,  // button height
  normal_src: 'transparent_img.png',  // transparent image
  press_src: 'transparent_img.png',  // transparent image
  show_level: hmUI.show_level.ONLY_NORMAL,
  click_func: () => {
    click_btn();
  }
});
