﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let menuBackground = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_calorie_current_text_img = ''
        
let btn_zona1 = ''

let btnBattery = ''
let btnHeart = ''
let btnStep = ''

let menuVisible = false
        function showWidget(id) {

  normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
  normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
  normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

  if (id == 0) {
    normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
  }

  if (id == 1) {
    normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
  }

  if (id == 2) {
    normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
    }

  if (id == 3) {
    normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
  }
}

function hideMenu() {

  menuVisible = false;

  menuBackground.setProperty(
    hmUI.prop.VISIBLE,
    false
  );

  btnBattery.setProperty(
    hmUI.prop.VISIBLE,
    false
  );

  btnHeart.setProperty(
    hmUI.prop.VISIBLE,
    false
  );

  btnStep.setProperty(
    hmUI.prop.VISIBLE,
    false
     );

  btnCalorie.setProperty(
    hmUI.prop.VISIBLE,
    false
  );
}

function toggleMenu() {

  menuVisible = !menuVisible;

  menuBackground.setProperty(
    hmUI.prop.VISIBLE,
    menuVisible
  );

  btnBattery.setProperty(
    hmUI.prop.VISIBLE,
    menuVisible
  );

  btnHeart.setProperty(
    hmUI.prop.VISIBLE,
    menuVisible
  );

  btnStep.setProperty(
    hmUI.prop.VISIBLE,
    menuVisible
    );

  btnCalorie.setProperty(
    hmUI.prop.VISIBLE,
    menuVisible
  );
}
     

        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0119.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 150,
              font_array: ["Bat_number00.png","Bat_number01.png","Bat_number02.png","Bat_number03.png","Bat_number04.png","Bat_number05.png","Bat_number06.png","Bat_number07.png","Bat_number08.png","Bat_number09.png"],
              padding: false,
              h_space: 1,
              angle: 0,
              unit_sc: '0130.png',
              unit_tc: '0130.png',
              unit_en: '0130.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 150,
              font_array: ["Bat_number00.png","Bat_number01.png","Bat_number02.png","Bat_number03.png","Bat_number04.png","Bat_number05.png","Bat_number06.png","Bat_number07.png","Bat_number08.png","Bat_number09.png"],
              padding: false,
              h_space: 1,
              angle: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 150,
              font_array: ["Bat_number00.png","Bat_number01.png","Bat_number02.png","Bat_number03.png","Bat_number04.png","Bat_number05.png","Bat_number06.png","Bat_number07.png","Bat_number08.png","Bat_number09.png"],
              padding: false,
              h_space: 1,
              angle: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
          normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 150,
              font_array: ["Bat_number00.png","Bat_number01.png","Bat_number02.png","Bat_number03.png","Bat_number04.png","Bat_number05.png","Bat_number06.png","Bat_number07.png","Bat_number08.png","Bat_number09.png"],
              padding: false,
              h_space: 1,
              angle: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });  
            
            
            
menuBackground = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
              y: 0,
              w: 466,
              h: 466,
  src: 'menu.png',
  show_level: hmUI.show_level.ONLY_NORMAL,
});


            btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 183,
  y: 183,
  text: '',
  w: 100,
  h: 100,
  normal_src: 'Empty.png',
  press_src: 'Empty.png',
  click_func: () => {
    toggleMenu();
    click_Vibrate();
  },
  show_level: hmUI.show_level.ONLY_NORMAL,
});

       btnBattery = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 80,
  y: 150,
  w: 200,
  h: 50,
  text: 'заряд',
  normal_src: 'Empty.png',
  press_src: 'Empty.png',
  click_func: () => {

    showWidget(0);

    hideMenu();

    click_Vibrate();
  },
  show_level: hmUI.show_level.ONLY_NORMAL,
});

btnHeart = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 80,
  y: 220,
  w: 200,
  h: 50,
  text: 'пульс',
  normal_src: 'Empty.png',
  press_src: 'Empty.png',
  click_func: () => {

    showWidget(1);

    hideMenu();

    click_Vibrate();
  },
  show_level: hmUI.show_level.ONLY_NORMAL,
});

btnStep = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 80,
  y: 290,
  w: 200,
  h: 50,
  text: 'шаги',
  normal_src: 'Empty.png',
  press_src: 'Empty.png',
  click_func: () => {

    showWidget(2);

    hideMenu();

    click_Vibrate();
  },
  show_level: hmUI.show_level.ONLY_NORMAL,
});

btnCalorie = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 80,
  y: 360,
  w: 200,
  h: 50,
  text: 'калории',
  normal_src: 'Empty.png',
  press_src: 'Empty.png',
  click_func: () => {

    showWidget(3);

    hideMenu();

    click_Vibrate();
  },
  show_level: hmUI.show_level.ONLY_NORMAL,
});
menuBackground.setProperty(hmUI.prop.VISIBLE, false);

btnBattery.setProperty(hmUI.prop.VISIBLE, false);
btnHeart.setProperty(hmUI.prop.VISIBLE, false);
btnStep.setProperty(hmUI.prop.VISIBLE, false);
btnCalorie.setProperty(hmUI.prop.VISIBLE, false);


normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}