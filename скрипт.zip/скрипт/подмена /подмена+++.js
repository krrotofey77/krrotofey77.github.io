let btn_zona1 = ''       
        let zona1_num = 0       
        let zona1_all = 1

        function click_zona1() {		  
        zona1_num = (zona1_num + 1) % (zona1_all + 1);  
        if (zona1_num == 0) {	
          normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
          Button_1.setProperty(hmUI.prop.VISIBLE, false);  
          normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);       
          hmUI.showToast({text: 'пульс'});     
          };        
        };
      
          if (zona1_num == 1) {          
            normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
            Button_1.setProperty(hmUI.prop.VISIBLE, true);
            normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);       
            hmUI.showToast({text: 'пульс'});                                     

        };


     let btn_zona2 = ''       
     let zona2_num = 0       
     let zona2_all = 1

     function click_zona2() {		  
      zona2_num = (zona2_num + 1) % (zona2_all + 1);  
     if (zona2_num == 0) {	
      normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       Button_3.setProperty(hmUI.prop.VISIBLE, false);
       normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            
       hmUI.showToast({text: 'калории'});                              
  
       };        
     
   
       if (zona2_num == 1) {
        
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
         Button_3.setProperty(hmUI.prop.VISIBLE, true);
         normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, true);      
         hmUI.showToast({text: 'калории'});                              
  
  };
  }

  let btn_zona3 = ''       
  let zona3_num = 0       
  let zona3_all = 1

  function click_zona3() {		  
    zona3_num = (zona3_num + 1) % (zona3_all + 1);  
  if (zona2_num == 0) {	
    normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
    Button_2.setProperty(hmUI.prop.VISIBLE, false);
    normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);   
    hmUI.showToast({text: 'пульс'});     
   
  };

    if (zona3_num == 1) {
     
      normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
      Button_2.setProperty(hmUI.prop.VISIBLE, true);
      normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);      
      hmUI.showToast({text: 'пульс'});                       

};
}




btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {             
  x: 185,             
  y: 375,              
  text: '',              
  w: 100,             
  h: 100,             
  normal_src: 'Empty.png',              
  press_src: 'Empty.png',             
  click_func: () => {				  
   click_zona1();               
   click_Vibrate();             
  },              
  show_level: hmUI.show_level.ONLY_NORMAL,            
});            
 btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
 normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
 Button_1.setProperty(hmUI.prop.VISIBLE, false);

 btn_zona2 = hmUI.createWidget(hmUI.widget.BUTTON, {             
  x: 265,             
  y: 255,              
  text: '',              
  w: 100,             
  h: 100,             
  normal_src: 'Empty.png',              
  press_src: 'Empty.png',             
  click_func: () => {				  
   click_zona2();               
   click_Vibrate();             
  },              
  show_level: hmUI.show_level.ONLY_NORMAL,            
});            
 btn_zona2.setProperty(hmUI.prop.VISIBLE, true);
 normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
Button_3.setProperty(hmUI.prop.VISIBLE, false);

btn_zona3 = hmUI.createWidget(hmUI.widget.BUTTON, {             
x: 100,             
y: 255,              
text: '',              
w: 100,             
h: 100,             
normal_src: 'Empty.png',              
press_src: 'Empty.png',             
click_func: () => {				  
click_zona3();               
click_Vibrate();             
},              
show_level: hmUI.show_level.ONLY_NORMAL,            
});            
btn_zona3.setProperty(hmUI.prop.VISIBLE, true);
normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
Button_2.setProperty(hmUI.prop.VISIBLE, false);