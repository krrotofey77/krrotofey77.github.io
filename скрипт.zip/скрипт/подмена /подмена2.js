﻿      

        let set_p_button = ''
        let step_cal_state = 0 // смена показаний
        let step_cal_state_txt = ''

        function step_cal_Switcher() {

          let step_cal_state_total = 6;
  
          step_cal_state = (step_cal_state + 1) % step_cal_state_total;
  
          switch (step_cal_state) {
  
              case 0:
                
                normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
                normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
                 
                step_cal_state_txt = 'Заряд';
              break;
  
              case 1:

                normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
                normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                step_cal_state_txt = 'Пульс'; 
              break;

              case 2:

                normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
                normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                step_cal_state_txt = 'Шаги'; 
              break;

              case 3:

                normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
                normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                step_cal_state_txt = 'Дистанция'; 
              break;

              case 4:

                normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
                normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                step_cal_state_txt = 'Погода'; 
              break;

              case 5:

                normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
                normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                step_cal_state_txt = 'Цифровое время'; 
              break;

              default:
                  break;
          }
  
          hmUI.showToast({ text: step_cal_state_txt });
        }
  
   


            normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
            normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    
      

          set_p_button = hmUI.createWidget(hmUI.widget.BUTTON, {
            x: 60,
            y: 180,
            text: '',
            w: 95,
            h: 95,
            normal_src: '',
            press_src: '',
            click_func: () => {
              step_cal_Switcher();
                //vibro(9);
            },
            show_level: hmUI.show_level.ONLY_NORMAL,
           });
           set_p_button.setProperty(hmUI.prop.VISIBLE, true);
