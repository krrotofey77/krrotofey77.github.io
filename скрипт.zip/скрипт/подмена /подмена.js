let group_btn = ''
        let ac_state = 0
        let ac_state_txt = ''


        function click_ac_Switcher() {

        let ac_state_total = 2;

        ac_state = (ac_state + 1) % ac_state_total;

  switch (ac_state) {

      case 0:
        group1.setProperty(hmUI.prop.VISIBLE, true);
		group2.setProperty(hmUI.prop.VISIBLE, false);
        normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        ac_state_txt = 'Steps';
          break;

      case 1:
        group2.setProperty(hmUI.prop.VISIBLE, true);
		group1.setProperty(hmUI.prop.VISIBLE, false);
        normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        ac_state_txt = 'Calorie';
      break;
    
      default:
          break;
  }

  hmUI.showToast({ text: ac_state_txt });
  
  
  
}
================
group_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 198,
  y: 359,
  text: '',
  w: 68,
  h: 48,
  normal_src: 'Empty.png',
  press_src: 'Empty.png',
  click_func: () => {
    click_ac_Switcher();
  },
  show_level: hmUI.show_level.ONLY_NORMAL,
});
group_btn.setProperty(hmUI.prop.VISIBLE, true); 
