let btn_element_1 = ''
        let elementnumber_1 = 1
        let total_elemente = 6

        function click_elemente() {
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }
                if(elementnumber_1==3) {
                  UpdateElementeThree();
                }
                if(elementnumber_1==4) {
                  UpdateElementeFour();
                }
                if(elementnumber_1==5) {
                  UpdateElementeFive();
                }
                if(elementnumber_1==6) {
                  UpdateElementeSix();
                }
                
            }
            if(elementnumber_1==1) hmUI.showToast({text: 'Шаги'});
            if(elementnumber_1==2) hmUI.showToast({text: 'Дистанция'});
            if(elementnumber_1==3) hmUI.showToast({text: 'Калории'});
            if(elementnumber_1==4) hmUI.showToast({text: 'Пульс'});
            if(elementnumber_1==5) hmUI.showToast({text: 'Кислород'});
            if(elementnumber_1==6) hmUI.showToast({text: 'Батарея'});
           

        }

        //шаги
        function UpdateElementeOne(){



       normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

       normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
   
       normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
       normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);

       normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

       normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);


        normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_icon_img .setProperty(hmUI.prop.VISIBLE, false);



        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);

        }

        //дистанция
        function UpdateElementeTwo(){

       normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

       normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
   
       normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);

       normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

       normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);

        normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_icon_img .setProperty(hmUI.prop.VISIBLE, false);

        }

       //калории
        function UpdateElementeThree(){

       normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

       normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
   
       normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);

       normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

       normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

        normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_icon_img .setProperty(hmUI.prop.VISIBLE, true);

        }


       //пульс
        function UpdateElementeFour(){

       normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

       normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
   
       normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);

       normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

        normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_icon_img .setProperty(hmUI.prop.VISIBLE, true);
        }

       //кислород
        function UpdateElementeFive(){

       normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

       normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
   
       normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

       normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);

        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

        normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_icon_img .setProperty(hmUI.prop.VISIBLE, true);

        }


       //заряд
        function UpdateElementeSix(){

       normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

       normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
       normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
   
       normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

       normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

        normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_icon_img .setProperty(hmUI.prop.VISIBLE, true);
        }



        Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 205,
          y: 205,
          w: 65,
          h: 55,
          text: '',
          color: 0xFFFF8C00,
          text_size: 25,
          press_src: 'empty.png',
          normal_src: 'empty.png',
          click_func: (button_widget) => {
            /// change elemente
            click_elemente()
          }, // end func
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button
