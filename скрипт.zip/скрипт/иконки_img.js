
        let normal_calorie_icon_img = '';
        let normal_heart_rate_icon_img = '';

       //////////////////////////////////////////////////////////
                // FontName: ic_by_Sever5187-Regular.ttf; FontSize: 25
                hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 464,
                    y: 464,
                    w: 388,
                    h: 36,
                    text_size: 25,
                    char_space: 0,
                    line_space: 0,
                    font: 'fonts/ic_by_Sever5187-Regular.ttf',
                    color: 0xFFFF0000,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.TOP,
                    text_style: hmUI.text_style.ELLIPSIS,
                    text: "0123456789 _-.,:;`'%°\\/",
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

               //////////////////////////////////////////////////
                normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 80,
                    y: 330,
                    w: 302,
                    h: 70,
                    text_size: 44,
                    text: "C",
                    char_space: 0,
                    line_space: 0,
                    font: 'fonts/ic_by_Sever5187-Regular.ttf',
                    color: 0xffff0000,
                    align_h: hmUI.align.LEFT, // CENTER_H
                    align_v: hmUI.align.TOP, // CENTER_V
                    text_style: hmUI.text_style.NONE,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 180,
                    y: 130,
                    w: 302,
                    h: 70,
                    text_size: 44,
                    text: "P",
                    char_space: 0,
                    line_space: 0,
                    font: 'fonts/ic_by_Sever5187-Regular.ttf',
                    color: 0xffff0000,
                    align_h: hmUI.align.LEFT, // CENTER_H
                    align_v: hmUI.align.TOP, // CENTER_V
                    text_style: hmUI.text_style.NONE,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                console.log('Watch_Face.ScreenAOD');
                const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: () => {
                        normal_calorie_icon_img.setProperty(hmUI.prop.MORE, {
                            x: 80,
                            y: 330,
                            w: 302,
                            h: 70,
                            text_size: 44,
                            text: "C",
                            char_space: 0,
                            line_space: 0,
                            font: 'fonts/ic_by_Sever5187-Regular.ttf',
                            color: 0xffff0000, // Обновленный цвет
                             //alpha:255,
                            align_h: hmUI.align.CENTER_H,
                            align_v: hmUI.align.CENTER_V,
                            text_style: hmUI.text_style.NONE,
                            show_level: hmUI.show_level.ONLY_NORMAL,
                        });
                        normal_heart_rate_icon_img.setProperty(hmUI.prop.MORE, {
                            x: 217,
                            y: 117,
                            w: 150,
                            h: 30,
                            text_size: 25,
                            char_space: 0,
                            line_space: 0,
                            font: 'fonts/ic_by_Sever5187-Regular.ttf',
                            color: 0xFFFF0000,
                             //alpha:255,
                            align_h: hmUI.align.CENTER_H,
                            align_v: hmUI.align.TOP,
                            text_style: hmUI.text_style.ELLIPSIS,
                            type: hmUI.data_type.HEART,
                            show_level: hmUI.show_level.ONLY_NORMAL,
                        });
                    },
                    pause_call: () => {
                        // Пауза
                    }
                });

            
        
           