 let bot_circle_btn = ''
        let bot_circle_state = 0

        function click_bot_circle_Switcher() {

          let bot_circle_state_total = 5;

          bot_circle_state = (bot_circle_state + 1) % bot_circle_state_total;

          switch (bot_circle_state) {

              case 0:
 
                  normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                    hour_path: 'h_1.png',
                    hour_centerX: 233,
                    hour_centerY: 233,
                    hour_posX: 15,
                    hour_posY: 168,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
      
                  normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                    minute_path: 'm_1.png',
                    minute_centerX: 233,
                    minute_centerY: 233,
                    minute_posX: 17,
                    minute_posY: 231,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
				  
				  normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                    second_path: 's_1.png',
                    second_centerX: 233,
                    second_centerY: 233,
                    second_posX: 13,
                    second_posY: 237,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
      
                  bot_circle_state_txt = 'Hands 1';
                  break;

              case 1:

                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                  hour_path: 'h_2.png',
                  hour_centerX: 233,
                  hour_centerY: 233,
                  hour_posX: 15,
                  hour_posY: 168,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                  minute_path: 'm_2.png',
                  minute_centerX: 233,
                  minute_centerY: 233,
                  minute_posX: 17,
                  minute_posY: 231,
                 show_level: hmUI.show_level.ONLY_NORMAL,
                });
				
				normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                  second_path: 's_2.png',
                  second_centerX: 233,
                  second_centerY: 233,
                  second_posX: 14,
                  second_posY: 226,
                show_level: hmUI.show_level.ONLY_NORMAL,
                });
   
              bot_circle_state_txt = 'Hands 2';
                  break;
                  case 2:
 
                  normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                    hour_path: 'h_3.png',
                    hour_centerX: 233,
                    hour_centerY: 233,
                    hour_posX: 15,
                    hour_posY: 168,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
      
                  normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                    minute_path: 'm_3.png',
                    minute_centerX: 233,
                    minute_centerY: 233,
                    minute_posX: 17,
                    minute_posY: 231,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
				  
				  normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                    second_path: 's_3.png',
                    second_centerX: 233,
                    second_centerY: 233,
                    second_posX: 13,
                    second_posY: 237,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
      
                  bot_circle_state_txt = 'Hands 3';
                  break;

              case 3:

                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                  hour_path: 'h_4.png',
                  hour_centerX: 233,
                  hour_centerY: 233,
                  hour_posX: 15,
                  hour_posY: 168,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                  minute_path: 'm_4.png',
                  minute_centerX: 233,
                  minute_centerY: 233,
                  minute_posX: 17,
                  minute_posY: 231,
                 show_level: hmUI.show_level.ONLY_NORMAL,
                });
				
				normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                  second_path: 's_4.png',
                  second_centerX: 233,
                  second_centerY: 233,
                  second_posX: 14,
                  second_posY: 226,
                show_level: hmUI.show_level.ONLY_NORMAL,
                });
   
              bot_circle_state_txt = 'Hands 4';
                  break;
                  case 4:
 
                  normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                    hour_path: 'h_5.png',
                    hour_centerX: 233,
                    hour_centerY: 233,
                    hour_posX: 15,
                    hour_posY: 168,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
      
                  normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                    minute_path: 'm_5.png',
                    minute_centerX: 233,
                    minute_centerY: 233,
                    minute_posX: 17,
                    minute_posY: 231,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
				  
				  normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                    second_path: 's_5.png',
                    second_centerX: 233,
                    second_centerY: 233,
                    second_posX: 13,
                    second_posY: 237,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
      
                  bot_circle_state_txt = 'Hands 5';
                  break;
              default:
                  break;
          }

          hmUI.showToast({ text: bot_circle_state_txt });
      }
	  
	  кнопка
	  bot_circle_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 202,
              y: 202,
              text: '',
              w: 65,
              h: 65,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
                  click_bot_circle_Switcher();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              bot_circle_btn.setProperty(hmUI.prop.VISIBLE, true);