let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 1
		
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {				   
			normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
			normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);			
		    hmUI.showToast({
            });
          };
		  
		 if (zona1_num == 1) {
			normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
			normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }
		------------------------------------------------------

		btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
		  x: 184,
		  y: 277,
		  text: '',
		  w: 97,
		  h: 97,
		  normal_src: 'Empty.png',
		  press_src: 'Empty.png',
		  click_func: () => {
			click_zona1();
		 },
		  show_level: hmUI.show_level.ONLY_NORMAL,
		});
		btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
		normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
		
		
	