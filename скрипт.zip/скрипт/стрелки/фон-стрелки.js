﻿
        let btn_bezel = ''
        let bezel_num = 1
        let bezel_all = 3
     
        function click_Bezel() {
            if(bezel_num>=bezel_all) {bezel_num=1;}
            else { bezel_num=bezel_num+1;}
            hmUI.showToast({text: "<BackGround> " + parseInt(bezel_num) });
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg_" + parseInt(bezel_num) + ".png");
        normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
              hour_path: `h_${bezel_num}.png`,
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 31,
              hour_posY: 147,
              show_level: hmUI.show_level.ONLY_NORMAL,
            } );
        normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
              minute_path: `m_${bezel_num}.png`,
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 27,
              minute_posY: 215,
              show_level: hmUI.show_level.ONLY_NORMAL,
            } );
         normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
              second_path: `s_${bezel_num}.png`,
              second_centerY: 233,
              second_centerY: 233,
              second_posX: 27,
              second_posY: 215,
              show_level: hmUI.show_level.ONLY_NORMAL,
             
            } );
          }
      
          console.log('Watch_Face.Shortcuts');
            btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 183,
              y: 183,
              text: '',
              w: 100,
              h: 100,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
                  click_Bezel();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel.setProperty(hmUI.prop.VISIBLE, true);

            