   let colornumber = 1
        let totalcolors = 6
        let namecolor = ''

        function click_Analog() {
            if(colornumber>=totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }

if ( colornumber == 1) { namecolor = "Style 1"}
if ( colornumber == 2) { namecolor = "Style 2"}
if ( colornumber == 3) { namecolor = "Style 3"}
if ( colornumber == 4) { namecolor = "Style 4"}
if ( colornumber == 5) { namecolor = "Style 5"}
if ( colornumber == 6) { namecolor = "Hidden"}
hmUI.showToast({text: namecolor });

        normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, "h_" + parseInt(colornumber) + ".png");
        normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, "m_" + parseInt(colornumber) + ".png");
        normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "s_" + parseInt(colornumber) + ".png");
        
   normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg_" + parseInt(colornumber) + ".png");   
                           
        }
////////////////////////////
Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 218,
    y: 217,
    w: 52,
    h: 49,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'Empty.png',
    normal_src: 'Empty.png',
    click_func: (button_widget) => {
      //change analog style
click_Analog()
    }, // end func
    show_level: hmUI.show_level.ONLY_NORMAL,
  }); // end button