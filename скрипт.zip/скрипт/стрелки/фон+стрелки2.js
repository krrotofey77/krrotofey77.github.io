  let nomer = 0;

         function menayem_fon_i_srelki() {
          nomer = (nomer + 1) % 10//по нажатию на кнопку к nomer добавляется 1, если nomer = 10 то nomer=0
          normal_image_img.setProperty(hmUI.prop.SRC, 'bg_' + nomer + '.png');//изменение фона согласно номера
          menayem_srelki(nomer)//вызов замены стрелок согласно номера
         }

//замена стрелок
         function menayem_srelki(handsnumberMin) {
          switch (handsnumberMin) {
           case 1:
            hourStr = 'str_H_1.png';
            minuStr = 'str_M_1.png';
            secoStr = 'str_S_1.png';
            break;
           case 2:
            hourStr = 'str_H_2.png';
            minuStr = 'str_M_2.png';
            secoStr = 'str_S_2.png';
            break;
           case 3:
            hourStr = 'str_H_3.png';
            minuStr = 'str_M_3.png';
            secoStr = 'str_S_3.png';
            break;
           case 4:
            hourStr = 'str_H_4.png';
            minuStr = 'str_M_4.png';
            secoStr = 'str_S_4.png';
            break;
           case 5:
            hourStr = 'str_H_5.png';
            minuStr = 'str_M_5.png';
            secoStr = 'str_S_5.png';
            break;
           case 6:
            hourStr = 'str_H_6.png';
            minuStr = 'str_M_6.png';
            secoStr = 'str_S_6.png';
            break;
           case 7:
            hourStr = 'str_H_7.png';
            minuStr = 'str_M_7.png';
            secoStr = 'str_S_7.png';
            break;
           case 8:
            hourStr = 'str_H_8.png';
            minuStr = 'str_M_8.png';
            secoStr = 'str_S_8.png';
            break;
           case 9:
            hourStr = 'str_H_9.png';
            minuStr = 'str_M_9.png';
            secoStr = 'str_S_9.png';
            break;
           default:
            hourStr = 'str_H_0.png';
            minuStr = 'str_M_0.png';
            secoStr = 'str_S_0.png';
            break;
          }
          normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
           hour_path: hourStr,
           hour_centerX: 233,
           hour_centerY: 233,
           hour_posX: 24,
           hour_posY: 108,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
           minute_path: minuStr,
           minute_centerX: 233,
           minute_centerY: 233,
           minute_posX: 24,
           minute_posY: 162,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
           second_path: secoStr,
           second_centerX: 233,
           second_centerY: 233,
           second_posX: 18,
           second_posY: 192,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


         }



//виджеты

//фон
         normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          src: 'bg_1.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
         });


//стрелки
         normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_path: 'str_H_0.png',
          hour_centerX: 233,
          hour_centerY: 233,
          hour_posX: 24,
          hour_posY: 108,
          show_level: hmUI.show_level.ONLY_NORMAL,
         });

         normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          minute_path: 'str_M_0.png',
          minute_centerX: 233,
          minute_centerY: 233,
          minute_posX: 24,
          minute_posY: 162,
          show_level: hmUI.show_level.ONLY_NORMAL,
         });

         normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          second_path: 'str_S_0.png',
          second_centerX: 233,
          second_centerY: 233,
          second_posX: 18,
          second_posY: 192,
          show_level: hmUI.show_level.ONLY_NORMAL,
         });


//кнопка
         btn_fon_i_srelki = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 183, //x кнопки
          y: 183, //y кнопки
          text: '',
          w: 100, //ширина кнопки
          h: 100, //высота кнопки
          normal_src: '0_Empty.png',
          press_src: 'press_100.png',
          click_func: () => {
           menayem_fon_i_srelki();
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
         });

