        let normal_digital_clock_img_time_1 = ''
        let normal_digital_clock_img_time_2 = ''
        let normal_digital_clock_img_time_3 = ''
        let normal_digital_clock_img_time_4 = ''
        ----------------------------------------------------------------
        let btn_zona1 = ''       
        let zona1_num = 0       
        let zona1_all = 4

        function click_zona1() {		  
        zona1_num = (zona1_num + 1) % (zona1_all + 1);  
        if (zona1_num == 0) {		
		    normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
            normal_digital_clock_img_time_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_digital_clock_img_time_2.setProperty(hmUI.prop.VISIBLE, false);
			normal_digital_clock_img_time_3.setProperty(hmUI.prop.VISIBLE, false);
			normal_digital_clock_img_time_4.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona1_num == 1) {
			normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
            normal_digital_clock_img_time_1.setProperty(hmUI.prop.VISIBLE, true);
			normal_digital_clock_img_time_2.setProperty(hmUI.prop.VISIBLE, false);
			normal_digital_clock_img_time_3.setProperty(hmUI.prop.VISIBLE, false);
			normal_digital_clock_img_time_4.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 2) {
			normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
            normal_digital_clock_img_time_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_digital_clock_img_time_2.setProperty(hmUI.prop.VISIBLE, true);
			normal_digital_clock_img_time_3.setProperty(hmUI.prop.VISIBLE, false);
			normal_digital_clock_img_time_4.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 3) {
			normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
            normal_digital_clock_img_time_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_digital_clock_img_time_2.setProperty(hmUI.prop.VISIBLE, false);
			normal_digital_clock_img_time_3.setProperty(hmUI.prop.VISIBLE, true);
			normal_digital_clock_img_time_4.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 4) {
			normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
            normal_digital_clock_img_time_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_digital_clock_img_time_2.setProperty(hmUI.prop.VISIBLE, false);
			normal_digital_clock_img_time_3.setProperty(hmUI.prop.VISIBLE, false);
			normal_digital_clock_img_time_4.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
     });
     };
     }

		-------------------------------------------------
		normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
			hour_startX: 47,
			hour_startY: 192,
			hour_array: ["c_0.png","c_1.png","c_2.png","c_3.png","c_4.png","c_5.png","c_6.png","c_7.png","c_8.png","c_9.png"],
			hour_zero: 1,
			hour_space: 0,
			hour_angle: 0,
			hour_unit_sc: 'colonc_3.png',
			hour_unit_tc: 'colonc_3.png',
			hour_unit_en: 'colonc_3.png',
			hour_align: hmUI.align.LEFT,

			minute_startX: 168,
			minute_startY: 192,
			minute_array: ["c_0.png","c_1.png","c_2.png","c_3.png","c_4.png","c_5.png","c_6.png","c_7.png","c_8.png","c_9.png"],
			minute_zero: 1,
			minute_space: 0,
			minute_angle: 0,
			minute_follow: 1,
			minute_align: hmUI.align.LEFT,

			show_level: hmUI.show_level.ONLY_NORMAL,
		  });
		  
		  normal_digital_clock_img_time_1 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
			hour_startX: 47,
			hour_startY: 192,
			hour_array: ["b_0.png","b_1.png","b_2.png","b_3.png","b_4.png","b_5.png","b_6.png","b_7.png","b_8.png","b_9.png"],
			hour_zero: 1,
			hour_space: 0,
			hour_angle: 0,
			hour_unit_sc: 'colonb_2.png',
			hour_unit_tc: 'colonb_2.png',
			hour_unit_en: 'colonb_2.png',
			hour_align: hmUI.align.LEFT,

			minute_startX: 168,
			minute_startY: 192,
			minute_array: ["b_0.png","b_1.png","b_2.png","b_3.png","b_4.png","b_5.png","b_6.png","b_7.png","b_8.png","b_9.png"],
			minute_zero: 1,
			minute_space: 0,
			minute_angle: 0,
			minute_follow: 1,
			minute_align: hmUI.align.LEFT,

			show_level: hmUI.show_level.ONLY_NORMAL,
		  });
		  
		  normal_digital_clock_img_time_2 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
			hour_startX: 57,
			hour_startY: 192,
			hour_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
			hour_zero: 1,
			hour_space: 0,
			hour_angle: 0,
			hour_unit_sc: 'colond_5.png',
			hour_unit_tc: 'colond_5.png',
			hour_unit_en: 'colond_5.png',
			hour_align: hmUI.align.LEFT,

			minute_startX: 168,
			minute_startY: 192,
			minute_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
			minute_zero: 1,
			minute_space: 0,
			minute_angle: 0,
			minute_follow: 1,
			minute_align: hmUI.align.LEFT,

			show_level: hmUI.show_level.ONLY_NORMAL,
		  });
		  
		  normal_digital_clock_img_time_3 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
			hour_startX: 61,
			hour_startY: 192,
			hour_array: ["h_0.png","h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png","h_7.png","h_8.png","h_9.png"],
			hour_zero: 1,
			hour_space: 0,
			hour_angle: 0,
			hour_unit_sc: 'colonh_1.png',
			hour_unit_tc: 'colonh_1.png',
			hour_unit_en: 'colonh_1.png',
			hour_align: hmUI.align.LEFT,

			minute_startX: 166,
			minute_startY: 192,
			minute_array: ["h_0.png","h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png","h_7.png","h_8.png","h_9.png"],
			minute_zero: 1,
			minute_space: 0,
			minute_angle: 0,
			minute_follow: 1,
			minute_align: hmUI.align.LEFT,

			show_level: hmUI.show_level.ONLY_NORMAL,
		  });
		  
		  normal_digital_clock_img_time_4 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
			hour_startX: 57,
			hour_startY: 192,
			hour_array: ["s_0.png","s_1.png","s_2.png","s_3.png","s_4.png","s_5.png","s_6.png","s_7.png","s_8.png","s_9.png"],
			hour_zero: 1,
			hour_space: 0,
			hour_angle: 0,
			hour_unit_sc: 'colons_4.png',
			hour_unit_tc: 'colons_4.png',
			hour_unit_en: 'colons_4.png',
			hour_align: hmUI.align.LEFT,

			minute_startX: 166,
			minute_startY: 192,
			minute_array: ["s_0.png","s_1.png","s_2.png","s_3.png","s_4.png","s_5.png","s_6.png","s_7.png","s_8.png","s_9.png"],
			minute_zero: 1,
			minute_space: 0,
			minute_angle: 0,
			minute_follow: 1,
			minute_align: hmUI.align.LEFT,

			show_level: hmUI.show_level.ONLY_NORMAL,
		  });
		  ---------------------------------------------------
		  btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {             
			x: 183,             
			y: 183,              
			text: '',              
			w: 100,             
			h: 100,             
			normal_src: 'Empty.png',              
			press_src: 'Empty.png',             
			click_func: () => {				  
			 click_zona1();               
			 click_Vibrate();             
			},              
			show_level: hmUI.show_level.ONLY_NORMAL,            
		  });            
		   btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
		   normal_digital_clock_img_time_1.setProperty(hmUI.prop.VISIBLE, false);
		   normal_digital_clock_img_time_2.setProperty(hmUI.prop.VISIBLE, false);
		   normal_digital_clock_img_time_3.setProperty(hmUI.prop.VISIBLE, false);
		   normal_digital_clock_img_time_4.setProperty(hmUI.prop.VISIBLE, false);