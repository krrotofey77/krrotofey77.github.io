﻿/*
** Watch_Face_Editor tool
** watchface js version v2.0.1
** Copyright © SashaCX75. All Rights Reserved
*/

try {
  (() => {
    const e = __$$hmAppManager$$__.currentApp;
    const o = e.current;
    const n = Logger.getLogger("watchface_SashaCX75");

    o.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        const CLOCK_CONFIGS = [
          { x: 47, mx: 168, p: 'c', c: 'colonc_3.png' },
          { x: 47, mx: 168, p: 'b', c: 'colonb_2.png' },
          { x: 57, mx: 168, p: 'd', c: 'colond_5.png' },
          { x: 61, mx: 166, p: 'h', c: 'colonh_1.png' },
          { x: 57, mx: 166, p: 's', c: 'colons_4.png' }
        ];

        let zona1_num = 0;
        let clockStyles = [];

        const getImgArr = (p) => Array.from({ length: 10 }, (_, i) => `${p}_${i}.png`);

        // Функция переключения видимости (теперь она доступна выше)
        function updateStyles() {
          clockStyles.forEach((widget, i) => {
            widget.setProperty(hmUI.prop.VISIBLE, i === zona1_num);
          });
        }

        // Создаем виджеты
        clockStyles = CLOCK_CONFIGS.map((conf, index) => {
          return hmUI.createWidget(hmUI.widget.IMG_TIME, {
            hour_startX: conf.x,
            hour_startY: 192,
            hour_array: getImgArr(conf.p),
            hour_unit_sc: conf.c,
            hour_unit_tc: conf.c,
            hour_unit_en: conf.c,
            hour_zero: 1,
            hour_align: hmUI.align.LEFT,
            minute_startX: conf.mx,
            minute_startY: 192,
            minute_array: getImgArr(conf.p),
            minute_zero: 1,
            minute_follow: 1,
            minute_align: hmUI.align.LEFT,
            show_level: hmUI.show_level.ONLY_NORMAL
          });
        });

        // Кнопка
        hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 183,
          y: 183,
          w: 100,
          h: 100,
          text: '',
          normal_src: 'Empty.png',
          press_src: 'Empty.png',
          click_func: () => {
            zona1_num = (zona1_num + 1) % clockStyles.length;
            updateStyles();
            if (typeof click_Vibrate === 'function') click_Vibrate();
            hmUI.showToast({ text: 'Style ' + (zona1_num + 1) });
          },
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        // КРИТИЧЕСКИЙ МОМЕНТ: 
        // Явно вызываем скрытие всех лишних стилей сразу после инициализации
        updateStyles();
      },

      onInit() {
        n.log("onInit");
      },

      build() {
        this.init_view();
      },

      onDestroy() {
        n.log("onDestroy");
      }
    });
  })();
} catch (e) {
  console.log("Mini Program Error", e);
}
