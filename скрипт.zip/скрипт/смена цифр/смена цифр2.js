// ======================================================
//  CLOCK STYLE SWITCH SYSTEM (Optimized)
// ======================================================

// ---------- Глобальные переменные ----------
let clockStyles = []
let zona1_num = 0
let btn_zona1 = null


// ======================================================
//  ФУНКЦИЯ СОЗДАНИЯ СТИЛЯ ЧАСОВ
// ======================================================

function createClockStyle(config) {
  return hmUI.createWidget(hmUI.widget.IMG_TIME, {

    hour_startX: config.hourX,
    hour_startY: config.hourY,
    hour_array: config.hourArray,
    hour_zero: 1,
    hour_space: 0,
    hour_angle: 0,
    hour_unit_sc: config.colon,
    hour_unit_tc: config.colon,
    hour_unit_en: config.colon,
    hour_align: hmUI.align.LEFT,

    minute_startX: config.minX,
    minute_startY: config.minY,
    minute_array: config.minuteArray,
    minute_zero: 1,
    minute_space: 0,
    minute_angle: 0,
    minute_follow: 1,
    minute_align: hmUI.align.LEFT,

    show_level: hmUI.show_level.ONLY_NORMAL,
  })
}


// ======================================================
//  СОЗДАЕМ ВСЕ СТИЛИ
// ======================================================

function initClockStyles() {

  clockStyles = [

    // --- Стиль 0 ---
    createClockStyle({
      hourX: 47,
      hourY: 192,
      minX: 168,
      minY: 192,
      hourArray: ["c_0.png","c_1.png","c_2.png","c_3.png","c_4.png","c_5.png","c_6.png","c_7.png","c_8.png","c_9.png"],
      minuteArray: ["c_0.png","c_1.png","c_2.png","c_3.png","c_4.png","c_5.png","c_6.png","c_7.png","c_8.png","c_9.png"],
      colon: "colonc_3.png" //разделитель//
    }),

    // --- Стиль 1 ---
    createClockStyle({
      hourX: 47,
      hourY: 192,
      minX: 168,
      minY: 192,
      hourArray: ["b_0.png","b_1.png","b_2.png","b_3.png","b_4.png","b_5.png","b_6.png","b_7.png","b_8.png","b_9.png"],
      minuteArray: ["b_0.png","b_1.png","b_2.png","b_3.png","b_4.png","b_5.png","b_6.png","b_7.png","b_8.png","b_9.png"],
      colon: "colonb_2.png"
    }),

    // --- Стиль 2 ---
    createClockStyle({
      hourX: 57,
      hourY: 192,
      minX: 168,
      minY: 192,
      hourArray: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
      minuteArray: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
      colon: "colond_5.png"
    }),

    // --- Стиль 3 ---
    createClockStyle({
      hourX: 61,
      hourY: 192,
      minX: 166,
      minY: 192,
      hourArray: ["h_0.png","h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png","h_7.png","h_8.png","h_9.png"],
      minuteArray: ["h_0.png","h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png","h_7.png","h_8.png","h_9.png"],
      colon: "colonh_1.png"
    }),

    // --- Стиль 4 ---
    createClockStyle({
      hourX: 57,
      hourY: 192,
      minX: 166,
      minY: 192,
      hourArray: ["s_0.png","s_1.png","s_2.png","s_3.png","s_4.png","s_5.png","s_6.png","s_7.png","s_8.png","s_9.png"],
      minuteArray: ["s_0.png","s_1.png","s_2.png","s_3.png","s_4.png","s_5.png","s_6.png","s_7.png","s_8.png","s_9.png"],
      colon: "colons_4.png"
    })

  ]


  // Показываем только первый стиль
  updateClockVisibility()
}


// ======================================================
//  ОБНОВЛЕНИЕ ВИДИМОСТИ
// ======================================================

function updateClockVisibility() {

  for (let i = 0; i < clockStyles.length; i++) {
    clockStyles[i].setProperty(
      hmUI.prop.VISIBLE,
      i === zona1_num
    )
  }
}


// ======================================================
//  ПЕРЕКЛЮЧЕНИЕ СТИЛЯ
// ======================================================

function click_zona1() {

  zona1_num = (zona1_num + 1) % clockStyles.length

  updateClockVisibility()

  hmUI.showToast({})
}


// ======================================================
//  КНОПКА ПЕРЕКЛЮЧЕНИЯ
// ======================================================

function initButton() {

  btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 183,
    y: 183,
    text: '',
    w: 100,
    h: 100,
    normal_src: 'Empty.png',
    press_src: 'Empty.png',
    click_func: () => {
      click_zona1()
      click_Vibrate()
    },
    show_level: hmUI.show_level.ONLY_NORMAL,
  })

  btn_zona1.setProperty(hmUI.prop.VISIBLE, true)
}


// ======================================================
//  ИНИЦИАЛИЗАЦИЯ
// ======================================================

initClockStyles()
initButton()