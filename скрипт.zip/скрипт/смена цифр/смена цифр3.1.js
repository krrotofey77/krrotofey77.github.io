﻿try {
  (() => {
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    const __$$module$$__ = __$$app$$__.current;

    const h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__)
    );

    const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75');

    // =========================
    // USER VARIABLES
    // =========================
    let time_index = 0;
    let normal_time = null;
    let Button_1 = null;

    // =========================
    // FUNCTIONS
    // =========================

    const time_styles = [
      {
        digit: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
        colon: "time_colon.png"
      },
      {
        digit: ["time1_0.png","time1_1.png","time1_2.png","time1_3.png","time1_4.png","time1_5.png","time1_6.png","time1_7.png","time1_8.png","time1_9.png"],
        colon: "time1_colon.png"
      },
      {
        digit: ["time2_0.png","time2_1.png","time2_2.png","time2_3.png","time2_4.png","time2_5.png","time2_6.png","time2_7.png","time2_8.png","time2_9.png"],
        colon: "time2_colon.png"
      },
      {
        digit: ["time3_0.png","time3_1.png","time3_2.png","time3_3.png","time3_4.png","time3_5.png","time3_6.png","time3_7.png","time3_8.png","time3_9.png"],
        colon: "time3_colon.png"
      }
    ];

    function getTimeArray() {
      return time_styles[time_index].digit;
    }

    function getColon() {
      return time_styles[time_index].colon;
    }

    function change_time() {
      console.log(`change_time(${time_index})`);

      time_index = (time_index + 1) % time_styles.length;

      const arr = getTimeArray();
      const colon_img = getColon();

      normal_time.setProperty(hmUI.prop.MORE, {
        hour_array: arr,
        minute_array: arr,
        second_array: arr,
        hour_unit_sc: colon_img,    // colon для简体中文
        hour_unit_tc: colon_img,    // colon для繁體中文
        hour_unit_en: colon_img     // colon для English
      });
    }

    // =========================
    // WATCHFACE
    // =========================

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {

        console.log('Watch_Face.ScreenNormal');

        // Фон
        hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 480,
          h: 480,
          src: 'bg_chess.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // ЧАСЫ + МИНУТЫ + СЕКУНДЫ + ДВОЕТОЧИЕ
        normal_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {

          // Часы
          hour_startX: 100,
          hour_startY: 220,
          hour_array: getTimeArray(),
          hour_zero: 1,
          hour_space: 0,
          hour_align: hmUI.align.LEFT,
          
          // ДВОЕТОЧИЕ (важно: эти параметры ставятся после часов и до минут)
          hour_unit_sc: getColon(),    // colon для简体中文
          hour_unit_tc: getColon(),    // colon для繁體中文
          hour_unit_en: getColon(),    // colon для English

          // Минуты
          minute_startX: 180,
          minute_startY: 220,
          minute_array: getTimeArray(),
          minute_zero: 1,
          minute_space: 0,
          minute_follow: 1,           // важно: минуты следуют за двоеточием
          minute_align: hmUI.align.LEFT,

          // Секунды
          second_startX: 260,
          second_startY: 220,
          second_array: getTimeArray(),
          second_zero: 1,
          second_space: 0,
          second_align: hmUI.align.LEFT,

          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // КНОПКА
        Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 180,
          y: 339,
          w: 120,
          h: 40,
          text: 'Switch',
          color: 0xFF80FF80,
          text_size: 25,
          radius: 12,
          press_color: 0xFFA0A0A0,
          normal_color: 0xFF696969,
          click_func: () => {
            change_time();
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        console.log('Watch_Face.ScreenAOD');
      },

      onInit() {
        logger.log('index page.js on init invoke');
      },

      build() {
        this.init_view();
        logger.log('index page.js on ready invoke');
      },

      onDestroy() {
        logger.log('index page.js on destroy invoke');
      },
    });

  })();
} catch (e) {
  console.log('Mini Program Error', e);
  e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}