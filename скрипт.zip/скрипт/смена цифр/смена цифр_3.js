﻿try {
  (() => {
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    const __$$module$$__ = __$$app$$__.current;

    const h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__)
    );

    const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75');

    // =========================
    // USER VARIABLES
    // =========================
    let time_index = 0;
    let normal_time = null;
    let Button_1 = null;

    // =========================
    // FUNCTIONS
    // =========================

    const time_styles = [
  ["number_0.png","number_1.png","number_2.png","number_3.png","number_4.png","number_5.png","number_6.png","number_7.png","number_8.png","number_9.png"],
  ["i_number_0.png","i_number_1.png","i_number_2.png","i_number_3.png","i_number_4.png","i_number_5.png","i_number_6.png","i_number_7.png","i_number_8.png","i_number_9.png"],
    ["5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png"],
  ["alt_0.png","alt_1.png","alt_2.png","alt_3.png","alt_4.png","alt_5.png","alt_6.png","alt_7.png","alt_8.png","alt_9.png"] // ← третий стиль
];

function getTimeArray() {
  return time_styles[time_index];
}

    function change_time() {
  console.log(`change_time(${time_index})`);

  time_index = (time_index + 1) % time_styles.length;

  const arr = getTimeArray();

  normal_time.setProperty(hmUI.prop.MORE, {
    hour_array: arr,
    minute_array: arr,
    second_array: arr,
  });
}

    // =========================
    // WATCHFACE
    // =========================

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {

        console.log('Watch_Face.ScreenNormal');

        // Фон
        hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 480,
          h: 480,
          src: 'bg_chess.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // ЧАСЫ + МИНУТЫ + СЕКУНДЫ
        normal_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {

          // Часы
          hour_startX: 100,
          hour_startY: 220,
          hour_array: getTimeArray(),
          hour_zero: 1,
          hour_space: 0,
          hour_align: hmUI.align.LEFT,

          // Минуты
          minute_startX: 180,
          minute_startY: 220,
          minute_array: getTimeArray(),
          minute_zero: 1,
          minute_space: 0,
          minute_align: hmUI.align.LEFT,

          // Секунды
          second_startX: 260,
          second_startY: 220,
          second_array: getTimeArray(),
          second_zero: 1,
          second_space: 0,
          second_align: hmUI.align.LEFT,

          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // КНОПКА
        Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 180,
          y: 339,
          w: 120,
          h: 40,
          text: 'Switch',
          color: 0xFF80FF80,
          text_size: 25,
          radius: 12,
          press_color: 0xFFA0A0A0,
          normal_color: 0xFF696969,
          click_func: () => {
            change_time();
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        console.log('Watch_Face.ScreenAOD');
      },

      onInit() {
        logger.log('index page.js on init invoke');
      },

      build() {
        this.init_view();
        logger.log('index page.js on ready invoke');
      },

      onDestroy() {
        logger.log('index page.js on destroy invoke');
      },
    });

  })();
} catch (e) {
  console.log('Mini Program Error', e);
  e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}