﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        function read_pressure() {
          console.log("read_pressure()");
          const file_name_alt = "../../../baro_altim/pressure.dat";
          const [fs_stat, err] = hmFS.stat(file_name_alt);
          if (err == 0) {
            let file_size = fs_stat.size;
            const len = file_size / 4;
            console.log(`size_alt: ${file_size}, lenght: ${len}`)
            const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY)
        
            let array_buffer = new Float32Array(len);
            hmFS.read(fh, array_buffer.buffer, 0, file_size);
            hmFS.close(fh);
            console.log(`value ${array_buffer[array_buffer.length -1]}`);
            return array_buffer;
          } else {
            console.log('err:', err)
          }
          return null;
        }
        
        function getPressureValue(pressure_array) {
          console.log("getPressureValue()");
          if(pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
          let start_index = pressure_array.length - 1;
          let end_index = start_index - 30*3; // 3 часа
          if(end_index < 0) end_index = 0;
          for (let index = start_index; index >= end_index; index--) {
            if(pressure_array[index] != 0) return parseInt(pressure_array[index] / 100);
          }
          return 0;
        }
        
        function changesPressure(pressure_array) {
          console.log("changesPressure()");
          if(pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
          let start_index = pressure_array.length - 1;
          let end_index = start_index - 30*3; // 3 часа
          let value = pressure_array[start_index];
          let result = 0;
          if(end_index < 0) end_index = 0;
          for (let index = start_index; index >= end_index; index--) {
            let element = pressure_array[index];
            if(element != 0) {
              if(Math.abs(value - element) > 10) { // учитываем только если разниза больше 0,1 hPa
                value = value - element;
                console.log(`element = ${element}`);
                console.log(`pressere_changes = ${value}`);
                return value;
              }
            }
          }
          return result;
        }
        
        function hPa_To_mmHg(hPa_value = 0) {
          let mmHg = Math.round(hPa_value * 0.750064);
          return mmHg;
        }
        //#endregion
        
        let text_pressere; // отображаем давление
        let text_pressere_changes; // отображаем изменение давления
        
        let normal_background_bg = ''
        let normal_image_img = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_step_icon_img = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_pro_minute_cover_pointer_img = ''
        let normal_analog_clock_time_pointer_smooth_second = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_second_separator_img = ''
        let idle_background_bg_img = ''
        let idle_image_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_second_separator_img = ''
        let image_top_img = ''
        let Button_1 = ''
        let timeSensor = ''
        let btn_zona1 = ''       
        let zona1_num = 0       
        let zona1_all = 1

        function click_zona1() {		  
        zona1_num = (zona1_num + 1) % (zona1_all + 1);  
        if (zona1_num == 0) {	
          normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
          normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
          normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true); 
          image_top_img.setProperty(hmUI.prop.VISIBLE, false);
          text_pressere.setProperty(hmUI.prop.VISIBLE, false); 
          normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);        
          hmUI.showToast({     
          });        
        };
      
          if (zona1_num == 1) {
            normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            image_top_img.setProperty(hmUI.prop.VISIBLE, true);
            text_pressere.setProperty(hmUI.prop.VISIBLE, true); 
            normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);           
            hmUI.showToast({          
                                      
     });
     };
     }
    
    let bg_fill = ''
        let bgColor = [0xeeeeee,0x00ffff,0x00fcdf,]
        let colorIndex = 0 
        let degreeSum = 0
        let crownSensitivity = 70		// уровень чувствительности колесика
        let colorIndex_text
    
     function onDigitalCrown() {
                        hmApp.registerSpinEvent(function (key, degree) {
                                if (key === hmApp.key.HOME) {
                                    degreeSum += degree;
                                    if (Math.abs(degreeSum) > crownSensitivity){
                                        let step = degreeSum < 0 ? -1 : 1;
                                        colorIndex += step;
                                        colorIndex = colorIndex < 0 ? bgColor.length + colorIndex : colorIndex % bgColor.length;
                                        degreeSum = 0;
                                        
                                        bg_fill.setProperty(hmUI.prop.MORE, { 
                                            x: 0,
                                            y: 0,
                                            w: 466,
                                            h: 466,
                                            radius: 233,
                                            color: bgColor[colorIndex],
                                        });
                                        
                        
                                    }
                                }
                            }
                        ) // crown
                    }
                    let bot_circle_btn = ''
                    //let mask_img = ''
                    let btn_mask = ''
                    let mask_num = 1
                    let mask_all = 5
            
                    function click_mask() {
                    if(mask_num>=mask_all) {mask_num=1;}
                    else { mask_num=mask_num+1;}
                    hmUI.showToast({text: "<Яркость> " + parseInt(mask_num) });
                    normal_image_img.setProperty(hmUI.prop.SRC, "mask_" + parseInt(mask_num) + ".png");
            }


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: 2IONA-Black.ttf; FontSize: 22; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 26,
              h: 26,
              text_size: 22,
              char_space: 2,
              line_space: 0,
              font: 'fonts/2IONA-Black.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              color: '0xFF8F9999',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            bg_fill = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              radius: 233,
              color: bgColor[colorIndex],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 164,
              y: 378,
              w: 150,
              h: 30,
              text_size: 22,
              char_space: 2,
              line_space: 0,
              font: 'fonts/2IONA-Black.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 251,
              y: 406,
              image_array: ["81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 160,
              y: 409,
              font_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              padding: false,
              h_space: 0,
              unit_sc: '111.png',
              unit_tc: '111.png',
              unit_en: '111.png',
              negative_image: '110.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 238,
              month_startY: 20,
              month_sc_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              month_tc_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              month_en_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 170,
              day_startY: 20,
              day_sc_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              day_tc_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              day_en_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: '34.png',
              day_unit_tc: '34.png',
              day_unit_en: '34.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 101,
              y: 309,
              src: '15.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 341,
              y: 114,
              src: '16.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            let alarm_clock_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 373,
              y: 118,
              font_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              padding: true,
              h_space: -1,
              dot_image: '112.png',          //ALARM CLOCK 
              invalid_image: 'empty.png',    //ALARM CLOCK
              align_h: hmUI.align.CENTR,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 264,
              font_array: ["5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 397,
              y: 270,
              src: '116.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 361,
              y: 207,
              src: '117.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 68,
              y: 75,
              week_en: ["17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              week_tc: ["17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              week_sc: ["17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 324,
              font_array: ["5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png"],
              padding: false,
              h_space: 0,
              unit_sc: '4.png',
              unit_tc: '4.png',
              unit_en: '4.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 246,
              y: 323,
              image_array: ["73.png","74.png","75.png","76.png","77.png","78.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 269,
              y: 206,
              font_array: ["5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 395,
              y: 211,
              src: '115.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 341,
              y: 114,
              src: '80.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '35.png',
              // center_x: 148,
              // center_y: 290,
              // x: 7,
              // y: 87,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 148 - 7,
              pos_y: 290 - 87,
              center_x: 148,
              center_y: 290,
              src: '35.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '36.png',
              // center_x: 148,
              // center_y: 290,
              // x: 8,
              // y: 99,
              // start_angle: 0,
              // end_angle: 360,
              // cover_path: '1.png',
              // cover_x: 0,
              // cover_y: 0,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 148 - 8,
              pos_y: 290 - 99,
              center_x: 148,
              center_y: 290,
              src: '36.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_pro_minute_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '37.png',
              // center_x: 148,
              // center_y: 291,
              // x: 8,
              // y: 99,
              // start_angle: 0,
              // end_angle: 360,
              // cover_path: '3.png',
              // cover_x: 44,
              // cover_y: 195,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '37.png',
              second_centerX: 148,
              second_centerY: 291,
              second_posX: 8,
              second_posY: 99,
              fresh_frequency: 10,
              fresh_freqency: 10,
              second_cover_path: '3.png',
              second_cover_x: 44,
              second_cover_y: 195,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 3,
              // fps: 10,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 69,
              hour_startY: 109,
              hour_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              hour_zero: 1,
              hour_space: -3,
              hour_angle: 0,
              hour_unit_sc: '48.png',
              hour_unit_tc: '48.png',
              hour_unit_en: '48.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 324,
              second_startY: 151,
              second_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -4,
              y: -4,
              src: '2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 108,
              hour_startY: 190,
              hour_array: ["61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png"],
              hour_zero: 1,
              hour_space: -3,
              hour_angle: 0,
              hour_unit_sc: '71.png',
              hour_unit_tc: '71.png',
              hour_unit_en: '71.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 324,
              second_startY: 151,
              second_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -4,
              y: -4,
              src: '2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 395,
              y: 211,
              src: '114.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            text_pressere = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 213,
              y: 188,
              w: 200,
              h: 65,
              text_size: 65,
              char_space: 0,
              line_space: 0,
              font: 'fonts/2IONA-Black.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              padding: true,
              text_style: hmUI.text_style.NONE,
              text: "--",
            });
           
            btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {             
              x: 385,             
              y: 200,              
              text: '',              
              w: 80,             
              h: 60,           
              normal_src: 'Empty.png',              
              press_src: 'Empty.png',             
              click_func: () => {				  
               click_zona1();               
               click_Vibrate();             
              },              
              show_level: hmUI.show_level.ONLY_NORMAL,            
            });            
             btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
             image_top_img.setProperty(hmUI.prop.VISIBLE, false);
             text_pressere.setProperty(hmUI.prop.VISIBLE, false);  
             normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
             
             btn_mask = hmUI.createWidget(hmUI.widget.BUTTON, {
                x: 0,
                y: 200,
                text: '',
                w: 80,
                h: 60,
                normal_src: 'Empty.png',
                press_src: 'Empty.png',
                click_func: () => {
                click_mask();
                },
                show_level: hmUI.show_level.ONLY_NORMAL,
                });
                btn_mask.setProperty(hmUI.prop.VISIBLE, true);

                console.log('Watch_Face.Buttons');
                Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 192,
                  y: 411,
                  w: 91,
                  h: 41,
                  text: '',
                  color: 0xFFFF8C00,
                  text_size: 25,
                  press_src: '72.png',
                  normal_src: '72.png',
                  click_func: () => {
	hmApp.startApp({ appid: 1066654, 
		url: 'page/index',
		params: {
			from_wf: true,
		}
	});
  },
});
    
            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                setTimeout(() => {
                  onDigitalCrown();
                  }, 350);
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                console.log('resume_call.js');
                let pressure_array = read_pressure();
                let value = getPressureValue(pressure_array);
                value = hPa_To_mmHg(value); // если нужно перевести в мм.рт.ст.
                let value_str = value == 0 ? "--" : value + "";
                text_pressere.setProperty(hmUI.prop.TEXT, value_str);
                
                // если нужно отслеживать изменение давления
                let pressere_changes_str = "Давление не меняется";
                let pressere_changes = changesPressure(pressure_array);
                if(pressere_changes < 0) pressere_changes_str = "Давление падает";
                if(pressere_changes > 0) pressere_changes_str = "Давление растет";
   text_pressere_changes.setProperty(hmUI.prop.TEXT, pressere_changes_str);           

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}